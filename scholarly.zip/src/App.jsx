import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import LandingPage from '@/pages/LandingPage';
import LoginPage from '@/pages/LoginPage';
import SignupPage from '@/pages/SignupPage';
import StudentDashboard from '@/pages/StudentDashboard';
import AdminDashboard from '@/pages/AdminDashboard';
import CoursePage from '@/pages/CoursePage';
import WelcomePage from '@/pages/WelcomePage';
import { useAuth } from '@/contexts/SupabaseAuthContext';

function App() {
  const { user, session, loading, profile, signOut, fetchProfile } = useAuth();
  const [currentPage, setCurrentPage] = useState('landing');
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [isWelcoming, setIsWelcoming] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      if (!['landing', 'login', 'signup', 'welcome'].includes(currentPage)) {
          setCurrentPage('landing');
      }
    }
  }, [user, loading, currentPage]);

  const handleNavigate = useCallback((page, data = null) => {
    if (page === 'course' && data) {
      setSelectedCourse(data);
    }
    
    if (page === 'welcome') {
      setIsWelcoming(true);
      if (user) fetchProfile(user.id);
    } else if (page.endsWith('-dashboard')) {
      setIsWelcoming(false);
    }
    
    if (page === 'home') {
        if (profile) {
            setCurrentPage(profile.role === 'admin' ? 'admin-dashboard' : 'student-dashboard');
        } else {
            setCurrentPage('landing');
        }
    } else {
        setCurrentPage(page);
    }
  }, [profile, user, fetchProfile]);
  
  const handleLogin = async () => {
      if (user) {
        const profileData = await fetchProfile(user.id);
        if (profileData) {
            setCurrentPage(profileData.role === 'admin' ? 'admin-dashboard' : 'student-dashboard');
        }
      }
  };

  const handleLogout = async () => {
    await signOut();
    setCurrentPage('landing');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div>
      </div>
    );
  }

  const renderPage = () => {
    if (isWelcoming) {
      if (!profile) {
        return <div className="min-h-screen flex items-center justify-center bg-background"><div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div></div>;
      }
      return <WelcomePage user={profile} onNavigate={handleNavigate} />;
    }
    
    if (!profile) {
      switch (currentPage) {
        case 'login':
          return <LoginPage onNavigate={handleNavigate} onLogin={handleLogin} />;
        case 'signup':
          return <SignupPage onNavigate={handleNavigate} />;
        default:
          return <LandingPage onNavigate={handleNavigate} />;
      }
    }

    switch (currentPage) {
      case 'student-dashboard':
        return <StudentDashboard user={profile} onNavigate={handleNavigate} onLogout={handleLogout} />;
      case 'admin-dashboard':
        return <AdminDashboard user={profile} onNavigate={handleNavigate} onLogout={handleLogout} />;
      case 'course':
        return <CoursePage course={selectedCourse} user={profile} onNavigate={handleNavigate} />;
      default:
        if (profile.role === 'admin') {
            return <AdminDashboard user={profile} onNavigate={handleNavigate} onLogout={handleLogout} />;
        }
        return <StudentDashboard user={profile} onNavigate={handleNavigate} onLogout={handleLogout} />;
    }
  };

  return (
    <>
      <Helmet>
        {/* Basic Meta */}
        <title>Scholarly | AI-Powered Study & Research Hub for Lagos Students</title>
        <meta
          name="description"
          content="Scholarly is an AI-driven learning and research platform built for Lagos students and professionals. Access PDF notes, video lectures, quizzes, property listings, and a smart AI assistant for schools like UNILAG, LASU, and YABATECH."
        />
        <meta
          name="keywords"
          content="Scholarly, Lagos students, AI education, UNILAG, LASU, YABATECH, study assistant, academic research, PDF summarizer, MCQs, property listings, scholarly AI"
        />
        <meta name="author" content="Scholarly Team" />

        {/* Theme & Branding */}
        <meta name="theme-color" content="#ffffff" />
        <meta name="color-scheme" content="light dark" />
        <meta name="background-color" content="#ffffff" />

        {/* Open Graph */}
        <meta property="og:type" content="website" />
        <meta
          property="og:title"
          content="Scholarly | AI-Powered Study & Research Hub for Lagos Students"
        />
        <meta
          property="og:description"
          content="Empowering Lagos students through AI-powered learning, property access, and academic collaboration. Study smarter with Scholarly."
        />
        <meta
          property="og:image"
          content="https://www.scholarlyedu.com/assets/banner-gradient.png"
        />
        <meta
          property="og:url"
          content={typeof window !== "undefined" ? window.location.href : "https://www.scholarlyedu.com"}
        />
        <meta property="og:locale" content="en_US" />

        {/* Twitter */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta
          name="twitter:title"
          content="Scholarly | Learn, Connect & Excel with AI"
        />
        <meta
          name="twitter:description"
          content="Join Scholarly — the futuristic AI-powered platform connecting Lagos students and agents through learning, research, and real estate."
        />
        <meta
          name="twitter:image"
          content="https://www.scholarlyedu.com/assets/banner-gradient.png"
        />
        <meta name="twitter:creator" content="@ScholarlyAI" />

        {/* Scholarly Metadata */}
        <meta
          name="citation_title"
          content="Scholarly: The AI Education Platform for Lagos Students"
        />
        <meta
          name="citation_author"
          content="Scholarly Research & Engineering Team"
        />
        <meta name="citation_publication_date" content="2025/10/12" />
        <meta
          name="citation_journal_title"
          content="Scholarly Research Series"
        />
        <meta
          name="citation_pdf_url"
          content="https://www.scholarlyedu.com/docs/whitepaper.pdf"
        />

        {/* Favicon */}
        <link rel="icon" href="https://www.scholarlyedu.com/assets/favicon.ico" />
        <link
          rel="apple-touch-icon"
          href="https://www.scholarlyedu.com/assets/logo-gradient.png"
        />
      </Helmet>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage + (isWelcoming ? '-welcome' : '')}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3, ease: 'easeInOut' }}
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
      <Toaster />
    </>
  );
}

export default App;
/* global Deno */

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { corsHeaders } from '../_shared/cors.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.30.0';
import { OpenAI } from 'https://esm.sh/openai@4.11.1';
import pdf from 'https://esm.sh/pdf-parse@1.1.1';
import { extract } from 'https://esm.sh/mammoth@1.6.0';

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
const AI_MODEL = Deno.env.get('AI_MODEL') || 'gpt-3.5-turbo';

const openai = new OpenAI({
  apiKey: OPENAI_API_KEY,
});

async function getDocumentContent(supabase, materialId) {
  const { data: material, error: materialError } = await supabase
    .from('materials')
    .select('storage_path, title, type')
    .eq('id', materialId)
    .single();

  if (materialError || !material) {
    throw new Error('Material not found.');
  }

  const { data: fileData, error: downloadError } = await supabase.storage
    .from('materials')
    .download(material.storage_path);

  if (downloadError) {
    throw new Error(`Failed to download document from storage: ${downloadError.message}`);
  }

  const buffer = await fileData.arrayBuffer();
  let content = '';
  
  const fileExtension = (material.type || material.storage_path.split('.').pop() || '').toLowerCase();

  if (fileExtension.includes('pdf')) {
      const pdfData = await pdf(buffer);
      content = pdfData.text;
  } else if (fileExtension.includes('docx')) {
      const docxResult = await extract({ arrayBuffer: buffer });
      content = docxResult.value;
  } else if (fileExtension.includes('txt')) {
      content = new TextDecoder().decode(buffer);
  } else {
      throw new Error(`Unsupported file type: ${fileExtension}`);
  }

  if (!content) {
    throw new Error('Could not extract any text from the document.');
  }

  return {
    content: content,
    title: material.title,
  };
}


async function handleOnDemandSummary(supabase, materialId) {
  const { data: cachedSummary } = await supabase
    .from('document_summaries')
    .select('summary_text, key_points')
    .eq('material_id', materialId)
    .maybeSingle();

  if (cachedSummary) {
    return { summary: cachedSummary.summary_text, keyPoints: cachedSummary.key_points };
  }

  const { content, title } = await getDocumentContent(supabase, materialId);

  const summaryPrompt = `
    Provide a concise summary and a list of key points for the following document.
    The document is titled "${title}".
    
    Document Content (first 12000 characters):
    """
    ${content.substring(0, 12000)}
    """

    Format your response as a JSON object with two keys: "summary" (a string) and "keyPoints" (an array of strings).
    The summary should be a brief, easy-to-understand paragraph.
    The key points should be a list of the most important takeaways.
  `;

  const completion = await openai.chat.completions.create({
    model: AI_MODEL,
    messages: [{ role: 'user', content: summaryPrompt }],
    response_format: { type: 'json_object' },
  });

  const result = JSON.parse(completion.choices[0].message.content);

  const { error: insertError } = await supabase
    .from('document_summaries')
    .insert({
      material_id: materialId,
      summary_text: result.summary,
      key_points: result.keyPoints,
      model_used: AI_MODEL,
      tokens_used: completion.usage?.total_tokens,
    });

  if (insertError) {
    console.error('Failed to cache summary:', insertError);
  }

  return result;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL'),
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    );

    const { materialId, action } = await req.json();

    if (!materialId || !action) {
      throw new Error('Missing materialId or action in request body');
    }

    let result;
    switch (action) {
      case 'on_demand_summary':
        result = await handleOnDemandSummary(supabase, materialId);
        break;
      default:
        throw new Error(`Unsupported action: ${action}`);
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });
  } catch (error) {
    console.error('Error in ai-action:', error.message, error.stack);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});
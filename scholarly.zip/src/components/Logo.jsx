import React from 'react';
import { BookMarked } from 'lucide-react';

const Logo = ({ className, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-2 cursor-pointer ${className}`}
    >
      <div className="bg-gradient-to-br from-purple-600 to-blue-500 p-2 rounded-lg shadow-md">
        <BookMarked className="text-white w-5 h-5" />
      </div>
      <span className="text-2xl font-bold text-gray-800">Scholarly</span>
    </div>
  );
};

export default Logo;

    import React, { useState, useEffect, useCallback, memo } from 'react';
    import { Document, Page } from 'react-pdf';
    import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
    import 'react-pdf/dist/esm/Page/TextLayer.css';
    import { Button } from '@/components/ui/button';
    import { Slider } from '@/components/ui/slider';
    import { Progress } from '@/components/ui/progress';
    import { ZoomIn, ZoomOut, Download, Loader2, AlertTriangle, RefreshCw, X, MessageSquare, BookOpen } from 'lucide-react';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { getSignedUrl } from '@/lib/data';
    import { useToast } from '@/components/ui/use-toast';
    import ChatBot from '@/components/ChatBot';

    const PDFViewer = ({ material, onBack }) => {
      const { profile } = useAuth();
      const { toast } = useToast();
      const [numPages, setNumPages] = useState(null);
      const [scale, setScale] = useState(1.0);
      const [isDownloadEnabled, setIsDownloadEnabled] = useState(false);
      const [isLoading, setIsLoading] = useState(true);
      const [loadError, setLoadError] = useState(null);
      const [signedUrl, setSignedUrl] = useState(null);
      const [retries, setRetries] = useState(0);
      const [isChatOpen, setIsChatOpen] = useState(false);
      const maxRetries = 2;
      const [pagesLoaded, setPagesLoaded] = useState(0);

      const fetchSignedUrl = useCallback(async () => {
        if (!material?.storage_path) {
          setLoadError('Invalid file path. Cannot display document.');
          setIsLoading(false);
          return;
        }
        setIsLoading(true);
        setLoadError(null);
        setSignedUrl(null);
        setPagesLoaded(0);
        try {
          const url = await getSignedUrl(material.storage_path);
          setSignedUrl(url);
        } catch (error) {
          console.error("Failed to get signed URL:", error);
          const errorMessage = 'Could not securely access the document. Please try again.';
          setLoadError(errorMessage);
          toast({ title: 'PDF Access Error', description: errorMessage, variant: 'destructive' });
          setIsLoading(false);
        }
      }, [material?.storage_path, toast]);

      useEffect(() => {
        fetchSignedUrl();
      }, [fetchSignedUrl, retries]);

      useEffect(() => {
        if (profile) {
          setIsDownloadEnabled(profile.can_download);
        }
      }, [profile]);

      const onDocumentLoadSuccess = useCallback(({ numPages }) => {
        setNumPages(numPages);
        setIsLoading(false);
        setLoadError(null);
        setRetries(0); 
      }, []);

      const onPageLoadSuccess = useCallback(() => {
        setPagesLoaded(prev => prev + 1);
      }, []);

      const onDocumentLoadError = useCallback((error) => {
        console.error("PDF Load Error:", error);
        let errorMessage = 'Failed to load the PDF document. It may be corrupted or in an unsupported format.';
        if (error.name === 'MissingPDFException' || error.message.includes('Load failed')) {
            errorMessage = 'The document could not be found. The file may be missing or the link has expired.';
        } else if (error.name === 'InvalidPDFException') {
            errorMessage = 'The document is not a valid PDF file.';
        } else if (error.message.includes('Unexpected server response')) {
            errorMessage = 'There was a network issue fetching the document. Please check your connection.';
        }
        
        if (retries < maxRetries) {
            setRetries(prev => prev + 1);
            return;
        }
        
        setLoadError(errorMessage);
        toast({ title: "PDF Load Error", description: errorMessage, variant: "destructive"});
        setIsLoading(false);
      }, [toast, retries, maxRetries]);

      const retryLoad = () => {
        setRetries(0);
        setLoadError(null);
        setIsLoading(true);
        fetchSignedUrl();
      }

      const zoomIn = () => setScale(prev => Math.min(prev + 0.2, 3.0));
      const zoomOut = () => setScale(prev => Math.max(prev - 0.2, 0.5));

      const handleDownload = async () => {
        if (!isDownloadEnabled) {
          toast({ title: 'Download Restricted', description: 'You do not have permission to download this material.' });
          return;
        }
        if (!signedUrl) {
            toast({ title: 'Download Failed', description: 'File URL is not available.', variant: 'destructive' });
            return;
        }
        try {
          const link = document.createElement('a');
          link.href = signedUrl;
          link.setAttribute('download', material.title || 'document.pdf');
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          toast({ title: 'Download Started', description: 'Your file download has begun.', variant: 'success' });
        } catch (error) {
          toast({ title: 'Download Failed', description: 'Could not initiate download. Please try again.', variant: 'destructive' });
        }
      };
      
      const WatermarkComponent = memo(() => {
        const watermark = profile?.email;
        if (isDownloadEnabled || !watermark) return null;
        return (
          <div className="absolute inset-0 grid grid-cols-3 grid-rows-6 pointer-events-none z-10 overflow-hidden">
            {[...Array(18)].map((_, i) => (
              <div key={i} className="flex items-center justify-center -rotate-45 opacity-5">
                <p className="text-foreground font-bold whitespace-nowrap text-lg">{watermark}</p>
              </div>
            ))}
          </div>
        );
      });

      const loadingComponent = (
        <div className="flex h-full items-center justify-center bg-white p-4">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
            <p className="mt-2 text-muted-foreground">Preparing document...</p>
          </div>
        </div>
      );
      
      const errorComponent = (
        <div className="flex h-full flex-col items-center justify-center bg-white p-4">
          <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
          <h3 className="text-xl font-semibold mb-2">Failed to Load PDF</h3>
          <p className="text-muted-foreground text-center max-w-md mb-4">{loadError || 'An unknown error occurred.'}</p>
          <Button onClick={retryLoad}>
            <RefreshCw className="mr-2 h-4 w-4"/> Try Again
          </Button>
        </div>
      );

      return (
        <div className="flex flex-col h-full bg-secondary/30 rounded-lg shadow-inner">
          <div className="flex flex-wrap justify-between items-center gap-2 p-2 rounded-t-lg bg-background border-b">
            <div className="flex items-center gap-2">
                <Button onClick={onBack} variant="ghost" size="icon">
                    <X className="h-5 w-5" />
                </Button>
                <h3 className="font-semibold text-sm truncate max-w-[200px] sm:max-w-xs">{material.title}</h3>
            </div>
            <div className="flex flex-wrap justify-center items-center gap-2">
                <div className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-muted-foreground" />
                    <span className="text-sm font-medium text-muted-foreground w-24 text-center">
                        {numPages ? `${pagesLoaded} / ${numPages}` : '--'} Pages
                    </span>
                </div>

                <div className="h-6 w-px bg-border mx-2 hidden sm:block"></div>
                <Button onClick={zoomOut} disabled={scale <= 0.5 || isLoading || !!loadError} variant="ghost" size="icon" className="hidden sm:inline-flex">
                    <ZoomOut className="h-5 w-5" />
                </Button>
                <Slider
                    value={[scale]}
                    onValueChange={(val) => setScale(val[0])}
                    max={3.0}
                    min={0.5}
                    step={0.1}
                    className="w-24 mx-2 hidden sm:block"
                    disabled={isLoading || !!loadError}
                />
                <Button onClick={zoomIn} disabled={scale >= 3.0 || isLoading || !!loadError} variant="ghost" size="icon" className="hidden sm:inline-flex">
                    <ZoomIn className="h-5 w-5" />
                </Button>
                <div className="h-6 w-px bg-border mx-2 hidden sm:block"></div>
                 {profile?.can_use_ai && (
                  <Button onClick={() => setIsChatOpen(prev => !prev)} variant={isChatOpen ? 'secondary' : 'default'}>
                    <MessageSquare className="h-4 w-4 mr-2" /> AI Assistant
                  </Button>
                )}
                <Button onClick={handleDownload} disabled={!isDownloadEnabled || isLoading || !!loadError} variant="default">
                    <Download className="h-4 w-4 mr-2" /> Download
                </Button>
            </div>
          </div>
          {(isLoading || (numPages && pagesLoaded < numPages)) && !loadError && (
              <Progress value={numPages ? (pagesLoaded / numPages) * 100 : 0} className="w-full h-1 rounded-none" />
          )}
          <div className="relative flex-grow w-full overflow-hidden rounded-b-md bg-white">
            <div className="absolute inset-0 overflow-auto custom-scrollbar">
              {(isLoading || !signedUrl) && !loadError && loadingComponent}
              {loadError && errorComponent}
              {signedUrl && !loadError && (
                 <Document
                  file={{ url: signedUrl, rangeChunkSize: 65536 }}
                  onLoadSuccess={onDocumentLoadSuccess}
                  onLoadError={onDocumentLoadError}
                  loading={loadingComponent}
                  className="flex flex-col items-center py-4 gap-y-4"
                >
                  <WatermarkComponent />
                  {Array.from(new Array(numPages), (el, index) => (
                    <Page
                      key={`page_${index + 1}`}
                      pageNumber={index + 1}
                      scale={scale}
                      renderTextLayer={true}
                      renderAnnotationLayer={false}
                      onLoadSuccess={onPageLoadSuccess}
                      loading={<div className="w-full h-[50vh] flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin"/></div>}
                      className="shadow-md"
                    />
                  ))}
                </Document>
              )}
            </div>
            {profile?.can_use_ai && material?.id && (
              <ChatBot 
                materialId={material.id} 
                materialTitle={material.title}
                isOpen={isChatOpen}
                setIsOpen={setIsChatOpen}
              />
            )}
          </div>
        </div>
      );
    }

    export default PDFViewer;
  
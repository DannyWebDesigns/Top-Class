import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardContent, CardFooter, CardTitle } from '@/components/ui/card';
import { MessageSquare, Send, X, Bot, FlaskConical, Lightbulb, HelpCircle, User, Loader2 } from 'lucide-react';
import { performAIAction } from '@/lib/data';
import { useToast } from '@/components/ui/use-toast';

function ChatBot({ materialId, materialTitle, isOpen, setIsOpen }) {
  const { toast } = useToast();
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if(isOpen && messages.length === 0) {
      setMessages([{ sender: 'bot', text: `Hello! I'm your AI assistant for "${materialTitle}". Ask me anything or use one of the quick actions below!` }]);
    }
  }, [isOpen, materialTitle, messages.length]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading || !materialId) return;

    const userMessage = { sender: 'user', text: inputMessage };
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await performAIAction(materialId, 'qna', inputMessage);
      setMessages(prev => [...prev, { sender: 'bot', text: response.answer, sources: response.sources }]);
    } catch (error) {
      setMessages(prev => [...prev, { sender: 'bot', text: error.message || "I'm having trouble connecting. Please try again." }]);
      toast({ title: 'AI Error', description: error.message || 'Failed to get a response.', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAIAction = async (actionType, actionText) => {
    if (isLoading || !materialId) return;
    setMessages(prev => [...prev, { sender: 'user', text: actionText }]);
    setIsLoading(true);

    try {
      const response = await performAIAction(materialId, actionType);
      let botResponse;
      
      if (actionType === 'generate_mcq' && response.mcqs) {
         botResponse = {
            sender: 'bot', 
            component: 'mcq',
            data: response.mcqs
        };
      } else {
        botResponse = { sender: 'bot', text: response.result || `Could not perform action: ${actionText}` };
      }
      setMessages(prev => [...prev, botResponse]);
    } catch (error) {
      setMessages(prev => [...prev, { sender: 'bot', text: error.message || `Sorry, I couldn't perform the action: ${actionText}.` }]);
      toast({ title: 'AI Action Error', description: error.message || `Failed to ${actionText}.`, variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {!isOpen && (
        <motion.button
          className="fixed bottom-6 right-6 bg-primary text-primary-foreground h-16 w-16 rounded-full shadow-lg flex items-center justify-center z-[60]"
          whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
          onClick={() => setIsOpen(true)}
          aria-label="Open AI Assistant"
        >
          <MessageSquare size={28} />
        </motion.button>
      )}

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="fixed bottom-6 right-6 w-full max-w-md h-[70vh] max-h-[600px] z-[60]"
          >
            <Card className="h-full w-full flex flex-col shadow-2xl border-primary/20 bg-background/95 backdrop-blur-sm">
              <CardHeader className="flex-row items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bot className="h-6 w-6 text-primary" />
                  <CardTitle>AI Study Assistant</CardTitle>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
                {messages.map((msg, index) => (
                  <div key={index} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                    {msg.sender === 'bot' && <Bot className="h-6 w-6 text-primary flex-shrink-0" />}
                    <div className={`p-3 rounded-lg max-w-[85%] ${msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
                      {msg.component === 'mcq' ? (
                        <div className="flex flex-col gap-4">
                        {msg.data.map((mcq, i) => (
                            <div key={i} className="bg-background/50 p-3 rounded-lg border">
                                <p className="font-semibold mb-2">{i + 1}. {mcq.question}</p>
                                <ul className="space-y-1 mb-2">
                                {mcq.options.map((option, optIndex) => (
                                    <li key={optIndex} className={`text-sm ${optIndex === mcq.correct_option_index ? 'text-green-600 font-bold' : ''}`}>
                                    {String.fromCharCode(65 + optIndex)}. {option}
                                    </li>
                                ))}
                                </ul>
                                <p className="text-xs text-muted-foreground border-t pt-1 mt-2">Explanation: {mcq.explanation}</p>
                            </div>
                        ))}
                        </div>
                      ) : (
                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                      )}
                      {msg.sources && (
                        <div className="mt-2 text-xs text-muted-foreground">
                          <strong>Sources:</strong> {msg.sources.map(s => `Page ${s.page}`).join(', ')}
                        </div>
                      )}
                    </div>
                     {msg.sender === 'user' && <User className="h-6 w-6 text-muted-foreground flex-shrink-0" />}
                  </div>
                ))}
                 {isLoading && (
                    <div className="flex items-start gap-3">
                        <Bot className="h-6 w-6 text-primary flex-shrink-0" />
                        <div className="p-3 rounded-lg bg-secondary flex items-center">
                            <Loader2 className="w-5 h-5 text-muted-foreground animate-spin"/>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
              </CardContent>
              <CardFooter className="p-2 border-t flex flex-col gap-2">
                <div className="grid grid-cols-3 gap-2 w-full">
                   <Button variant="outline" size="sm" onClick={() => handleAIAction('generate_mcq', 'Generate MCQs')} disabled={isLoading}>
                    <Lightbulb className="h-4 w-4 mr-2" /> MCQs
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleAIAction('key_concepts', 'List Key Concepts')} disabled={isLoading}>
                    <FlaskConical className="h-4 w-4 mr-2" /> Concepts
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleAIAction('example_questions', 'Create Study Questions')} disabled={isLoading}>
                    <HelpCircle className="h-4 w-4 mr-2" /> Questions
                  </Button>
                </div>
                <div className="flex w-full space-x-2">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Ask a question..."
                    disabled={isLoading}
                  />
                  <Button onClick={handleSendMessage} disabled={isLoading || !inputMessage.trim()}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export default ChatBot;
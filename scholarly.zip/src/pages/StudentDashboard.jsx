import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Book, Video, LogOut, Search, Star, Bot, FileText, Loader2, Building } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import Logo from '@/components/Logo';
import { supabase } from '@/lib/customSupabaseClient';

function StudentDashboard({ onLogout, onNavigate }) {
  const { toast } = useToast();
  const { profile } = useAuth();
  const [courses, setCourses] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [videos, setVideos] = useState([]);
  const [institutions, setInstitutions] = useState([]);
  const [departments, setDepartments] = useState([]);

  const [filteredCourses, setFilteredCourses] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUniversity, setSelectedUniversity] = useState('all');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [loading, setLoading] = useState(true);

  const universities = useMemo(() => ['all', ...institutions.map(i => i.name)], [institutions]);
  const availableDepartments = useMemo(() => {
      if (selectedUniversity === 'all') return ['all'];
      const universityId = institutions.find(i => i.name === selectedUniversity)?.id;
      if (!universityId) return ['all'];
      return ['all', ...departments.filter(d => d.institution_id === universityId).map(d => d.name)];
  }, [selectedUniversity, institutions, departments]);

  const loadInitialData = useCallback(async () => {
    setLoading(true);
    try {
      const [coursesData, materialsData, videosData, institutionsData, departmentsData] = await Promise.all([
        supabase.from('courses').select('*'),
        supabase.from('materials').select('id, course_id, status'),
        supabase.from('videos').select('id, course_id'),
        supabase.from('homepage_institutions').select('*'),
        supabase.from('departments').select('*'),
      ]);
      setCourses(coursesData.data || []);
      setMaterials(materialsData.data || []);
      setVideos(videosData.data || []);
      setInstitutions(institutionsData.data || []);
      setDepartments(departmentsData.data || []);

    } catch (error) {
      toast({ title: 'Error', description: 'Failed to load dashboard data.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    loadInitialData();
    const channel = supabase.channel('student-dashboard-realtime').on('postgres_changes', { event: '*', schema: 'public' }, loadInitialData).subscribe();
    return () => supabase.removeChannel(channel);
  }, [loadInitialData]);
  
  useEffect(() => {
      if(selectedUniversity === 'all') {
          setSelectedDepartment('all');
      }
  }, [selectedUniversity]);

  useEffect(() => {
    let tempCourses = courses.filter(course =>
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.code.toLowerCase().includes(searchTerm.toLowerCase())
    );
    if (selectedUniversity !== 'all') tempCourses = tempCourses.filter(c => c.university === selectedUniversity);
    if (selectedDepartment !== 'all') {
        const departmentId = departments.find(d => d.name === selectedDepartment)?.id;
        if(departmentId) {
             tempCourses = tempCourses.filter(c => c.department_id === departmentId);
        }
    }
    setFilteredCourses(tempCourses);
  }, [searchTerm, courses, selectedUniversity, selectedDepartment, departments]);

  const getMaterialCount = (courseId) => materials.filter(m => m.course_id === courseId && m.status === 'available').length;
  const getVideoCount = (courseId) => videos.filter(v => v.course_id === courseId).length;

  const containerVariants = { hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.05 } } };
  const itemVariants = { hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } } };

  if (!profile) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-primary"></div></div>;
  }

  return (
    <>
      <Helmet><title>Your Learning Hub - Scholarly</title><meta name="description" content={`Welcome to your personalized learning hub, ${profile.full_name}.`} /></Helmet>
      <div className="min-h-screen bg-gray-50/50">
        <header className="container mx-auto px-4 sm:px-6 lg:px-8 pt-6">
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="flex justify-between items-center bg-white p-3 rounded-xl shadow-sm border">
            <Logo onClick={() => onNavigate('home')} />
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-gray-600 hidden sm:block">Welcome, {profile.full_name.split(' ')[0]}</span>
              <Button onClick={onLogout} variant="ghost" size="icon" className="rounded-full"><LogOut className="h-5 w-5 text-gray-600" /></Button>
            </div>
          </motion.div>
        </header>

        <main className="container mx-auto p-4 sm:p-6 lg:p-8">
            <motion.div key="course-list" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <div className="mb-8"><h1 className="text-4xl font-bold mb-2 gradient-text">Your Learning Hub</h1><p className="text-muted-foreground">All your study materials, in one place.</p></div>
                <Card className="p-4 mb-8 shadow-sm bg-white/70 backdrop-blur-sm border">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                    <div className="relative md:col-span-2"><Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input placeholder="Search courses, materials, or topics..." className="w-full pl-10 bg-gray-100 border-none focus:ring-2 focus:ring-primary" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} /></div>
                    <Select value={selectedUniversity} onValueChange={setSelectedUniversity}><SelectTrigger className="w-full bg-white border-gray-200"><SelectValue placeholder="University" /></SelectTrigger><SelectContent>{universities.map(uni => <SelectItem key={uni} value={uni}>{uni === 'all' ? 'All Universities' : uni}</SelectItem>)}</SelectContent></Select>
                    <Select value={selectedDepartment} onValueChange={setSelectedDepartment} disabled={selectedUniversity === 'all'}><SelectTrigger className="w-full bg-white border-gray-200 disabled:opacity-50"><SelectValue placeholder="Department" /></SelectTrigger><SelectContent>{availableDepartments.map(dep => <SelectItem key={dep} value={dep}>{dep === 'all' ? 'All Departments' : dep}</SelectItem>)}</SelectContent></Select>
                  </div>
                </Card>
                <div className="mb-6"><h2 className="text-2xl font-bold flex items-center gap-2"><Star className="text-yellow-400" /> Available Courses</h2></div>
                {loading ? (
                    <div className="flex justify-center items-center h-64"><Loader2 className="h-12 w-12 animate-spin text-primary"/></div>
                ) : (
                    <motion.div variants={containerVariants} initial="hidden" animate="visible" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredCourses.length > 0 ? filteredCourses.map(course => (
                        <motion.div key={course.id} variants={itemVariants}>
                        <Card onClick={() => onNavigate('course', course)} className="cursor-pointer bg-white transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5 overflow-hidden border">
                            <CardContent className="p-5">
                            <div className="flex justify-between items-start mb-4"><div className="p-3 bg-primary/10 rounded-lg"><Book className="h-6 w-6 text-primary" /></div><div className="text-xs font-semibold bg-primary/10 text-primary px-2 py-1 rounded-full">{course.university}</div></div>
                            <h3 className="font-bold text-lg mb-1 truncate">{course.title}</h3><p className="text-sm text-muted-foreground mb-4">{course.code}</p>
                            <div className="flex justify-between items-center text-sm text-muted-foreground"><span className="flex items-center gap-1.5"><FileText className="h-4 w-4" /> {getMaterialCount(course.id)}</span><span className="flex items-center gap-1.5"><Video className="h-4 w-4" /> {getVideoCount(course.id)}</span></div>
                            </CardContent>
                        </Card>
                        </motion.div>
                    )) : <p className="col-span-full text-muted-foreground text-center py-10">No courses found. Try adjusting your filters.</p>}
                    </motion.div>
                )}
                <motion.div variants={itemVariants} className="mt-12"><h2 className="text-2xl font-bold flex items-center gap-2 mb-4"><Bot className="text-primary" /> AI Study Assistant</h2><Card className="p-5 shadow-sm bg-white border"><p className="text-muted-foreground">Hi! I'm your AI study assistant. Select a document from any course to start an interactive study session. {profile?.can_use_ai ? "Your AI features are enabled!" : "Ask an admin to enable AI features for your account."}</p></Card></motion.div>
            </motion.div>
        </main>
      </div>
    </>
  );
}

export default StudentDashboard;
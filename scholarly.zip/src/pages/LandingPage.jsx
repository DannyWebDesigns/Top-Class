import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Video, MessageSquare, Search, Shield, Zap, Star, GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import { supabase } from '@/lib/customSupabaseClient';
const LandingPage = ({
  onNavigate
}) => {
  const [institutions, setInstitutions] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const fetchInstitutions = async () => {
      setLoading(true);
      const {
        data,
        error
      } = await supabase.from('homepage_institutions').select('*').order('name');
      if (error) {
        console.error("Error fetching institutions:", error);
      } else {
        setInstitutions(data);
      }
      setLoading(false);
    };
    fetchInstitutions();
    const channel = supabase.channel('homepage_institutions_changes_landing').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'homepage_institutions'
    }, payload => {
      console.log('Landing page received realtime update:', payload);
      fetchInstitutions();
    }).subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
  const features = [{
    icon: BookOpen,
    title: 'Vast PDF Library',
    desc: 'Access thousands of course materials and past questions.'
  }, {
    icon: Video,
    title: 'Curated Video Lectures',
    desc: 'Watch handpicked YouTube lectures for every topic.'
  }, {
    icon: MessageSquare,
    title: 'AI Study Assistant',
    desc: 'Get instant, accurate answers to your study questions.'
  }, {
    icon: Search,
    title: 'Advanced Search',
    desc: 'Quickly find materials by course, topic, or university.'
  }, {
    icon: Shield,
    title: 'Secure & Private',
    desc: 'Your data and study progress are always protected.'
  }, {
    icon: Zap,
    title: 'Blazing Fast',
    desc: 'A smooth, responsive experience on all your devices.'
  }];
  const testimonials = [{
    name: 'Adebayo, UNILAG',
    text: 'Scholarly changed the game for my exam prep. The past questions are a lifesaver!',
    avatar: 'https://images.unsplash.com/photo-1618231835033-a0c529323789?q=80&w=1887&auto=format&fit=crop'
  }, {
    name: 'Chidinma, LASU',
    text: 'The AI chatbot helps me understand complex topics faster than ever. It\'s like having a 24/7 tutor.',
    avatar: 'https://images.unsplash.com/photo-1629872433830-615858842c65?q=80&w=1887&auto=format&fit=crop'
  }, {
    name: 'Tunde, YABATECH',
    text: 'I love how organized everything is. Finding lecture notes for my specific course is so easy.',
    avatar: 'https://images.unsplash.com/photo-1631985223307-e2a86a693358?q=80&w=1887&auto=format&fit=crop'
  }];
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };
  const itemVariants = {
    hidden: {
      y: 20,
      opacity: 0
    },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };
  return <div className="min-h-screen bg-background">
      <nav className="glass-effect fixed top-4 left-1/2 -translate-x-1/2 w-[95%] max-w-7xl z-50 px-4 sm:px-6 py-3 rounded-2xl">
        <div className="flex justify-between items-center">
          <Logo />
          <div className="flex items-center gap-1 sm:gap-2">
            <Button variant="ghost" onClick={() => onNavigate('login')}>
              Login
            </Button>
            <Button onClick={() => onNavigate('signup')} className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-shadow text-sm sm:text-base px-3 sm:px-4">
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      <section className="pt-40 pb-24 px-6 text-center overflow-hidden">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.6
      }}>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text leading-tight">
            Unlock Your Academic Potential
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-3xl mx-auto">
            The ultimate resource hub for Lagos students. Access PDF notes, video lectures, and an AI tutor for UNILAG, LASU, YABATECH, and more.
          </p>
          <motion.div whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }}>
            <Button size="lg" onClick={() => onNavigate('signup')} className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-10 py-7 rounded-full shadow-lg hover:shadow-2xl transition-all">
              Start Learning in Seconds
            </Button>
          </motion.div>
        </motion.div>

        <motion.div initial={{
        opacity: 0,
        scale: 0.9
      }} animate={{
        opacity: 1,
        scale: 1
      }} transition={{
        delay: 0.3,
        duration: 0.6
      }} className="mt-20">
          <div className="relative max-w-5xl mx-auto">
            <div className="absolute -inset-2 bg-gradient-to-r from-purple-400 to-blue-400 rounded-3xl blur-xl opacity-50"></div>
            <img className="relative rounded-3xl shadow-2xl w-full" alt="A modern, diverse group of students collaborating around a digital tablet" src="https://horizons-cdn.hostinger.com/725bf773-15c9-4be3-940c-c9741472d5c1/chatgpt-image-oct-10-2025-at-07_32_06-pm-F6QqL.png" />
          </div>
        </motion.div>
      </section>

      <section className="py-24 px-6 bg-secondary/50">
        <div className="max-w-7xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.3
        }} variants={itemVariants}>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 gradient-text">Everything You Need to Excel</h2>
            <p className="text-lg text-muted-foreground text-center mb-16 max-w-2xl mx-auto">From lecture notes to AI-powered exam prep, we've got you covered.</p>
          </motion.div>
          <motion.div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.1
        }} variants={containerVariants}>
            {features.map(feature => <motion.div key={feature.title} variants={itemVariants} className="course-card">
                <div className="bg-gradient-to-br from-purple-100 to-blue-100 p-3 rounded-xl w-max mb-4">
                  <feature.icon className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.desc}</p>
              </motion.div>)}
          </motion.div>
        </div>
      </section>

      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.3
        }} variants={itemVariants}>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">Top Lagos Institutions</h2>
          </motion.div>
          <motion.div className="grid grid-cols-2 md:grid-cols-4 gap-8" initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.1
        }} variants={containerVariants}>
            {loading ? Array.from({
            length: 4
          }).map((_, index) => <motion.div key={index} variants={itemVariants} className="group relative rounded-2xl overflow-hidden bg-muted animate-pulse h-64"></motion.div>) : institutions.map(uni => <motion.div key={uni.name} variants={itemVariants} className="group relative rounded-2xl overflow-hidden hover-lift">
                <img className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110" alt={uni.name} src={`${uni.image_url}?t=${new Date(uni.updated_at || uni.created_at).getTime()}`} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6">
                  <h3 className="text-2xl font-bold text-white">{uni.name}</h3>
                </div>
              </motion.div>)}
          </motion.div>
        </div>
      </section>
      
      <section className="py-24 px-6 bg-secondary/50">
        <div className="max-w-5xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.3
        }} variants={itemVariants}>
            <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text">Don't Just Take Our Word For It</h2>
          </motion.div>
          <motion.div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8" initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.1
        }} variants={containerVariants}>
            {testimonials.map(testimonial => <motion.div key={testimonial.name} variants={itemVariants} className="course-card text-center">
                <img className="w-20 h-20 rounded-full mx-auto mb-4 shadow-lg object-cover" alt={testimonial.name} src={testimonial.avatar} />
                <p className="text-muted-foreground mb-4">"{testimonial.text}"</p>
                <div className="flex justify-center items-center text-yellow-500 mb-4">
                  {[...Array(5)].map((_, i) => <Star key={i} fill="currentColor" className="w-5 h-5" />)}
                </div>
                <h4 className="font-bold text-foreground">{testimonial.name}</h4>
              </motion.div>)}
          </motion.div>
        </div>
      </section>

      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.5
        }} variants={itemVariants}>
            <GraduationCap className="w-16 h-16 mx-auto mb-6 text-purple-500" />
            <h2 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">Ready to Ace Your Exams?</h2>
            <p className="text-lg text-muted-foreground mb-10">
              Join thousands of students across Lagos who are already learning smarter with Scholarly.
            </p>
            <motion.div whileHover={{
            scale: 1.05
          }} whileTap={{
            scale: 0.95
          }}>
              <Button size="lg" onClick={() => onNavigate('signup')} className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-10 py-7 rounded-full shadow-lg hover:shadow-2xl transition-all">
                Sign Up and Start for Free
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      <footer className="py-12 px-6 mt-20 border-t">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <Logo className="justify-center mb-4" />
          <p>© {new Date().getFullYear()} Scholarly. All Rights Reserved.</p>
          <p>Empowering the next generation of Lagos leaders.</p>
        </div>
      </footer>
    </div>;
};
export default LandingPage;

    import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { Helmet } from 'react-helmet';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
    import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
    import { Switch } from '@/components/ui/switch';
    import { Label } from '@/components/ui/label';
    import {
      fetchUniversities, addUniversity, updateUniversity, deleteUniversity,
      fetchUsers, updateUserPermission, fetchAuditLogs,
      addCourse, fetchCourses, updateCourse, deleteCourse,
      addMaterial, updateMaterial, deleteMaterial, uploadFile
    } from '@/lib/data';
    import { useToast } from '@/components/ui/use-toast';
    import { Edit, Trash2, PlusCircle, Book, Video, Users, Home, FileText, UploadCloud, X, Building, Check, Search, LogOut, BarChart2, RefreshCw, AlertTriangle, ShieldCheck } from 'lucide-react';
    import { Textarea } from '@/components/ui/textarea';
    import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import Logo from '@/components/Logo';
    import { supabase } from '@/lib/customSupabaseClient';

    const StatCard = ({ title, value, icon: Icon, colorClass, description }) => (
        <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5 border-l-4 border-primary/50 bg-card glass-effect">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
                <Icon className={`h-5 w-5 ${colorClass}`} />
            </CardHeader>
            <CardContent>
                <div className="text-3xl font-bold">{value}</div>
                <p className="text-xs text-muted-foreground">{description}</p>
            </CardContent>
        </Card>
    );

    const DialogComponent = ({ open, onOpenChange, title, description, children, footer }) => (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-background/95 backdrop-blur-sm border-primary/20">
                <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-foreground">{title}</DialogTitle>
                    {description && <DialogDescription>{description}</DialogDescription>}
                </DialogHeader>
                <div className="py-4 grid gap-4">{children}</div>
                <DialogFooter>{footer}</DialogFooter>
            </DialogContent>
        </Dialog>
    );

    const StatusBadge = ({ status }) => {
        const statusStyles = {
            available: 'bg-green-100 text-green-800',
            error: 'bg-red-100 text-red-800',
        };
        const badge = <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${statusStyles[status] || 'bg-gray-100 text-gray-800'}`}>{status || 'unknown'}</span>;
        return badge;
    };


    function AdminDashboard({ user, onNavigate, onLogout }) {
        const { toast } = useToast();
        const [activeTab, setActiveTab] = useState('statistics');
        const [searchTerm, setSearchTerm] = useState('');

        const [data, setData] = useState({ institutions: [], users: [], auditLogs: [], courses: [], materials: [], videos: [], departments: [] });
        
        const [dialogState, setDialogState] = useState({
            institution: { open: false, current: null, formData: {} },
            department: { open: false, current: null, formData: {} },
            course: { open: false, current: null, formData: {} },
            material: { open: false, current: null, formData: {} },
            video: { open: false, current: null, formData: {} }
        });

        const [isUploading, setIsUploading] = useState(false);
        const [materialFile, setMaterialFile] = useState(null);
        
        const loadData = useCallback(async () => {
            try {
                const [instData, usersData, logsData, coursesData, materialsData, videosData, departmentsData] = await Promise.all([
                    fetchUniversities(), fetchUsers(), fetchAuditLogs(), fetchCourses(),
                    supabase.from('materials').select('*').order('created_at', { ascending: false }), 
                    supabase.from('videos').select('*'),
                    supabase.from('departments').select('*'),
                ]);
                setData({
                    institutions: instData || [], users: usersData || [], auditLogs: logsData || [],
                    courses: coursesData || [], materials: materialsData.data || [], videos: videosData.data || [], departments: departmentsData.data || []
                });
            } catch (error) { toast({ title: 'Error', description: 'Failed to load platform data.', variant: 'destructive' }); }
        }, [toast]);

        useEffect(() => {
            loadData();
            const channel = supabase.channel('admin-dashboard-realtime').on('postgres_changes', { event: '*', schema: 'public' }, (payload) => {
                loadData();
            }).subscribe();
            return () => supabase.removeChannel(channel);
        }, [loadData]);

        const filteredData = useMemo(() => ({
            users: data.users.filter(u => u.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || u.email?.toLowerCase().includes(searchTerm.toLowerCase())),
            courses: data.courses.filter(c => c.title?.toLowerCase().includes(searchTerm.toLowerCase()) || c.code?.toLowerCase().includes(searchTerm.toLowerCase())),
            materials: data.materials.filter(m => m.title?.toLowerCase().includes(searchTerm.toLowerCase())),
            videos: data.videos.filter(v => v.title?.toLowerCase().includes(searchTerm.toLowerCase())),
            institutions: data.institutions.filter(i => i.name?.toLowerCase().includes(searchTerm.toLowerCase())),
            departments: data.departments.filter(d => d.name?.toLowerCase().includes(searchTerm.toLowerCase()))
        }), [data, searchTerm]);

        const openDialog = (type, current = null, initialData = {}) => {
            setDialogState(prev => ({
                ...prev,
                [type]: {
                    open: true,
                    current,
                    formData: { ...(current || {}), ...initialData }
                }
            }));
        };

        const closeDialog = (type) => {
            setDialogState(prev => ({ ...prev, [type]: { open: false, current: null, formData: {} } }));
            setMaterialFile(null);
        };
        
        const handleDialogFormChange = (type, field, value) => {
            setDialogState(prev => ({
                ...prev,
                [type]: { ...prev[type], formData: { ...prev[type].formData, [field]: value } }
            }));
        };
        
        const handleMaterialFileChange = (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const MAX_SIZE = 50 * 1024 * 1024; // 50MB
            if (file.size > MAX_SIZE) {
                toast({ title: 'File Too Large', description: `File should not exceed ${MAX_SIZE / 1024 / 1024}MB.`, variant: 'destructive' });
                e.target.value = '';
                return;
            }
            setMaterialFile(file);
        };

        const handleSave = async (type) => {
            const { current, formData } = dialogState[type];
            setIsUploading(true);
        
            try {
                switch (type) {
                    case 'material': {
                        if (!formData.title || !formData.course_id) throw new Error('Title and course are required.');
                        if (!current && !materialFile) throw new Error('File is required for new materials.');
                        
                        if (current) {
                            await updateMaterial(current.id, {
                                title: formData.title,
                                course_id: formData.course_id,
                            });
                        } else {
                            if (materialFile.size === 0) throw new Error('File is empty. Please upload a valid file.');
                            const course = data.courses.find(c => c.id === formData.course_id);
                            if (!course) throw new Error('Selected course not found.');
                            
                            const coursePath = `${course.university}/${course.code}`.replace(/\s+/g, '_').toLowerCase();
                            const storagePath = `${coursePath}/${Date.now()}_${materialFile.name.replace(/\s+/g, '_')}`;
                            
                            const tempMaterial = await addMaterial({
                                course_id: formData.course_id,
                                title: formData.title,
                                type: materialFile.type,
                                file_url: 'pending', 
                                status: 'pending'
                            });

                            try {
                                const { path } = await uploadFile(materialFile, 'materials', storagePath);
                                const { data: { publicUrl } } = supabase.storage.from('materials').getPublicUrl(path);
                                
                                await updateMaterial(tempMaterial.id, {
                                    file_url: publicUrl,
                                    storage_path: path,
                                    file_size: materialFile.size,
                                    file_size_mb: (materialFile.size / (1024 * 1024)),
                                    status: 'available',
                                    is_indexed_for_ai: true, // All docs are AI ready on-demand
                                });
                            } catch(uploadError) {
                                await deleteMaterial(tempMaterial.id);
                                throw uploadError;
                            }
                        }
                        break;
                    }
                    case 'department': {
                        if (!formData.name || !formData.institution_id) throw new Error('Name and university are required.');
                        if(current) {
                            await supabase.from('departments').update({ name: formData.name, institution_id: formData.institution_id }).eq('id', current.id);
                        } else {
                            await supabase.from('departments').insert({ name: formData.name, institution_id: formData.institution_id });
                        }
                        break;
                    }
                    case 'course': {
                        const { title, code, university, subject, description } = formData;
                        if (!title || !code || !university || !subject) throw new Error('All fields except description are required.');
                        if (current) {
                            await updateCourse(current.id, { title, code, university, subject, description });
                        } else {
                            await addCourse(title, code, university, subject, description);
                        }
                        break;
                    }
                    default: {
                       toast({ title: 'Hold up!', description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀", variant: 'default' });
                       setIsUploading(false);
                       return;
                    }
                }
                toast({ title: 'Success', description: `${type.charAt(0).toUpperCase() + type.slice(1)} saved successfully.`, variant: 'success' });
                closeDialog(type);
            } catch (error) {
                toast({ title: 'Save Failed', description: error.message, variant: 'destructive' });
            } finally {
                setIsUploading(false);
            }
        };
        
        const handleDelete = async (type, id) => {
            if (!window.confirm(`Delete this ${type}? This is irreversible.`)) return;
            try {
                if (type === 'material') {
                    const materialToDelete = data.materials.find(m => m.id === id);
                    if (materialToDelete?.storage_path) {
                        await supabase.storage.from('materials').remove([materialToDelete.storage_path]);
                    }
                    await deleteMaterial(id);
                } else if (type === 'department') {
                    await supabase.from('departments').delete().eq('id', id);
                } else if (type === 'course') {
                    await deleteCourse(id);
                } else {
                    toast({ title: 'Hold up!', description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀", variant: 'default' });
                     return;
                }
                toast({ title: 'Success', description: `${type} deleted.`, variant: 'success' });
            } catch (error) { toast({ title: 'Error', description: `Failed to delete ${type}: ${error.message}`, variant: 'destructive' }); }
        };

        const handleTogglePermission = async (targetUser, column, currentValue) => {
            try {
                await updateUserPermission(targetUser.id, column, !currentValue);
                toast({ title: 'Success', description: `Permission updated for ${targetUser.full_name}.`, variant: 'success' });
            } catch (error) { toast({ title: 'Error', description: `Failed to update permission: ${error.message}`, variant: 'destructive' }); }
        };
        
        const tabs = useMemo(() => [
            { value: 'statistics', icon: BarChart2, label: 'Dashboard' },
            { value: 'users', icon: Users, label: 'Users' },
            { value: 'institutions', icon: Building, label: 'Institutions'},
            { value: 'courses', icon: Book, label: 'Courses' },
            { value: 'materials', icon: FileText, label: 'Materials' },
        ], []);
        
        return (
            <>
                <Helmet><title>Admin Dashboard - Scholarly</title></Helmet>
                <div className="min-h-screen bg-gray-50/50">
                    <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-lg border-b border-gray-200/80">
                        <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-20">
                            <Logo onClick={() => onNavigate('home')} />
                            <div className="flex items-center gap-4">
                                <div className="text-right hidden sm:block">
                                    <p className="font-semibold text-primary">{user.full_name}</p>
                                    <p className="text-xs text-muted-foreground">Administrator</p>
                                </div>
                                <Button onClick={onLogout} variant="ghost" size="icon" className="rounded-full hover:bg-primary/10"><LogOut className="h-5 w-5 text-primary" /></Button>
                            </div>
                        </div>
                    </header>

                    <main className="container mx-auto p-4 sm:p-6 lg:p-8">
                        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                            <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8 bg-transparent p-0 rounded-none shadow-none border-b">
                                 {tabs.map(tab => <TabsTrigger key={tab.value} value={tab.value} className="flex-1 gap-2 data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none bg-transparent text-muted-foreground data-[state=active]:text-primary py-3"><tab.icon className="w-4 h-4"/>{tab.label}</TabsTrigger>)}
                            </TabsList>
                            
                             <AnimatePresence mode="wait">
                                <motion.div key={activeTab} initial={{ opacity: 0, y:10 }} animate={{ opacity: 1, y:0 }} exit={{ opacity: 0, y:-10 }} transition={{ duration: 0.2 }}>
                                    {activeTab === 'statistics' && <TabsContent value="statistics" forceMount>
                                        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                                            <StatCard title="Total Users" value={data.users.length} icon={Users} colorClass="text-blue-500" description={`${data.users.filter(u => u.can_use_ai).length} with AI access`} />
                                            <StatCard title="Total Institutions" value={data.institutions.length} icon={Building} colorClass="text-indigo-500" description={`${data.departments.length} departments`} />
                                            <StatCard title="Total Courses" value={data.courses.length} icon={Book} colorClass="text-green-500" description={`${new Set(data.courses.map(c => c.university)).size} universities`} />
                                            <StatCard title="Total Materials" value={data.materials.length} icon={FileText} colorClass="text-yellow-500" description={`${data.materials.filter(m => m.status === 'available').length} available`} />
                                        </div>
                                    </TabsContent>}
                                    
                                    {activeTab === 'institutions' && <TabsContent value="institutions" forceMount className="space-y-6">
                                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                            <Card className="glass-effect"><CardHeader><CardTitle>Manage Institutions</CardTitle></CardHeader><CardContent><Button onClick={() => openDialog('institution')}> <PlusCircle className="mr-2 h-4 w-4" /> Add Institution</Button></CardContent></Card>
                                            <Card className="glass-effect"><CardHeader><CardTitle>Manage Departments</CardTitle></CardHeader><CardContent><Button onClick={() => openDialog('department')}><PlusCircle className="mr-2 h-4 w-4" /> Add Department</Button></CardContent></Card>
                                        </div>
                                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                            <Card className="glass-effect"><CardHeader><CardTitle>All Institutions</CardTitle></CardHeader><CardContent className="space-y-2">{filteredData.institutions.map(inst => (<div key={inst.id} className="flex justify-between items-center p-2 rounded-md hover:bg-primary/5"><p>{inst.name}</p></div>))}</CardContent></Card>
                                            <Card className="glass-effect"><CardHeader><CardTitle>All Departments</CardTitle></CardHeader><CardContent className="space-y-2">{filteredData.departments.map(dep => (<div key={dep.id} className="flex justify-between items-center p-2 rounded-md hover:bg-primary/5"><p>{dep.name} <span className="text-xs text-muted-foreground">({data.institutions.find(i=>i.id===dep.institution_id)?.name})</span></p><div className="flex gap-2"><Button variant="ghost" size="icon" onClick={() => openDialog('department', dep)}><Edit className="h-4 w-4"/></Button><Button variant="ghost" size="icon" onClick={() => handleDelete('department', dep.id)}><Trash2 className="h-4 w-4 text-destructive"/></Button></div></div>))}</CardContent></Card>
                                        </div>
                                    </TabsContent>}
                                    
                                    {activeTab === 'courses' && <TabsContent value="courses" forceMount className="space-y-6">
                                        <Card className="glass-effect"><CardHeader><CardTitle>Course Management</CardTitle><CardDescription>Organize all academic courses.</CardDescription></CardHeader><CardContent><Button onClick={() => openDialog('course')}><PlusCircle className="mr-2 h-4 w-4" /> Add Course</Button></CardContent></Card>
                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">{filteredData.courses.map(course => (<Card key={course.id} className="glass-effect"><CardHeader><CardTitle>{course.title}</CardTitle><CardDescription>{course.code} - {course.university}</CardDescription></CardHeader><CardContent className="flex gap-2"><Button variant="outline" size="sm" onClick={() => openDialog('course', course)}><Edit className="h-4 w-4 mr-1"/>Edit</Button><Button variant="destructive" size="sm" onClick={() => handleDelete('course', course.id)}><Trash2 className="h-4 w-4 mr-1"/>Delete</Button></CardContent></Card>))}</div>
                                    </TabsContent>}

                                    {activeTab === 'users' && <TabsContent value="users" forceMount>
                                        <Card className="glass-effect"><CardHeader><CardTitle>User Management</CardTitle><CardDescription>Toggle permissions for users.</CardDescription></CardHeader>
                                        <CardContent>
                                            <div className="relative mb-4"><Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input placeholder="Search users by name or email..." className="pl-10" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} /></div>
                                            <div className="overflow-x-auto"><table className="w-full text-left"><thead><tr className="border-b"><th className="p-3">Name</th><th className="p-3">Email</th><th className="p-3">Role</th><th className="p-3 text-center">Downloads</th><th className="p-3 text-center">AI Access</th></tr></thead>
                                            <tbody>{filteredData.users.map(u => (<tr key={u.id} className="border-b hover:bg-gray-50/80"><td className="p-3 font-medium">{u.full_name}</td><td className="p-3 text-muted-foreground">{u.email}</td><td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${u.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>{u.role}</span></td><td className="p-3 text-center"><Switch checked={!!u.can_download} onCheckedChange={() => handleTogglePermission(u, 'can_download', u.can_download)} /></td><td className="p-3 text-center"><Switch checked={!!u.can_use_ai} onCheckedChange={() => handleTogglePermission(u, 'can_use_ai', u.can_use_ai)} /></td></tr>))}</tbody></table></div>
                                        </CardContent></Card>
                                    </TabsContent>}
                                    
                                    {activeTab === 'materials' && <TabsContent value="materials" forceMount className="space-y-6">
                                        <Card className="glass-effect"><CardHeader><CardTitle>Material Management</CardTitle><CardDescription>Upload and manage course documents.</CardDescription></CardHeader><CardContent><Button onClick={() => openDialog('material')}><PlusCircle className="mr-2 h-4 w-4"/>Add Material</Button></CardContent></Card>
                                        <div className="overflow-x-auto mt-6 bg-background p-4 rounded-xl border glass-effect"><table className="w-full text-left"><thead><tr className="border-b"><th className="p-3">Title</th><th className="p-3">Course</th><th className="p-3">Status</th><th className="p-3 text-center">AI Ready</th><th className="p-3 text-right">Actions</th></tr></thead><tbody>{filteredData.materials.map(mat => <tr key={mat.id} className="border-b hover:bg-gray-50/80 last:border-0"><td className="p-3 font-medium">{mat.title}</td><td className="p-3 text-muted-foreground">{data.courses.find(c => c.id === mat.course_id)?.title}</td><td className="p-3"><StatusBadge status={mat.status} /></td><td className="p-3 text-center">{mat.is_indexed_for_ai ? <ShieldCheck className="h-5 w-5 text-green-500 mx-auto"/> : <X className="h-5 w-5 text-red-500 mx-auto"/>}</td><td className="p-3 flex gap-2 justify-end"><Button variant="outline" size="icon" onClick={() => openDialog('material', mat)}><Edit className="h-4 w-4"/></Button><Button variant="destructive" size="icon" onClick={() => handleDelete('material', mat.id)}><Trash2 className="h-4 w-4"/></Button></td></tr>)}</tbody></table></div>
                                    </TabsContent>}
                                </motion.div>
                            </AnimatePresence>
                        </Tabs>
                    </main>
                    
                    <DialogComponent open={dialogState.material.open} onOpenChange={() => closeDialog('material')} title={dialogState.material.current ? 'Edit Material' : 'Add Material'} footer={<><Button variant="outline" onClick={() => closeDialog('material')}>Cancel</Button><Button onClick={() => handleSave('material')} disabled={isUploading}>{isUploading ? `Uploading...`: 'Save Material'}</Button></>}>
                        <Input placeholder="Material Title" value={dialogState.material.formData.title || ''} onChange={(e) => handleDialogFormChange('material', 'title', e.target.value)}/>
                        <Select onValueChange={(value) => handleDialogFormChange('material', 'course_id', value)} value={dialogState.material.formData.course_id || ''}><SelectTrigger><SelectValue placeholder="Select a course..."/></SelectTrigger><SelectContent>{data.courses.map(c => <SelectItem key={c.id} value={c.id}>{c.title} ({c.code})</SelectItem>)}</SelectContent></Select>
                        {!dialogState.material.current && <>
                            <Label>File (PDF, DOCX, PPTX, TXT - Max 50MB)</Label>
                            <Input type="file" onChange={handleMaterialFileChange} accept=".pdf,.docx,.pptx,.txt" disabled={!!dialogState.material.current}/>
                            {materialFile && <p className="text-sm text-muted-foreground">Selected: {materialFile.name}</p>}
                        </>}
                        {isUploading && <div className="flex items-center gap-2"><div className="w-full h-2 bg-muted rounded-full overflow-hidden"><div className="h-full bg-primary animate-pulse" style={{width: '100%'}}></div></div><span>Processing...</span></div>}
                    </DialogComponent>

                    <DialogComponent open={dialogState.department.open} onOpenChange={() => closeDialog('department')} title={dialogState.department.current ? 'Edit Department' : 'Add Department'} footer={<><Button variant="outline" onClick={() => closeDialog('department')}>Cancel</Button><Button onClick={() => handleSave('department')} disabled={isUploading}>{isUploading ? `Saving...`: 'Save Department'}</Button></>}>
                        <Input placeholder="Department Name" value={dialogState.department.formData.name || ''} onChange={(e) => handleDialogFormChange('department', 'name', e.target.value)}/>
                        <Select onValueChange={(value) => handleDialogFormChange('department', 'institution_id', value)} value={dialogState.department.formData.institution_id || ''}><SelectTrigger><SelectValue placeholder="Select an institution..."/></SelectTrigger><SelectContent>{data.institutions.map(i => <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>)}</SelectContent></Select>
                    </DialogComponent>

                    <DialogComponent open={dialogState.course.open} onOpenChange={() => closeDialog('course')} title={dialogState.course.current ? 'Edit Course' : 'Add Course'} footer={<><Button variant="outline" onClick={() => closeDialog('course')}>Cancel</Button><Button onClick={() => handleSave('course')} disabled={isUploading}>{isUploading ? `Saving...`: 'Save Course'}</Button></>}>
                        <Input placeholder="Course Title" value={dialogState.course.formData.title || ''} onChange={(e) => handleDialogFormChange('course', 'title', e.target.value)}/>
                        <Input placeholder="Course Code" value={dialogState.course.formData.code || ''} onChange={(e) => handleDialogFormChange('course', 'code', e.target.value)}/>
                        <Input placeholder="University" value={dialogState.course.formData.university || ''} onChange={(e) => handleDialogFormChange('course', 'university', e.target.value)}/>
                        <Input placeholder="Subject" value={dialogState.course.formData.subject || ''} onChange={(e) => handleDialogFormChange('course', 'subject', e.target.value)}/>
                        <Textarea placeholder="Description" value={dialogState.course.formData.description || ''} onChange={(e) => handleDialogFormChange('course', 'description', e.target.value)}/>
                    </DialogComponent>
                </div>
            </>
        );
    }

    export default AdminDashboard;
  
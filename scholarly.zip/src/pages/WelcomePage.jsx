import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { PartyPopper, ArrowRight } from 'lucide-react';

const WelcomePage = ({ user, onNavigate }) => {

  useEffect(() => {
    const timer = setTimeout(() => {
      onNavigate(user.role === 'admin' ? 'admin-dashboard' : 'student-dashboard');
    }, 5000); // Auto-redirect after 5 seconds

    return () => clearTimeout(timer);
  }, [onNavigate, user.role]);

  const handleContinue = () => {
    onNavigate(user.role === 'admin' ? 'admin-dashboard' : 'student-dashboard');
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.3, delayChildren: 0.2 }
    }
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 p-6">
      <motion.div 
        className="text-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants}>
          <PartyPopper className="w-24 h-24 text-purple-500 mx-auto mb-8" strokeWidth={1.5} />
        </motion.div>
        
        <motion.h1 
          variants={itemVariants}
          className="text-4xl md:text-6xl font-bold mb-4"
        >
          <span className="gradient-text">Welcome, {user.full_name}!</span>
        </motion.h1>

        <motion.p 
          variants={itemVariants}
          className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto"
        >
          You're all set! Get ready to dive into a world of knowledge. We're preparing your personalized dashboard now.
        </motion.p>
        
        <motion.div variants={itemVariants}>
          <Button 
            size="lg"
            onClick={handleContinue}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg px-10 py-7 rounded-full shadow-lg hover:shadow-2xl transition-all"
          >
            Go to my Dashboard
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default WelcomePage;
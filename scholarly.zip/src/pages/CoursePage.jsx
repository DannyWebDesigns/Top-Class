import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Book, Video, Home, Download, Eye, Loader2, FileText, ChevronLeft, UploadCloud, Sparkles, X, AlertTriangle } from 'lucide-react';
import { getMaterials, getVideos, getSignedUrl, performAIAction } from '@/lib/data';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import PDFViewer from '@/components/PDFViewer';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const StatusBadge = ({ status, isIndexed, className }) => {
    const statusInfo = {
        available: { text: 'Available', color: 'bg-green-100 text-green-800' },
        indexing: { text: 'AI Indexing...', color: 'bg-cyan-100 text-cyan-800 animate-pulse' },
        uploaded: { text: 'Processing...', color: 'bg-blue-100 text-blue-800' },
        pending: { text: 'Pending...', color: 'bg-yellow-100 text-yellow-800' },
        error: { text: 'Error', color: 'bg-red-100 text-red-800' },
    };
    const currentStatus = statusInfo[status] || { text: 'Unknown', color: 'bg-gray-100 text-gray-800' };
    return (
      <div className="flex items-center gap-2">
        <span className={`px-2 py-1 text-xs font-medium rounded-full ${currentStatus.color} ${className}`}>{currentStatus.text}</span>
        {isIndexed && <Sparkles className="h-4 w-4 text-purple-500" title="AI Chat Enabled" />}
      </div>
    );
};

const MaterialItem = ({ material, onSelect, onDownload, canUseAI }) => (
    <Card className="hover:shadow-lg transition-shadow duration-300 group">
        <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-4 flex-1 overflow-hidden">
                <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <FileText className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1 overflow-hidden">
                    <h3 className="font-semibold truncate">{material.title}</h3>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <StatusBadge status={material.status} isIndexed={material.is_indexed_for_ai} />
                        {material.file_size_mb && <span>• {Number(material.file_size_mb).toFixed(2)} MB</span>}
                    </div>
                </div>
            </div>
            <div className="flex items-center gap-2 ml-4">
                <Button variant="default" size="sm" onClick={() => onSelect(material)} disabled={material.status !== 'available'}>
                    {canUseAI ? <Sparkles className="h-4 w-4 mr-1.5"/> : <Eye className="h-4 w-4 mr-1.5" />}
                    View
                </Button>
                <Button variant="ghost" size="icon" onClick={() => onDownload(material)} disabled={material.status !== 'available'}>
                    <Download className="h-5 w-5 text-primary" />
                </Button>
            </div>
        </CardContent>
    </Card>
);

const SummaryModal = ({ material, onOpenReader, onBack, summary, keyPoints, isLoading, error }) => (
    <Dialog open={true} onOpenChange={onBack}>
        <DialogContent className="max-w-2xl bg-background/95 backdrop-blur-sm border-primary/20">
            <DialogHeader>
                <DialogTitle className="text-2xl font-bold flex items-center gap-2"><Sparkles className="text-primary"/>AI Summary</DialogTitle>
                <DialogDescription>A quick overview of "{material.title}"</DialogDescription>
            </DialogHeader>
            {isLoading && <div className="flex flex-col items-center justify-center h-64"><Loader2 className="h-10 w-10 animate-spin text-primary mb-4" /><p className="text-muted-foreground">Generating summary... this can take a moment.</p></div>}
            {error && <div className="text-destructive-foreground bg-destructive/10 p-4 rounded-md text-center border border-destructive/20"><AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" /><h3 className="font-semibold text-destructive mb-1">AI Summary Failed</h3><p className="text-sm">{error}</p></div>}
            {!isLoading && !error && summary && (
                <div className="space-y-4 max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
                    <div>
                        <h3 className="font-semibold mb-2 text-lg">Summary</h3>
                        <p className="text-muted-foreground">{summary}</p>
                    </div>
                    <div>
                        <h3 className="font-semibold mb-2 text-lg">Key Points</h3>
                        <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                            {keyPoints.map((point, index) => <li key={index}>{point}</li>)}
                        </ul>
                    </div>
                </div>
            )}
            <DialogFooter>
                <Button variant="outline" onClick={onBack}>Back to Course</Button>
                <Button onClick={onOpenReader} >Open Full Document</Button>
            </DialogFooter>
        </DialogContent>
    </Dialog>
);


function CoursePage({ course, user, onNavigate }) {
  const { toast } = useToast();
  const [materials, setMaterials] = useState([]);
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [viewState, setViewState] = useState('list'); // 'list', 'reader'

  const loadData = useCallback(async () => {
    if (!course?.id) return;
    setLoading(true);
    try {
      const [materialsData, videosData] = await Promise.all([ getMaterials(course.id), getVideos(course.id) ]);
      setMaterials(materialsData.filter(m => m.status !== 'pending' && m.status !== 'error') || []);
      setVideos(videosData || []);
    } catch (error) {
      toast({ title: 'Error loading course content', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [course?.id, toast]);
  
  useEffect(() => {
    loadData();
    if (!course?.id) return;
    const channel = supabase.channel(`course-page-${course.id}`).on('postgres_changes', { event: '*', schema: 'public' }, loadData).subscribe();
    return () => supabase.removeChannel(channel);
  }, [course?.id, loadData]);

  const handleSelectMaterial = (material) => {
    setSelectedMaterial(material);
    setViewState('reader');
  };

  const handleDownload = async (material) => {
    if (!user.can_download) {
        toast({ title: "Permission Denied", description: "You don't have permission to download materials.", variant: "destructive" });
        return;
    }
    if (!material.storage_path) {
        toast({ title: "Download Failed", description: "File path is missing.", variant: "destructive" });
        return;
    }
    try {
        const url = await getSignedUrl(material.storage_path);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', material.title || 'download');
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
    } catch (error) {
        toast({ title: "Download Error", description: error.message, variant: "destructive" });
    }
  };

  const resetViews = () => {
    setSelectedMaterial(null);
    setViewState('list');
  };
  
  if (viewState === 'reader' && selectedMaterial) {
      return (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="w-full h-full p-2 sm:p-4">
                <PDFViewer material={selectedMaterial} onBack={resetViews} />
            </motion.div>
        </div>
      );
  }

  return (
    <>
      <Helmet>
        <title>{course.title} - Scholarly</title>
        <meta name="description" content={`Study materials and videos for ${course.title}.`} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <header className="py-6 container mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex justify-between items-center">
                <Button variant="ghost" onClick={() => onNavigate('student-dashboard')} className="flex items-center gap-2"><ChevronLeft className="h-5 w-5" /> Back to Courses</Button>
                <Button variant="ghost" onClick={() => onNavigate('home')}><Home className="h-5 w-5" /></Button>
            </motion.div>
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-4">
                <h1 className="text-4xl font-bold tracking-tight">{course.title}</h1>
                <p className="text-muted-foreground mt-2">{course.code} • {course.university}</p>
                <p className="mt-4 text-sm max-w-2xl">{course.description}</p>
            </motion.div>
        </header>

        <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Tabs defaultValue="materials" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6"><TabsTrigger value="materials"><Book className="mr-2 h-4 w-4" />Study Materials ({materials.length})</TabsTrigger><TabsTrigger value="videos"><Video className="mr-2 h-4 w-4" />Video Lectures ({videos.length})</TabsTrigger></TabsList>
            <TabsContent value="materials">
              {loading ? ( <div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin text-primary"/></div> ) : 
              materials.length > 0 ? (
                <motion.div className="grid grid-cols-1 md:grid-cols-2 gap-4" variants={{ hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.05 } }}} initial="hidden" animate="show">
                  {materials.map(material => (
                    <motion.div key={material.id} variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}>
                      <MaterialItem material={material} onSelect={handleSelectMaterial} onDownload={handleDownload} canUseAI={user.can_use_ai} />
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <Card className="text-center p-12 border-dashed"><UploadCloud className="mx-auto h-12 w-12 text-gray-400" /><h3 className="mt-4 text-lg font-semibold">No materials yet</h3><p className="mt-1 text-sm text-muted-foreground">Check back later or ask an admin to upload materials for this course.</p></Card>
              )}
            </TabsContent>
            <TabsContent value="videos">
               {loading ? ( <div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin text-primary"/></div> ) : 
               videos.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {videos.map(video => (
                    <motion.a href={video.youtube_url} target="_blank" rel="noopener noreferrer" key={video.id} className="block" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                      <Card className="overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all"><div className="aspect-video bg-gray-200 flex items-center justify-center"><Video className="w-12 h-12 text-gray-400"/></div><CardContent className="p-4"><h3 className="font-semibold truncate">{video.title}</h3><p className="text-xs text-muted-foreground">{video.duration || "Video"}</p></CardContent></Card>
                    </motion.a>
                  ))}
                </div>
              ) : (
                <Card className="text-center p-12 border-dashed"><Video className="mx-auto h-12 w-12 text-gray-400" /><h3 className="mt-4 text-lg font-semibold">No videos yet</h3><p className="mt-1 text-sm text-muted-foreground">Check back later for video lectures.</p></Card>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </>
  );
}

export default CoursePage;
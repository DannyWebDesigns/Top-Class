import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import Logo from '@/components/Logo';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const SignupPage = ({ onNavigate }) => {
  const { toast } = useToast();
  const { signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [university, setUniversity] = useState('');
  const [studentId, setStudentId] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const role = email === 'scholarly@gmail.com' ? 'admin' : 'student';

    const { data, error } = await signUp(email, password, {
      data: {
        full_name: fullName,
        university,
        student_id: studentId,
        role: role,
      },
    });

    setIsLoading(false);

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Signup failed',
        description: error.message,
      });
    } else if (data.user) {
      toast({
        title: 'Success! ✅',
        description: 'Your account has been created.',
      });
      onNavigate('welcome');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-secondary/50 p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <Logo className="justify-center" />
          <h1 className="text-3xl font-bold mt-4 gradient-text">Create Your Account</h1>
          <p className="text-gray-600">Join the community of learners.</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-4 bg-white p-8 rounded-2xl shadow-lg border"
        >
          <div>
            <Label htmlFor="fullName">Full Name</Label>
            <Input
              id="fullName"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g., Ada Lovelace"
              required
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              required
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              minLength="6"
              className="mt-1"
            />
          </div>
          <div>
            <Label>University</Label>
            <Select onValueChange={setUniversity} value={university}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select your university" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="UNILAG">University of Lagos</SelectItem>
                <SelectItem value="LASU">Lagos State University</SelectItem>
                <SelectItem value="YABATECH">Yaba College of Technology</SelectItem>
                <SelectItem value="LASPOTECH">Lagos State Polytechnic</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="studentId">Student ID (Optional)</Label>
            <Input
              id="studentId"
              type="text"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              placeholder="e.g., 180404001"
              className="mt-1"
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600"
            disabled={isLoading}
          >
            {isLoading ? 'Creating Account...' : 'Sign Up'}
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-600">
          Already have an account?{' '}
          <span
            onClick={() => onNavigate('login')}
            className="font-semibold text-purple-600 hover:underline cursor-pointer"
          >
            Log in
          </span>
        </p>
      </motion.div>
    </div>
  );
};

export default SignupPage;
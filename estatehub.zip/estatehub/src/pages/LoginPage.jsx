import React, { useState } from 'react';
    import { Link, useNavigate, useSearchParams } from 'react-router-dom';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { Eye, EyeOff, Loader2 } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import EHLogo from '@/components/EHLogo';

    const LoginPage = () => {
      const [formData, setFormData] = useState({ email: '', password: '' });
      const [focused, setFocused] = useState({ email: false, password: false });
      const [showPassword, setShowPassword] = useState(false);
      const [loading, setLoading] = useState(false);
      
      const { loginUser } = useAuth();
      const { toast } = useToast();
      const navigate = useNavigate();
      const [searchParams] = useSearchParams();
      const nextPath = searchParams.get('next');

      const handleFocus = (e) => setFocused({ ...focused, [e.target.name]: true });
      const handleBlur = (e) => setFocused({ ...focused, [e.target.name]: false });

      const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
          const profile = await loginUser(formData.email, formData.password);

          toast({ title: "Welcome back!", description: `Successfully signed in. 🎉` });

          if (nextPath) {
            navigate(nextPath, { replace: true });
            return;
          }
          
          if (profile.role === 'admin') {
            navigate('/admin');
          } else if (profile.role === 'agent') {
            navigate('/agent-dashboard');
          } else if (profile.role === 'client') {
            navigate('/client-dashboard');
          } else {
            navigate('/');
          }

        } catch (error) {
          toast({ title: "Login failed", description: error.message, variant: "destructive" });
        } finally {
          setLoading(false);
        }
      };

      const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
      };

      return (
        <>
          <Helmet><title>Login - EstateHub</title></Helmet>
          <div className="min-h-screen flex items-center justify-center p-4 bg-secondary/30 relative overflow-hidden">
            <motion.div initial={{ scale: 1.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1, ease: "circOut" }} className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-primary/10 rounded-full blur-3xl"></motion.div>
            <motion.div initial={{ scale: 1.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1, ease: "circOut", delay: 0.2 }} className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/20 rounded-full blur-3xl"></motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="w-full max-w-md z-10">
              <div className="text-center mb-8">
                <Link to="/" className="inline-flex items-center space-x-3 mb-6">
                  <EHLogo className="h-10 w-10" />
                  <span className="text-2xl font-bold">EstateHub</span>
                </Link>
                <h1 className="text-3xl font-bold mb-2">Welcome Back</h1>
                <p className="text-muted-foreground">Sign in to your account to continue.</p>
              </div>

              <Card className="bg-card/80 backdrop-blur-lg border">
                <CardHeader>
                  <CardTitle>Sign In</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="relative">
                      <Label htmlFor="email" className={`floating-label ${focused.email || formData.email ? 'floating-label-active' : ''}`}>Email Address</Label>
                      <Input id="email" name="email" type="email" required value={formData.email} onChange={handleChange} onFocus={handleFocus} onBlur={handleBlur} className="h-12 bg-transparent" autoComplete="email"/>
                    </div>
                    <div className="relative">
                      <Label htmlFor="password" className={`floating-label ${focused.password || formData.password ? 'floating-label-active' : ''}`}>Password</Label>
                      <Input id="password" name="password" type={showPassword ? 'text' : 'password'} required value={formData.password} onChange={handleChange} onFocus={handleFocus} onBlur={handleBlur} className="h-12 bg-transparent" autoComplete="current-password" />
                      <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                        {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                     <div className="text-right text-sm">
                        <Link to="/reset-password" tabIndex={-1} className="text-primary hover:underline font-medium">Forgot Password?</Link>
                    </div>
                    <Button type="submit" className="w-full h-12 text-base" disabled={loading}>
                      {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Sign In'}
                    </Button>
                  </form>
                  <div className="mt-6 text-center text-sm">
                    <p className="text-muted-foreground">Don't have an account? <Link to="/register" className="text-primary hover:underline font-medium">Sign up here</Link></p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </>
      );
    };

    export default LoginPage;
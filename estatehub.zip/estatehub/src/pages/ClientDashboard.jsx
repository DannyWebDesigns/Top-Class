
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import PaystackPop from '@paystack/inline-js';
import { MessageSquare, LifeBuoy, Loader2, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import SupportTicketDialog from '@/components/SupportTicketDialog.jsx';
import ProfileCard from '@/components/client-dashboard/ProfileCard';
import SupportCard from '@/components/client-dashboard/SupportCard';
import MyProperties from '@/components/client-dashboard/MyProperties';
import RecentTransactions from '@/components/client-dashboard/RecentTransactions';
import LiveAgentListings from '@/components/client-dashboard/LiveAgentListings';
import FeaturedListings from '@/components/client-dashboard/FeaturedListings';
import { cn } from '@/lib/utils';

const ClientDashboard = () => {
  const { user, profile, loading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [myProperties, setMyProperties] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [liveAgents, setLiveAgents] = useState([]);
  const [featuredListings, setFeaturedListings] = useState([]);
  const [featuredError, setFeaturedError] = useState(null);
  const [isProcessing, setIsProcessing] = useState(null);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [currentTransaction, setCurrentTransaction] = useState(null);
  const [paystackPublicKey, setPaystackPublicKey] = useState('');
  const [isSupportDialogOpen, setIsSupportDialogOpen] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [notifications, setNotifications] = useState([]);

  const loadData = useCallback(async (currentUserId) => {
    if (!currentUserId) return;
    setIsLoadingData(true);
    setFeaturedError(null);
    try {
      const [clientPropsRes, transactionsRes, liveAgentsRes, featuredListingsRes, notificationsRes] = await Promise.all([
        supabase.from('client_properties').select('*, listing:listing_id(*, agent:agent_id(*))').eq('client_id', currentUserId),
        supabase.from('transactions').select('*, listing:listing_id(title, images), payment:payments(*)').eq('client_id', currentUserId).order('created_at', { ascending: false }),
        supabase.from('profiles').select('*').eq('role', 'agent').eq('status', 'approved').limit(4),
        supabase.rpc('get_featured_listings', { p_limit: 2 }),
        supabase.from('notifications').select('*').eq('target_user_id', currentUserId).order('created_at', { ascending: false })
      ]);

      if (clientPropsRes.error) throw clientPropsRes.error;
      setMyProperties(clientPropsRes.data);

      if (transactionsRes.error) throw transactionsRes.error;
      setTransactions(transactionsRes.data);
      
      if (liveAgentsRes.error) throw liveAgentsRes.error;
      setLiveAgents(liveAgentsRes.data);
      
      if (featuredListingsRes.error) {
        setFeaturedError(featuredListingsRes.error.message);
        setFeaturedListings([]);
      } else {
        const listingsWithProfiles = await Promise.all(featuredListingsRes.data.map(async l => {
            const { data: profileData } = await supabase.from('profiles').select('*').eq('id', l.agent_id).single();
            return { ...l, profiles: profileData };
        }));
        setFeaturedListings(listingsWithProfiles);
      }

      if (notificationsRes.error) throw notificationsRes.error;
      setNotifications(notificationsRes.data);

    } catch (error) {
      toast({ title: "Error loading dashboard data", description: error.message, variant: "destructive" });
    } finally {
      setIsLoadingData(false);
    }
  }, [toast]);

  useEffect(() => {
    const fetchPaystackKey = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('get-paystack-public-key');
        if (error) throw error;
        if (data?.publicKey) setPaystackPublicKey(data.publicKey);
      } catch (error) {
        toast({ title: "Could not load payment provider", description: "Please contact support.", variant: "destructive" });
      }
    };
    fetchPaystackKey();
  }, [toast]);

  useEffect(() => {
    if (user?.id) {
      loadData(user.id);
    }
  }, [user, loadData]);

  useEffect(() => {
    if (!user?.id) return;
    const channel = supabase.channel(`client-dashboard-changes-${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', filter: `target_user_id=eq.${user.id}` }, (payload) => {
        if (payload.table === 'notifications') {
             setNotifications(current => [payload.new, ...current]);
             toast({ title: payload.new.payload?.title || 'New Notification', description: payload.new.payload?.message });
        } else {
             loadData(user.id);
        }
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'transactions', filter: `client_id=eq.${user.id}` }, () => loadData(user.id))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'client_properties', filter: `client_id=eq.${user.id}` }, () => loadData(user.id))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payments', filter: `user_id=eq.${user.id}` }, () => loadData(user.id))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'listings' }, () => loadData(user.id))
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [user, loadData, toast]);

  const handleMarkAsRead = async (notificationId) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', notificationId);
    setNotifications(current => current.map(n => n.id === notificationId ? { ...n, is_read: true } : n));
  };
  const unreadNotifications = notifications.filter(n => !n.is_read).length;


  const handlePay = async (transaction) => {
    setIsProcessing(transaction.id);

    try {
      const { data: confirmData, error: confirmError } = await supabase.rpc('client_confirm_transaction', { p_transaction_id: transaction.id });
      if (confirmError) throw confirmError;

      if (!paystackPublicKey) {
        toast({ title: 'Error', description: 'Payment provider not configured. Please contact support.', variant: 'destructive' });
        setIsProcessing(null);
        return;
      }
      
      const paystack = new PaystackPop();
      paystack.newTransaction({
        key: paystackPublicKey,
        email: user.email,
        amount: transaction.amount * 100,
        ref: transaction.id,
        metadata: {
          transaction_id: transaction.id,
          client_id: user.id,
          listing_id: transaction.listing_id,
        },
        onSuccess: () => {
          toast({ title: 'Payment Initiated!', description: 'Your payment is being verified. Your dashboard will update shortly.' });
        },
        onCancel: () => {
          toast({ title: 'Payment Canceled', description: 'You can try again anytime.' });
        },
        onClose: () => {
          setIsProcessing(null);
          loadData(user.id);
        },
      });
    } catch (error) {
      toast({ title: "Payment Initialization Failed", description: error.message, variant: "destructive" });
      setIsProcessing(null);
    }
  };

  const handleReject = async () => {
    if (!currentTransaction) return;
    setIsProcessing(currentTransaction.id);
    try {
      const { error } = await supabase.functions.invoke('client-reject-transaction', { body: { transaction_id: currentTransaction.id, reason: rejectionReason } });
      if (error) throw error;
      toast({ title: "Transaction Rejected", description: "The agent and admin have been notified." });
      loadData(user?.id);
    } catch (error) {
      toast({ title: "Action Failed", description: error.message, variant: "destructive" });
    } finally {
      setIsProcessing(null);
      setShowRejectModal(false);
      setRejectionReason('');
      setCurrentTransaction(null);
    }
  }

  const getGreeting = () => {
    if (loading) return 'Loading...';
    return !profile?.full_name ? 'Welcome!' : `Welcome back, ${profile.full_name.split(' ')[0]}!`;
  }

  return (
    <>
      <Helmet>
        <title>Client Dashboard - EstateHub</title>
        <meta name="description" content="Manage your properties, transactions, and support requests on EstateHub." />
      </Helmet>
      <div className="min-h-screen bg-secondary/50">
        <Navbar />
        <main className="container mx-auto px-4 py-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-1">{getGreeting()}</h1>
                <p className="text-muted-foreground">Here's what's happening with your account today.</p>
              </div>
              <div className="flex items-center gap-2 mt-4 sm:mt-0">
                 <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="outline" size="icon" className="relative">
                            <Bell className="h-5 w-5" />
                            {unreadNotifications > 0 && <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-red-500 flex items-center justify-center text-xs text-white">{unreadNotifications}</span>}
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-80"><div className="p-2"><h4 className="font-medium text-sm mb-2">Notifications</h4><div className="space-y-2 max-h-64 overflow-y-auto">
                        {notifications.length > 0 ? notifications.map(n => (
                            <div key={n.id} className="text-sm p-2 rounded-lg hover:bg-secondary"><p className={cn("font-semibold", !n.is_read && "text-foreground")}>{n.payload?.title || n.kind}</p><p className={cn("text-xs", n.is_read ? "text-muted-foreground" : "text-foreground/80")}>{n.payload?.message}</p>
                                {!n.is_read && <Button variant="link" size="sm" className="h-auto p-0 mt-1 text-xs" onClick={() => handleMarkAsRead(n.id)}>Mark as read</Button>}
                            </div>
                        )) : <p className="text-sm text-muted-foreground text-center py-4">No new notifications.</p>}
                    </div></div></PopoverContent>
                </Popover>
                <Button variant="outline" onClick={() => navigate('/messages')}>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Contact Agent
                </Button>
                <Button onClick={() => setIsSupportDialogOpen(true)}>
                  <LifeBuoy className="mr-2 h-4 w-4" />
                  Support
                </Button>
              </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <RecentTransactions transactions={transactions} onPay={handlePay} onReject={(tx) => { setCurrentTransaction(tx); setShowRejectModal(true); }} isProcessing={isProcessing} />
                <MyProperties properties={myProperties} isLoading={isLoadingData} />
                <FeaturedListings listings={featuredListings} isLoading={isLoadingData} error={featuredError} />
                <LiveAgentListings agents={liveAgents} isLoading={isLoadingData} />
              </div>
              <div className="space-y-8">
                <ProfileCard profile={profile} loading={loading} />
                <SupportCard onContactAgent={() => navigate('/messages')} onGetSupport={() => setIsSupportDialogOpen(true)} />
              </div>
            </div>
          </motion.div>
        </main>
      </div>
      <Dialog open={showRejectModal} onOpenChange={() => { setShowRejectModal(false); setCurrentTransaction(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Transaction</DialogTitle>
            <DialogDescription>Are you sure you want to reject this transaction? This action cannot be undone. Please provide a reason (optional).</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="rejectionReason">Reason for Rejection</Label>
            <Textarea id="rejectionReason" value={rejectionReason} onChange={(e) => setRejectionReason(e.target.value)} placeholder="e.g., The price is incorrect, I changed my mind..." />
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => { setShowRejectModal(false); setCurrentTransaction(null); }}>Cancel</Button>
            <Button variant="destructive" onClick={handleReject} disabled={isProcessing === currentTransaction?.id}>
              {isProcessing === currentTransaction?.id && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Rejection
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <SupportTicketDialog open={isSupportDialogOpen} onOpenChange={setIsSupportDialogOpen} />
    </>
  );
};

export default ClientDashboard;

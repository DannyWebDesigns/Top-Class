import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search, Filter, Users, Award, Star, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import Navbar from '@/components/Navbar';
import AgentCard from '@/components/AgentCard';
import { supabase } from '@/lib/customSupabaseClient';

const AgentsPage = () => {
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    experience: 'all',
    sortBy: 'name'
  });

  useEffect(() => {
    const loadAgents = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'agent')
        .eq('status', 'approved');
      
      if (error) {
        console.error("Error fetching agents:", error);
      } else {
        setAgents(data);
      }
      setLoading(false);
    };
    loadAgents();
  }, []);

  const filteredAgents = useMemo(() => {
    let filtered = agents;

    if (searchTerm) {
      filtered = filtered.filter(agent =>
        agent.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (agent.license_number && agent.license_number.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (filters.experience !== 'all') {
      const minExperience = parseInt(filters.experience);
      filtered = filtered.filter(agent => agent.years_of_experience >= minExperience);
    }

    filtered.sort((a, b) => {
      switch (filters.sortBy) {
        case 'experience':
          return b.years_of_experience - a.years_of_experience;
        case 'name':
        default:
          return a.full_name.localeCompare(b.full_name);
      }
    });

    return filtered;
  }, [agents, searchTerm, filters]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({ experience: 'all', sortBy: 'name' });
    setSearchTerm('');
  };

  return (
    <>
      <Helmet>
        <title>Real Estate Agents - EstateHub</title>
        <meta name="description" content="Connect with experienced and licensed real estate agents. Find the perfect agent to help you buy or sell your property." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-8 text-center">
              <h1 className="text-4xl font-bold text-foreground mb-2">Meet Our Agents</h1>
              <p className="text-muted-foreground">Connect with experienced professionals who will guide you every step of the way</p>
            </div>

            <Card className="mb-8 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                    <Input
                      placeholder="Search agents by name or license number..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 h-11"
                    />
                  </div>
                  <Button
                    onClick={() => setShowFilters(!showFilters)}
                    variant="outline"
                    className="h-11"
                  >
                    <Filter className="h-5 w-5 mr-2" />
                    Filters
                  </Button>
                </div>

                {showFilters && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6 pt-6 border-t"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Minimum Experience</label>
                        <select
                          value={filters.experience}
                          onChange={(e) => handleFilterChange('experience', e.target.value)}
                          className="w-full h-10 px-3 rounded-md bg-input border"
                        >
                          <option value="all">Any Experience</option>
                          <option value="1">1+ Years</option>
                          <option value="3">3+ Years</option>
                          <option value="5">5+ Years</option>
                          <option value="10">10+ Years</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Sort By</label>
                        <select
                          value={filters.sortBy}
                          onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                          className="w-full h-10 px-3 rounded-md bg-input border"
                        >
                          <option value="name">Name</option>
                          <option value="experience">Experience</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex justify-end mt-4">
                      <Button onClick={clearFilters} variant="ghost">Clear Filters</Button>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>

            <div className="flex items-center justify-between mb-6">
              <p className="text-muted-foreground">
                Showing {filteredAgents.length} of {agents.length} agents
              </p>
            </div>

            {loading ? (
              <div className="flex justify-center items-center py-16">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
              </div>
            ) : filteredAgents.length === 0 ? (
              <div className="text-center py-16">
                <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-foreground mb-2">No agents found</h3>
                <p className="text-muted-foreground mb-6">Try adjusting your search criteria or filters</p>
                <Button onClick={clearFilters}>Clear All Filters</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredAgents.map((agent, index) => (
                  <AgentCard key={agent.id} agent={agent} index={index} />
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default AgentsPage;
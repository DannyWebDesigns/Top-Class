import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowLeft, Send, Phone, Video, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const ChatPage = () => {
  const { agentId } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const [agent, setAgent] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadAgent();
    loadMessages();
  }, [agentId, user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadAgent = () => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundAgent = users.find(u => u.id === agentId && u.role === 'agent');
    setAgent(foundAgent);
  };

  const loadMessages = () => {
    if (!user) return;
    const chatKey = `chat_${user.id}_${agentId}`;
    const savedMessages = JSON.parse(localStorage.getItem(chatKey) || '[]');
    setMessages(savedMessages);
  };

  const saveMessages = (updatedMessages) => {
    if (!user) return;
    const chatKey = `chat_${user.id}_${agentId}`;
    localStorage.setItem(chatKey, JSON.stringify(updatedMessages));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !user) return;

    const message = {
      id: Date.now().toString(),
      text: newMessage,
      senderId: user.id,
      senderName: user.fullName,
      timestamp: new Date().toISOString(),
      isFromCurrentUser: true
    };

    const updatedMessages = [...messages, message];
    setMessages(updatedMessages);
    saveMessages(updatedMessages);
    setNewMessage('');

    setTimeout(() => {
      const agentResponse = {
        id: (Date.now() + 1).toString(),
        text: "Thank you for your message! I'll get back to you shortly with more information about the property.",
        senderId: agentId,
        senderName: agent?.fullName || 'Agent',
        timestamp: new Date().toISOString(),
        isFromCurrentUser: false
      };

      const messagesWithResponse = [...updatedMessages, agentResponse];
      setMessages(messagesWithResponse);
      saveMessages(messagesWithResponse);
    }, 2000);
  };

  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h2 className="text-2xl font-semibold text-foreground mb-2">Please log in</h2>
            <p className="text-muted-foreground mb-6">You need to be logged in to chat with agents.</p>
            <Button asChild><Link to="/login">Login</Link></Button>
          </div>
        </div>
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h2 className="text-2xl font-semibold text-foreground mb-2">Agent not found</h2>
            <p className="text-muted-foreground mb-6">The agent you're trying to chat with doesn't exist.</p>
            <Button asChild><Link to="/agents">Browse Agents</Link></Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Chat with {agent.fullName} - EstateHub</title>
        <meta name="description" content={`Chat directly with ${agent.fullName} about your real estate needs.`} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <Button asChild variant="ghost" className="mb-6 text-muted-foreground hover:text-foreground">
              <Link to={`/agent/${agentId}`}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Agent Profile
              </Link>
            </Button>

            <Card className="bg-card border-border h-[600px] flex flex-col">
              <CardHeader className="border-b border-border p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={agent.profilePicture} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {agent.fullName?.charAt(0).toUpperCase() || 'A'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="font-semibold text-foreground">{agent.fullName}</h2>
                      <p className="text-sm text-muted-foreground">Licensed Agent • Online</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground" onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })}><Phone className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground" onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })}><Video className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-foreground" onClick={() => toast({ title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" })}><MoreVertical className="h-4 w-4" /></Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="flex-1 p-4 overflow-y-auto custom-scrollbar">
                <div className="space-y-4">
                  {messages.length === 0 ? (
                    <div className="text-center py-8">
                      <Avatar className="h-16 w-16 mx-auto mb-4"><AvatarImage src={agent.profilePicture} /><AvatarFallback className="bg-primary text-primary-foreground text-xl">{agent.fullName?.charAt(0).toUpperCase() || 'A'}</AvatarFallback></Avatar>
                      <h3 className="text-lg font-semibold text-foreground mb-2">Start a conversation</h3>
                      <p className="text-muted-foreground text-sm">Send a message to {agent.fullName} to get started.</p>
                    </div>
                  ) : (
                    messages.map((message) => (
                      <div key={message.id} className={`flex ${message.isFromCurrentUser ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs lg:max-w-md ${message.isFromCurrentUser ? 'chat-bubble chat-bubble-sent' : 'chat-bubble chat-bubble-received'}`}>
                          <p className="text-sm">{message.text}</p>
                          <p className={`text-xs mt-1 ${message.isFromCurrentUser ? 'text-cyan-100/70' : 'text-muted-foreground'}`}>{formatTime(message.timestamp)}</p>
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </CardContent>

              <div className="border-t border-border p-4">
                <form onSubmit={handleSendMessage} className="flex space-x-2">
                  <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type your message..." className="flex-1 bg-input border-border text-foreground placeholder:text-muted-foreground" />
                  <Button type="submit" disabled={!newMessage.trim()}><Send className="h-4 w-4" /></Button>
                </form>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default ChatPage;
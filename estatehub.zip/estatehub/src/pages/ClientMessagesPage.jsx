import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MessageCircle, Send, Search, ArrowLeft, Paperclip, X, Loader2, Image as ImageIcon, File as FileIcon, Check, CheckCheck, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';
import { useDropzone } from 'react-dropzone';

const TypingIndicator = () => (
    <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-1.5 pl-4 pb-2"
    >
        <span className="text-sm text-muted-foreground italic">typing</span>
        <motion.div
            className="w-1.5 h-1.5 bg-muted-foreground rounded-full"
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 0.8, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
            className="w-1.5 h-1.5 bg-muted-foreground rounded-full"
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 0.8, repeat: Infinity, ease: 'easeInOut', delay: 0.1 }}
        />
        <motion.div
            className="w-1.5 h-1.5 bg-muted-foreground rounded-full"
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 0.8, repeat: Infinity, ease: 'easeInOut', delay: 0.2 }}
        />
    </motion.div>
);

const ClientMessagesPage = () => {
  const { user } = useAuth();
  const { agentId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const typingTimeoutRef = useRef(null);
  const messagesEndRef = useRef(null);
  
  const onDrop = useCallback(acceptedFiles => {
    if (acceptedFiles.length > 0) {
      setAttachment(acceptedFiles[0]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    noClick: true,
    noKeyboard: true,
    multiple: false,
  });

  const fetchConversations = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase.rpc('get_client_conversations');
    if (error) {
      toast({ title: "Error fetching conversations", description: error.message, variant: "destructive" });
    } else {
      setConversations(data);
      if (agentId && data.some(c => c.agent_id === agentId)) {
        setActiveConversation(data.find(c => c.agent_id === agentId));
      } else if (agentId) {
        const { data: agentProfile, error: profileError } = await supabase
          .from('profiles').select('id, full_name, avatar_url').eq('id', agentId).single();
        
        if (profileError) {
          toast({ title: "Error", description: "Could not find agent.", variant: "destructive" });
          navigate('/messages');
        } else {
            const newConvo = { agent_id: agentProfile.id, full_name: agentProfile.full_name, avatar_url: agentProfile.avatar_url, last_message: 'Start a new conversation!', last_message_time: new Date().toISOString() };
            setConversations(prev => [newConvo, ...prev.filter(c => c.agent_id !== agentId)]);
            setActiveConversation(newConvo);
        }
      } else if (data.length > 0 && !activeConversation) {
        setActiveConversation(data[0]);
      }
    }
  }, [user, toast, agentId, navigate, activeConversation]);

  const fetchMessages = useCallback(async () => {
    if (!activeConversation || !user) { setMessages([]); return; }
    
    const { data, error } = await supabase.from('chat_messages').select('*').or(`and(sender_id.eq.${user.id},receiver_id.eq.${activeConversation.agent_id}),and(sender_id.eq.${activeConversation.agent_id},receiver_id.eq.${user.id})`).order('created_at', { ascending: true });
    if (error) {
      toast({ title: "Error fetching messages", description: error.message, variant: "destructive" });
    } else {
      setMessages(data);
      const unreadIds = data.filter(m => !m.is_read && m.receiver_id === user.id).map(m => m.id);
      if (unreadIds.length > 0) {
        await supabase.from('chat_messages').update({ is_read: true }).in('id', unreadIds);
      }
    }
  }, [activeConversation, user, toast]);

  useEffect(() => { fetchConversations(); }, [fetchConversations]);
  useEffect(() => { fetchMessages(); }, [fetchMessages]);
  
  useEffect(() => {
    if (!activeConversation || !user) return;
    const channel = supabase.channel(`chat-${user.id}-${activeConversation.agent_id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' }, (payload) => {
          if((payload.new.receiver_id === user.id && payload.new.sender_id === activeConversation.agent_id) || (payload.new.sender_id === user.id && payload.new.receiver_id === activeConversation.agent_id)) {
            setMessages(current => [...current, payload.new]);
            if (payload.new.receiver_id === user.id) {
                supabase.from('chat_messages').update({ is_read: true }).eq('id', payload.new.id).then();
            }
          }
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chat_messages', filter: `receiver_id=eq.${user.id}`}, (payload) => {
        setMessages(current => current.map(m => m.id === payload.new.id ? payload.new : m));
      })
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        if (payload.senderId === activeConversation.agent_id) {
          setIsTyping(true);
          if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
          typingTimeoutRef.current = setTimeout(() => setIsTyping(false), 2000);
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); if(typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current); };
  }, [activeConversation, user]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleTyping = async () => {
    const channel = supabase.channel(`chat-${user.id}-${activeConversation.agent_id}`);
    await channel.send({ type: 'broadcast', event: 'typing', payload: { senderId: user.id } });
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if ((!newMessage.trim() && !attachment) || !activeConversation || !user) return;
    setIsSending(true);
    setUploadProgress(0);

    let mediaUrl = null;
    let mediaType = null;

    if (attachment) {
      const fileExt = attachment.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage.from('chat-attachments').upload(fileName, attachment, {
          cacheControl: '3600',
          upsert: false
        }, (event) => {
          if (event.type === 'progress') {
            setUploadProgress(Math.round((event.loaded / event.total) * 100));
          }
        });

      if (uploadError) {
        toast({ title: "Upload Failed", description: uploadError.message, variant: "destructive" });
        setIsSending(false);
        setAttachment(null);
        return;
      }
      
      const { data: urlData } = supabase.storage.from('chat-attachments').getPublicUrl(fileName);
      mediaUrl = urlData.publicUrl;
      mediaType = attachment.type.startsWith('image/') ? 'image' : 'file';
    }

    const { error } = await supabase.from('chat_messages').insert({ sender_id: user.id, receiver_id: activeConversation.agent_id, message: newMessage, media_url: mediaUrl, media_type: mediaType });
    if (error) { toast({ title: "Failed to send message", description: error.message, variant: "destructive" }); } 
    else { setNewMessage(''); setAttachment(null); fetchConversations(); }
    setIsSending(false);
  };

  if (!user) return <div className="p-8 text-center">Please login to view messages.</div>;

  return (
    <div {...getRootProps()} className={cn("min-h-screen bg-background flex flex-col outline-none", isDragActive && "bg-primary/10")}>
      <Helmet><title>My Messages - EstateHub</title></Helmet>
      <Navbar />
      <div className="container mx-auto px-4 py-8 flex-grow">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
          <Card className="h-[calc(100vh-150px)] flex">
            <div className={cn("w-full sm:w-1/3 border-r flex-col", activeConversation && "hidden sm:flex")}>
              <CardHeader><CardTitle>Conversations</CardTitle><CardDescription>Your chats with agents.</CardDescription></CardHeader>
              <div className="flex-1 overflow-y-auto custom-scrollbar">
                {conversations.map(c => <div key={c.agent_id} onClick={() => { navigate(`/messages/${c.agent_id}`); setActiveConversation(c);}} className={cn("p-4 flex items-center gap-3 cursor-pointer border-b hover:bg-secondary", activeConversation?.agent_id === c.agent_id && "bg-secondary")}><Avatar><AvatarImage src={c.avatar_url} /><AvatarFallback>{c.full_name?.charAt(0)}</AvatarFallback></Avatar><div className="flex-1 overflow-hidden"><p className="font-semibold truncate text-sm">{c.full_name}</p><p className="text-xs text-muted-foreground truncate">{c.last_message}</p></div></div>)}
              </div>
            </div>
            <div className={cn("w-full sm:w-2/3 flex-col", activeConversation ? "flex" : "hidden sm:flex")}>
              {activeConversation ? (
                <>
                  <CardHeader className="border-b"><div className="flex items-center gap-3"><Button variant="ghost" size="icon" className="sm:hidden" onClick={() => setActiveConversation(null)}><ArrowLeft className="h-4 w-4"/></Button><Avatar><AvatarImage src={activeConversation.avatar_url} /><AvatarFallback>{activeConversation.full_name?.charAt(0)}</AvatarFallback></Avatar><div><p className="font-semibold">{activeConversation.full_name}</p><p className="text-sm text-muted-foreground">Real Estate Agent</p></div></div></CardHeader>
                  <CardContent className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-4">
                    {messages.map((m) => ( <div key={m.id} className={cn("flex items-end gap-2", m.sender_id === user.id ? 'justify-end' : 'justify-start')}> {m.sender_id !== user.id && <Avatar className="h-6 w-6"><AvatarImage src={activeConversation.avatar_url} /><AvatarFallback>{activeConversation.full_name?.charAt(0)}</AvatarFallback></Avatar>} <div className={cn("max-w-md p-3 rounded-lg flex flex-col", m.sender_id === user.id ? 'bg-primary text-primary-foreground' : 'bg-secondary')}><p className="whitespace-pre-wrap break-words">{m.message}</p>{m.media_url && (m.media_type === 'image' ? <img src={m.media_url} alt="attachment" className="mt-2 rounded-lg max-w-xs h-auto" /> : <a href={m.media_url} target="_blank" rel="noopener noreferrer" className="mt-2 flex items-center gap-2 bg-background/20 p-2 rounded-md hover:bg-background/30"><FileIcon className="h-5 w-5"/> <span className="underline truncate">View Attachment</span></a>)}<div className={cn("text-xs mt-1.5 flex items-center gap-1", m.sender_id === user.id ? 'self-end text-primary-foreground/70' : 'self-start text-muted-foreground')}>{new Date(m.created_at).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'})} {m.sender_id === user.id && (m.is_read ? <CheckCheck size={16} className="text-blue-300" /> : <Check size={16} />)}</div></div></div>))}
                    {isTyping && <TypingIndicator />}
                    <div ref={messagesEndRef} />
                  </CardContent>
                  <div className="p-4 border-t">
                    <form onSubmit={handleSendMessage} className="flex gap-2">
                        <Button type="button" variant="ghost" size="icon" onClick={() => document.getElementById('file-input-client').click()}><Paperclip className="h-4 w-4" /></Button>
                        <Input id="file-input-client" type="file" className="hidden" onChange={(e) => setAttachment(e.target.files[0])} />
                        <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} onKeyDown={handleTyping} placeholder="Type a message..." disabled={isSending} />
                        <Button type="submit" disabled={isSending || (!newMessage.trim() && !attachment)}><Send className="h-4 w-4" /></Button>
                    </form>
                    {attachment && (<div className="mt-2 p-2 bg-secondary rounded-md text-sm"><div className="flex items-center justify-between"><div className="flex items-center gap-2 truncate"><ImageIcon className="h-4 w-4 flex-shrink-0" /><span className="truncate">{attachment.name}</span></div><Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => setAttachment(null)}><X className="h-4 w-4" /></Button></div>{isSending && <Progress value={uploadProgress} className="h-1 mt-1" />}</div>)}
                  </div>
                </>
              ) : <div className="flex-1 flex items-center justify-center text-center"><div className="text-muted-foreground"><MessageCircle className="h-16 w-16 mx-auto mb-4" /><h3 className="text-xl font-semibold">Select a conversation</h3><p>Choose a chat from the left to get started.</p></div></div>}
            </div>
            {isDragActive && <div className="absolute inset-0 bg-primary/20 border-4 border-dashed border-primary rounded-lg flex items-center justify-center pointer-events-none"><div className="text-center text-primary-foreground font-bold"><Paperclip size={48} className="mx-auto" /><p className="text-2xl mt-4">Drop file to attach</p></div></div>}
            <input {...getInputProps()} />
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default ClientMessagesPage;
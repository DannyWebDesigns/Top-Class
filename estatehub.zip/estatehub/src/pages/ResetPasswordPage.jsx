import React, { useState } from 'react';
    import { Link, useNavigate } from 'react-router-dom';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { Mail, Loader2, ArrowLeft } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import EHLogo from '@/components/EHLogo';

    const ResetPasswordPage = () => {
      const [email, setEmail] = useState('');
      const [loading, setLoading] = useState(false);
      const [submitted, setSubmitted] = useState(false);
      const { toast } = useToast();
      const navigate = useNavigate();

      const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
          const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${window.location.origin}/update-password`,
          });
          if (error) throw error;
          setSubmitted(true);
          toast({
            title: 'Check your email',
            description: 'A password reset link has been sent to your email address.',
          });
        } catch (error) {
          toast({ title: 'Error', description: error.message, variant: 'destructive' });
        } finally {
          setLoading(false);
        }
      };

      return (
        <>
          <Helmet><title>Reset Password - EstateHub</title></Helmet>
          <div className="min-h-screen flex items-center justify-center p-4 bg-secondary/30 relative overflow-hidden">
             <motion.div initial={{ scale: 1.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1, ease: "circOut" }} className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-primary/10 rounded-full blur-3xl"></motion.div>
            <motion.div initial={{ scale: 1.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1, ease: "circOut", delay: 0.2 }} className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/20 rounded-full blur-3xl"></motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="w-full max-w-md z-10">
              <div className="text-center mb-8">
                <Link to="/" className="inline-flex items-center space-x-3 mb-6">
                  <EHLogo className="h-10 w-10" />
                  <span className="text-2xl font-bold">EstateHub</span>
                </Link>
                <h1 className="text-3xl font-bold mb-2">Forgot Your Password?</h1>
                <p className="text-muted-foreground">No worries, we'll send you reset instructions.</p>
              </div>

              <Card className="bg-card/80 backdrop-blur-lg border">
                <CardHeader>
                  <CardTitle>Reset Password</CardTitle>
                   {submitted && <CardDescription>Please check your inbox for the reset link.</CardDescription>}
                </CardHeader>
                <CardContent>
                  {!submitted ? (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div>
                        <Label htmlFor="email">Email Address</Label>
                        <div className="relative mt-1">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                          <Input id="email" name="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="pl-10 h-12" placeholder="you@example.com" />
                        </div>
                      </div>
                      <Button type="submit" className="w-full h-12 text-base" disabled={loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Send Reset Link'}
                      </Button>
                    </form>
                  ) : (
                    <div className="text-center">
                        <p className="text-muted-foreground">If you don't see the email, check your spam folder. You can close this page.</p>
                    </div>
                  )}
                  <div className="mt-6 text-center text-sm">
                    <Button variant="link" onClick={() => navigate('/login')} className="text-primary">
                        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Login
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </>
      );
    };

    export default ResetPasswordPage;

import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Download, Printer, CheckCircle, Clock, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import EHLogo from '@/components/EHLogo';
import { formatCurrency } from '@/lib/utils';
import jsPDF from 'jspdf';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const ReceiptPage = () => {
  const { transactionId } = useParams();
  const { toast } = useToast();
  const [transaction, setTransaction] = useState(null);
  const [loading, setLoading] = useState(true);
  const receiptRef = useRef(null);

  useEffect(() => {
    const fetchTransaction = async () => {
      try {
        const { data, error } = await supabase
          .from('transactions')
          .select(`
            id,
            created_at,
            amount,
            status,
            type,
            listing:listing_id(title, location),
            agent:agent_id(full_name, email),
            client:client_id(full_name, email, phone_number),
            successfulPayment:payments!inner(provider_ref, created_at, method)
          `)
          .eq('id', transactionId)
          .eq('payments.status', 'success')
          .limit(1)
          .single();

        if (error || !data) {
          throw error || new Error('Transaction with a successful payment not found.');
        }
        
        setTransaction(data);

      } catch (error) {
        toast({
          title: 'Error Fetching Receipt',
          description: error.message || 'Could not find a valid, paid transaction for this receipt.',
          variant: 'destructive',
        });
      } finally {
        setLoading(false);
      }
    };

    fetchTransaction();
  }, [transactionId, toast]);

  const handleDownloadPdf = async () => {
    toast({ title: 'Generating PDF...', description: 'Please wait a moment.' });
    try {
      const response = await fetch('/api/generate-receipt-pdf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transaction_id: transactionId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate PDF from server');
      }

      const htmlString = await response.text();
      
      const doc = new jsPDF({
        orientation: 'p',
        unit: 'px',
        format: 'a4',
      });

      await doc.html(htmlString, {
        callback: function (doc) {
          doc.save(`EstateHub-Receipt-${transaction.id.substring(0, 8)}.pdf`);
        },
        x: 15,
        y: 15,
        width: 415,
        windowWidth: 800,
      });

    } catch (error) {
      toast({ title: 'Download Failed', description: error.message, variant: 'destructive' });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const getStatusBadge = (status) => {
    const statusMap = {
        admin_confirmed: { text: 'Completed', icon: CheckCircle, color: 'text-green-600 border-green-600 bg-green-50' },
        pending: { text: 'Pending', icon: Clock, color: 'text-amber-600 border-amber-600 bg-amber-50' },
        client_confirmed: { text: 'Awaiting Approval', icon: Clock, color: 'text-blue-600 border-blue-600 bg-blue-50' },
        rejected: { text: 'Rejected', icon: XCircle, color: 'text-red-600 border-red-600 bg-red-50' },
    };
    const { text, icon: Icon, color } = statusMap[status] || { text: status, icon: Clock, color: 'text-gray-600 border-gray-600' };
    return <Badge variant="outline" className={cn('capitalize', color)}><Icon className="mr-1 h-3 w-3" />{text}</Badge>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-secondary">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }

  if (!transaction) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-secondary">
        <p className="text-destructive font-semibold text-lg">Could not load receipt data.</p>
      </div>
    );
  }

  const { listing, agent, client, successfulPayment, status } = transaction;

  return (
    <>
      <Helmet>
        <title>Receipt - {transaction.id.substring(0, 8)}</title>
      </Helmet>
      <div className="bg-secondary min-h-screen py-12 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-end gap-2 mb-4 print:hidden">
            <Button onClick={handleDownloadPdf} variant="outline"><Download className="mr-2 h-4 w-4" /> Download PDF</Button>
            <Button onClick={handlePrint}><Printer className="mr-2 h-4 w-4" /> Print</Button>
          </div>
          <div ref={receiptRef} className="bg-background p-8 md:p-12 rounded-lg shadow-lg border">
            <header className="flex justify-between items-start pb-8 border-b">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Payment Receipt</h1>
                <p className="text-muted-foreground">Thank you for your business.</p>
              </div>
              <div className="flex items-center gap-2">
                <EHLogo className="h-10 w-10" />
                <span className="text-2xl font-bold">EstateHub</span>
              </div>
            </header>

            <section className="grid grid-cols-1 md:grid-cols-3 gap-8 my-8">
              <div>
                <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-2">Billed To</h2>
                <p className="font-bold text-lg">{client?.full_name}</p>
                <p className="text-muted-foreground">{client?.email}</p>
                <p className="text-muted-foreground">{client?.phone_number}</p>
              </div>
               <div className="text-left md:text-center">
                <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-2">Transaction Status</h2>
                {getStatusBadge(status)}
              </div>
              <div className="text-left md:text-right">
                <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-2">Payment Details</h2>
                <p><span className="font-semibold">Reference:</span> {successfulPayment?.provider_ref || 'N/A'}</p>
                <p><span className="font-semibold">Date:</span> {new Date(successfulPayment?.created_at || transaction.created_at).toLocaleString()}</p>
                <p><span className="font-semibold">Method:</span> {successfulPayment?.method?.toUpperCase() || 'N/A'}</p>
              </div>
            </section>

            <section>
              <h2 className="text-sm font-semibold uppercase text-muted-foreground mb-4">Order Summary</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b">
                      <th className="py-2 font-semibold">Description</th>
                      <th className="py-2 font-semibold text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="py-4">
                        <p className="font-semibold">{listing?.title}</p>
                        <p className="text-sm text-muted-foreground">{listing?.location}</p>
                        <p className="text-sm text-muted-foreground">Type: <span className="capitalize">{transaction.type}</span></p>
                      </td>
                      <td className="py-4 text-right font-medium">{formatCurrency(transaction.amount)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            <section className="flex justify-end mt-8">
              <div className="w-full max-w-xs">
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">Total</span>
                  <span className="font-medium">{formatCurrency(transaction.amount)}</span>
                </div>
                <div className="flex justify-between py-4">
                  <span className="font-bold text-lg">Amount Paid</span>
                  <span className="font-bold text-lg text-primary">{formatCurrency(successfulPayment ? transaction.amount : 0)}</span>
                </div>
              </div>
            </section>

            <footer className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
              <p>Sold by: {agent?.full_name} on behalf of EstateHub.</p>
              <p>If you have any questions, please contact our support team.</p>
              <p className="mt-4 font-semibold">Transaction ID: {transaction.id}</p>
            </footer>
          </div>
        </div>
      </div>
    </>
  );
};

export default ReceiptPage;


import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Loader2, Menu, Send } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import * as api from '@/api';

import Sidebar from '@/components/admin-dashboard/Sidebar';
import AnalyticsTab from '@/components/admin-dashboard/AnalyticsTab';
import UserManagementTab from '@/components/admin-dashboard/UserManagementTab';
import ListingsTab from '@/components/admin-dashboard/ListingsTab';
import TransactionsTab from '@/components/admin-dashboard/TransactionsTab';
import WithdrawalsTab from '@/components/admin-dashboard/WithdrawalsTab';
import ReportsTab from '@/components/admin-dashboard/ReportsTab';
import SupportTab from '@/components/admin-dashboard/SupportTab';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
        opacity: 1,
        y: 0,
        transition: {
            staggerChildren: 0.1,
            delayChildren: 0.2,
        },
    },
};

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const AdminDashboard = () => {
    const { profile, signOut } = useAuth();
    const { toast } = useToast();
    const { tab } = useParams();
    const navigate = useNavigate();
    
    const [activeTab, setActiveTab] = useState(tab || 'analytics');
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [analytics, setAnalytics] = useState({
        total_users: 0, total_agents: 0, total_clients: 0, total_listings: 0,
        total_transactions: 0, total_revenue: 0, monthly_signups: [], monthly_revenue: []
    });
    const [allUsers, setAllUsers] = useState([]);
    const [listings, setListings] = useState([]);
    const [supportMessages, setSupportMessages] = useState([]);
    const [reports, setReports] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [withdrawalRequests, setWithdrawalRequests] = useState([]);
    const [activeMessage, setActiveMessage] = useState(null);
    const [replyText, setReplyText] = useState('');
    const [userToHandle, setUserToHandle] = useState(null);
    const [listingToDelete, setListingToDelete] = useState(null);
    const [isProcessing, setIsProcessing] = useState(null);
    const [isReplying, setIsReplying] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [isDeletingUser, setIsDeletingUser] = useState(false);
    const [showSendMessage, setShowSendMessage] = useState(false);
    const [messageUser, setMessageUser] = useState(null);
    const [messageTitle, setMessageTitle] = useState('');
    const [messageContent, setMessageContent] = useState('');
    const [isSendingMessage, setIsSendingMessage] = useState(false);
    const [pendingApprovalsCount, setPendingApprovalsCount] = useState(0);

    const loadData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [analyticsRes, usersRes, listingsRes, messagesRes, reportsRes, transactionsRes, withdrawalsRes] = await Promise.all([
                api.fetchAdminDashboardAnalytics(),
                api.fetchAllProfiles(),
                api.fetchAllListingsWithProfiles(),
                api.fetchAllSupportMessages(),
                api.fetchAllReports(),
                api.fetchAllTransactions(),
                api.fetchAllWithdrawalRequests()
            ]);

            if (analyticsRes.error) throw analyticsRes.error;
            setAnalytics(analyticsRes.data);

            if (usersRes.error) throw usersRes.error;
            setAllUsers(usersRes.data);

            if (listingsRes.error) throw listingsRes.error;
            setListings(listingsRes.data);

            if (messagesRes.error) throw messagesRes.error;
            setSupportMessages(messagesRes.data);
            if (messagesRes.data.length > 0 && !activeMessage) setActiveMessage(messagesRes.data[0]);

            if (reportsRes.error) throw reportsRes.error;
            setReports(reportsRes.data);

            if (transactionsRes.error) throw transactionsRes.error;
            setTransactions(transactionsRes.data);
            setPendingApprovalsCount(transactionsRes.data.filter(t => t.status === 'client_confirmed').length);
            
            if (withdrawalsRes.error) throw withdrawalsRes.error;
            setWithdrawalRequests(withdrawalsRes.data);

        } catch (error) {
            toast({ title: "Error loading dashboard data", description: error.message, variant: "destructive" });
        } finally {
            setIsLoading(false);
        }
    }, [toast, activeMessage]);

    useEffect(() => {
        if (profile?.role !== 'admin') return;
        loadData();

        const channel = supabase.channel('admin-dashboard-changes').on('postgres_changes', { event: '*', schema: 'public' }, () => {
            loadData();
        }).subscribe();

        return () => { supabase.removeChannel(channel); };
    }, [profile, loadData]);
    
    useEffect(() => {
        navigate(`/admin/${activeTab}`, { replace: true });
    }, [activeTab, navigate]);

    const handleSendMessageSubmit = async (e) => {
        e.preventDefault();
        if (!messageUser) return;
        setIsSendingMessage(true);

        const { error } = await supabase.rpc('admin_send_notification', {
            p_target_user_id: messageUser.id,
            p_title: messageTitle,
            p_message: messageContent
        });

        if (error) {
            toast({ title: "Failed to send message", description: error.message, variant: "destructive" });
        } else {
            toast({ title: "Message Sent!", description: `Your message has been sent to ${messageUser.full_name}.` });
            setShowSendMessage(false);
            setMessageUser(null);
            setMessageTitle('');
            setMessageContent('');
        }
        setIsSendingMessage(false);
    };

    const handleUserAction = async () => {
        if (!userToHandle) return;
        setIsDeletingUser(true);
        const { error } = await supabase.functions.invoke('delete-user', { body: { user_id: userToHandle.id } });
        if (error) { toast({ title: `Failed to remove ${userToHandle.role}`, description: error.message, variant: "destructive" }); }
        else {
            toast({ title: `${userToHandle.role} Deleted`, description: `${userToHandle.full_name}'s account has been removed.` });
            loadData();
        }
        setUserToHandle(null);
        setIsDeletingUser(false);
    };

    const confirmDeleteListing = async () => {
        if (!listingToDelete) return;
        const { id, agent_id, title } = listingToDelete;

        const { error } = await supabase.from('listings').delete().eq('id', id);
        if (error) { toast({ title: "Error deleting listing", description: error.message, variant: "destructive" }); }
        else {
            if (agent_id) {
                const { error: notificationError } = await supabase.from('notifications').insert({
                    target_user_id: agent_id, kind: 'listing_removed', payload: { title: "Listing Removed", message: `Your property listing "${title}" has been removed by an administrator.` }
                });
                if (notificationError) console.error("Failed to send notification:", notificationError);
            }
            toast({ title: "Listing Deleted", description: "The listing has been removed." });
            loadData();
        }
        setListingToDelete(null);
    };

    const handleReplySubmit = async (e) => {
        e.preventDefault();
        if (!replyText.trim() || !activeMessage) return;
        setIsReplying(true);

        const { error } = await supabase.rpc('handle_admin_support_reply', {
            p_message_id: activeMessage.id,
            p_reply_text: replyText,
        });

        if (error) { toast({ title: "Error sending reply", description: error.message, variant: "destructive" }); }
        else {
            toast({ title: "Reply Sent", description: `Your reply to ${activeMessage.sender.full_name} has been sent.` });
            setReplyText('');
            loadData();
        }
        setIsReplying(false);
    };

    const handleUpdateReportStatus = async (reportId, newStatus) => {
        const { error } = await supabase.from('reports').update({ status: newStatus }).eq('id', reportId);
        if (error) { toast({ title: "Update Failed", description: error.message, variant: "destructive" }); }
        else { 
            toast({ title: "Report Status Updated" });
            loadData();
        }
    };

    const handleApproveTransaction = async (transactionId) => {
        setIsProcessing(transactionId);
        toast({ title: "Processing Approval...", description: "This may take a moment." });
        const { error } = await supabase.rpc('admin_approve_transaction', {
            p_transaction_id: transactionId
        });

        if (error) {
            toast({ title: "Approval Failed", description: error.message, variant: "destructive" });
        } else {
            toast({ title: "Transaction Approved & Payout Queued", description: "The agent and client have been notified." });
            loadData();
        }
        setIsProcessing(null);
    };

    const handleRejectTransaction = async (transactionId) => {
        setIsProcessing(transactionId);
        const { error } = await supabase.rpc('client_reject_transaction', { p_transaction_id: transactionId, p_reason: 'Rejected by administrator.' });
        if (error) {
            toast({ title: "Action Failed", description: error.message, variant: "destructive" });
        } else {
            toast({ title: "Transaction Rejected", description: "The agent and client have been notified." });
            loadData();
        }
        setIsProcessing(null);
    };
    
    const handleProcessWithdrawal = async (requestId, action, reason) => {
        setIsProcessing(requestId);
        const { error } = await supabase.rpc('admin_process_withdrawal', {
            p_request_id: requestId,
            p_action: action,
            p_rejection_reason: reason
        });
        if (error) {
            toast({ title: "Action Failed", description: error.message, variant: "destructive" });
        } else {
            toast({ title: `Withdrawal ${action}`, description: "The agent has been notified."});
            loadData();
        }
        setIsProcessing(null);
    };

    const agents = allUsers.filter(u => u.role === 'agent' && u.status !== 'deleted');
    const clients = allUsers.filter(u => u.role === 'client' && u.status !== 'deleted');

    const renderContent = () => {
        if (isLoading) {
            return <div className="flex items-center justify-center h-full"><Loader2 className="h-16 w-16 animate-spin text-primary" /></div>;
        }
        switch (activeTab) {
            case 'analytics': return <AnalyticsTab analytics={analytics} />;
            case 'users': return <UserManagementTab agents={agents} clients={clients} onUserAction={setUserToHandle} onSendMessage={(user) => { setMessageUser(user); setShowSendMessage(true);}} />;
            case 'listings': return <ListingsTab listings={listings} onDeleteAction={setListingToDelete} />;
            case 'transactions': return <TransactionsTab transactions={transactions} onApprove={handleApproveTransaction} onReject={handleRejectTransaction} isProcessing={isProcessing} />;
            case 'withdrawals': return <WithdrawalsTab requests={withdrawalRequests} onProcess={handleProcessWithdrawal} isProcessing={isProcessing} />;
            case 'reports': return <ReportsTab reports={reports} onUpdateStatus={handleUpdateReportStatus} />;
            case 'support': return <SupportTab messages={supportMessages} activeMessage={activeMessage} setActiveMessage={setActiveMessage} replyText={replyText} setReplyText={setReplyText} handleReplySubmit={handleReplySubmit} isReplying={isReplying} />;
            default: return <AnalyticsTab analytics={analytics} />;
        }
    };

    return (
        <>
            <Helmet><title>Admin Dashboard - EstateHub</title></Helmet>
            <div className="min-h-screen bg-secondary/30 flex">
                <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={signOut} isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} pendingApprovalsCount={pendingApprovalsCount} />
                <main className="flex-1 p-6 md:p-10 overflow-y-auto">
                    <motion.div initial="hidden" animate="visible" variants={containerVariants}>
                        <motion.div variants={itemVariants} className="mb-8 flex items-center justify-between">
                            <div>
                                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">Admin Dashboard</h1>
                                <p className="text-muted-foreground">Welcome back, {profile?.full_name || 'Admin'}.</p>
                            </div>
                            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsSidebarOpen(true)}>
                                <Menu className="h-6 w-6" />
                            </Button>
                        </motion.div>
                        {renderContent()}
                    </motion.div>
                </main>
            </div>

            <Dialog open={!!userToHandle} onOpenChange={() => setUserToHandle(null)}>
                <DialogContent><DialogHeader><DialogTitle>Confirm User Removal</DialogTitle><DialogDescription>
                    Are you sure you want to remove {userToHandle?.full_name}? This will anonymize their personal data and delete their login credentials. This action cannot be undone.
                </DialogDescription></DialogHeader><DialogFooter><Button variant="secondary" onClick={() => setUserToHandle(null)} disabled={isDeletingUser}>Cancel</Button><Button variant='destructive' onClick={handleUserAction} disabled={isDeletingUser}>
                    {isDeletingUser ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Yes, Remove User
                </Button></DialogFooter></DialogContent>
            </Dialog>

            <Dialog open={!!listingToDelete} onOpenChange={() => setListingToDelete(null)}>
                <DialogContent><DialogHeader><DialogTitle>Delete Listing?</DialogTitle><DialogDescription>Are you sure you want to permanently delete the listing for <strong>{listingToDelete?.title}</strong>? This action cannot be undone.</DialogDescription></DialogHeader><DialogFooter><Button variant="secondary" onClick={() => setListingToDelete(null)}>Cancel</Button><Button variant="destructive" onClick={confirmDeleteListing}>Yes, Delete Listing</Button></DialogFooter></DialogContent>
            </Dialog>
            
            <Dialog open={showSendMessage} onOpenChange={setShowSendMessage}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Send Notification to {messageUser?.full_name}</DialogTitle>
                        <DialogDescription>
                            Compose a message to be sent directly to the user's notification center.
                        </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleSendMessageSubmit} className="space-y-4 pt-4">
                        <div>
                            <Label htmlFor="msg-title">Title</Label>
                            <Input id="msg-title" value={messageTitle} onChange={e => setMessageTitle(e.target.value)} required />
                        </div>
                        <div>
                            <Label htmlFor="msg-content">Message</Label>
                            <Textarea id="msg-content" value={messageContent} onChange={e => setMessageContent(e.target.value)} required />
                        </div>
                         <DialogFooter>
                            <Button type="button" variant="secondary" onClick={() => setShowSendMessage(false)}>Cancel</Button>
                            <Button type="submit" disabled={isSendingMessage}>
                                {isSendingMessage ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                                Send Message
                            </Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default AdminDashboard;

import React from 'react';

function ProductDetailPage() {
  return (
    <div>
      <h1>Product Detail Page</h1>
      <p>Online Store has been disconnected. This page is no longer in use.</p>
    </div>
  );
}

export default ProductDetailPage;
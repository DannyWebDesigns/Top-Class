import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Bed, Bath, Triangle, ArrowLeft, Heart, Share2, MessageSquare, Flag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { formatCurrency } from '@/lib/utils';
import SEO from '@/components/SEO';

const PropertyDetailsPage = () => {
    const { id } = useParams();
    const { user } = useAuth();
    const { toast } = useToast();
    const [property, setProperty] = useState(null);
    const [loading, setLoading] = useState(true);
    const [isFavorite, setIsFavorite] = useState(false);
    const [showReportDialog, setShowReportDialog] = useState(false);
    const [reportReason, setReportReason] = useState('');
    const [reportDetails, setReportDetails] = useState('');

    const fetchProperty = useCallback(async () => {
        setLoading(true);
        const { data, error } = await supabase
            .from('listings')
            .select('*, profiles:agent_id(*)')
            .eq('id', id)
            .single();

        if (error) {
            toast({ title: "Error fetching property", description: "This listing may not exist or is no longer available.", variant: "destructive" });
        } else {
            setProperty(data);
        }
        setLoading(false);
    }, [id, toast]);

    const checkFavorite = useCallback(async () => {
        if (!user) return;
        const { data, error } = await supabase
            .from('favorites')
            .select('*')
            .eq('user_id', user.id)
            .eq('property_id', id);
        
        if (error && error.code !== 'PGRST116') { // Ignore "No rows found" error
            console.error('Error checking favorite:', error);
        } else if (data && data.length > 0) {
            setIsFavorite(true);
        } else {
            setIsFavorite(false);
        }
    }, [id, user]);

    useEffect(() => {
        fetchProperty();
        if(user) checkFavorite();
    }, [fetchProperty, checkFavorite, user]);

    const handleToggleFavorite = async () => {
        if (!user) {
            toast({ title: "Please log in", description: "You must be logged in to save properties.", variant: "destructive" });
            return;
        }

        if (isFavorite) {
            const { error } = await supabase.from('favorites').delete().match({ user_id: user.id, property_id: id });
            if (error) {
                toast({ title: "Error", description: error.message, variant: "destructive" });
            } else {
                toast({ title: "Removed from favorites." });
                setIsFavorite(false);
            }
        } else {
            const { error } = await supabase.from('favorites').insert({ user_id: user.id, property_id: id });
            if (error) {
                toast({ title: "Error", description: error.message, variant: "destructive" });
            } else {
                toast({ title: "Added to favorites!" });
                setIsFavorite(true);
            }
        }
    };
    
    const handleReportSubmit = async (e) => {
        e.preventDefault();
        if (!reportReason) {
            toast({ title: "Reason required", description: "Please select a reason for your report.", variant: "destructive" });
            return;
        }

        const { error } = await supabase.from('reports').insert({
            listing_id: property.id,
            reporter_id: user.id,
            reason: reportReason,
            details: reportDetails
        });

        if (error) {
            toast({ title: "Failed to submit report", description: error.message, variant: "destructive" });
        } else {
            toast({ title: "Report Submitted", description: "Thank you for helping keep our community safe. Our team will review this listing." });
            setShowReportDialog(false);
            setReportReason('');
            setReportDetails('');
        }
    };
    
    const getStructuredData = () => {
        if (!property) return null;
        return {
            "@context": "https://schema.org",
            "@type": "Product",
            "name": property.title,
            "description": property.description,
            "image": property.images?.[0],
            "url": window.location.href,
            "sku": property.id,
            "offers": {
                "@type": "Offer",
                "priceCurrency": property.currency || "NGN",
                "price": property.price,
                "availability": property.status === 'active' ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
                "seller": {
                    "@type": "Person",
                    "name": property.profiles.full_name
                }
            },
            "additionalProperty": [
                { "@type": "PropertyValue", "name": "Bedrooms", "value": property.bedrooms },
                { "@type": "PropertyValue", "name": "Bathrooms", "value": property.bathrooms },
                { "@type": "PropertyValue", "name": "Area", "value": `${property.area} sqft` }
            ]
        };
    };

    if (loading) return <div className="h-screen flex items-center justify-center">Loading property details...</div>;
    if (!property) return <div className="h-screen flex items-center justify-center">Property not found.</div>;

    const { title, description, price, location, type, bedrooms, bathrooms, area, images, profiles: agent } = property;

    return (
        <>
            <SEO
                title={`${title} - EstateHub`}
                description={description.substring(0, 160)}
                ogImage={images?.[0]}
                structuredData={getStructuredData()}
            />
            <Navbar />
            <div className="container mx-auto px-4 py-8">
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                    <div className="mb-6"><Link to="/properties" className="flex items-center text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4 mr-2" />Back to Listings</Link></div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2">
                            <Card className="overflow-hidden">
                                <div className="grid grid-cols-2 grid-rows-2 gap-2 h-[500px]">
                                    {images?.slice(0, 4).map((img, index) => (
                                        <div key={index} className={`relative ${index === 0 ? 'col-span-2 row-span-2' : 'hidden md:block'}`}>
                                            <img src={img} alt={`${title} image ${index + 1}`} className="w-full h-full object-cover"/>
                                        </div>
                                    ))}
                                </div>
                                <CardContent className="p-6">
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <Badge variant="secondary" className="capitalize mb-2">{type}</Badge>
                                            <h1 className="text-3xl font-bold">{title}</h1>
                                            <div className="flex items-center text-muted-foreground mt-1">
                                                <MapPin className="h-4 w-4 mr-1.5" /><span>{location}</span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <Button variant="ghost" size="icon" onClick={handleToggleFavorite}>
                                                <Heart className={`h-6 w-6 ${isFavorite ? 'text-red-500 fill-red-500' : 'text-muted-foreground'}`} />
                                            </Button>
                                            <Button variant="ghost" size="icon"><Share2 className="h-6 w-6 text-muted-foreground" /></Button>
                                            {user && user.id !== agent.id && (
                                                <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
                                                    <DialogTrigger asChild>
                                                        <Button variant="ghost" size="icon"><Flag className="h-6 w-6 text-muted-foreground" /></Button>
                                                    </DialogTrigger>
                                                    <DialogContent>
                                                        <DialogHeader>
                                                            <DialogTitle>Report Listing: {property.title}</DialogTitle>
                                                            <DialogDescription>Help us understand the problem. What is wrong with this listing?</DialogDescription>
                                                        </DialogHeader>
                                                        <form onSubmit={handleReportSubmit} className="space-y-4 pt-4">
                                                            <div>
                                                                <Label htmlFor="reason">Reason for reporting</Label>
                                                                <select id="reason" value={reportReason} onChange={(e) => setReportReason(e.target.value)} required className="w-full h-10 px-3 rounded-md bg-input border">
                                                                    <option value="" disabled>-- Select a reason --</option>
                                                                    <option value="inaccurate_information">Inaccurate Information</option>
                                                                    <option value="suspicious_or_scam">Suspicious or Scam</option>
                                                                    <option value="not_available">Property is not available</option>
                                                                    <option value="offensive_content">Offensive Content</option>
                                                                    <option value="other">Other</option>
                                                                </select>
                                                            </div>
                                                            <div>
                                                                <Label htmlFor="details">Additional Details (optional)</Label>
                                                                <Textarea id="details" value={reportDetails} onChange={(e) => setReportDetails(e.target.value)} placeholder="Provide more information here..."/>
                                                            </div>
                                                            <DialogFooter>
                                                                <DialogClose asChild><Button type="button" variant="secondary">Cancel</Button></DialogClose>
                                                                <Button type="submit">Submit Report</Button>
                                                            </DialogFooter>
                                                        </form>
                                                    </DialogContent>
                                                </Dialog>
                                            )}
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-center space-x-6 text-muted-foreground border-y py-4 my-4">
                                        <div className="flex items-center gap-2"><Bed className="h-5 w-5 text-primary" /><span>{bedrooms} Bedrooms</span></div>
                                        <div className="flex items-center gap-2"><Bath className="h-5 w-5 text-primary" /><span>{bathrooms} Bathrooms</span></div>
                                        <div className="flex items-center gap-2"><Triangle className="h-5 w-5 text-primary" /><span>{area} sqft</span></div>
                                    </div>

                                    <h2 className="text-xl font-semibold mb-2">Description</h2>
                                    <p className="text-muted-foreground whitespace-pre-wrap">{description}</p>
                                </CardContent>
                            </Card>
                        </div>

                        <div className="space-y-8">
                            <Card>
                                <CardContent className="p-6">
                                    <p className="text-3xl font-bold text-primary mb-4">{formatCurrency(price)}</p>
                                    <Button size="lg" className="w-full" asChild><Link to={`/messages/${agent.id}`}><MessageSquare className="mr-2 h-5 w-5" />Contact Agent</Link></Button>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardContent className="p-6">
                                    <h3 className="font-semibold mb-4">Listed by</h3>
                                    <div className="flex items-center gap-4">
                                        <Avatar className="h-16 w-16">
                                            <AvatarImage src={agent.avatar_url} alt={agent.full_name}/>
                                            <AvatarFallback>{agent.full_name?.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <Link to={`/agent/${agent.id}`} className="font-bold text-lg hover:text-primary transition-colors">{agent.full_name}</Link>
                                            <p className="text-sm text-muted-foreground">Licensed Agent</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </div>
                </motion.div>
            </div>
        </>
    );
};

export default PropertyDetailsPage;
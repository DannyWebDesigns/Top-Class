import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Search, Home, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import Navbar from '@/components/Navbar';
import PropertyCard from '@/components/PropertyCard';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const SavedPropertiesPage = () => {
  const { user } = useAuth();
  const [savedProperties, setSavedProperties] = useState([]);
  const [filteredProperties, setFilteredProperties] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  const loadSavedProperties = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('favorites')
      .select('*, property:listing_id(*, profiles:agent_id(*))')
      .eq('user_id', user.id);

    if (error) {
      console.error("Error fetching saved properties:", error);
      setSavedProperties([]);
    } else {
      setSavedProperties(data.map(fav => fav.property).filter(Boolean));
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    loadSavedProperties();
  }, [loadSavedProperties]);

  useEffect(() => {
    if (searchTerm) {
      setFilteredProperties(
        savedProperties.filter(p =>
          p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          p.location.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    } else {
      setFilteredProperties(savedProperties);
    }
  }, [searchTerm, savedProperties]);

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8 text-center">
          <h2 className="text-2xl font-semibold mb-2">Please log in</h2>
          <p className="text-muted-foreground mb-6">You need to be logged in to view your saved properties.</p>
          <Button asChild><Link to="/login">Login</Link></Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Saved Properties - EstateHub</title>
        <meta name="description" content="View and manage your saved properties." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <CardTitle className="text-3xl font-bold flex items-center gap-2">
                      <Heart className="text-red-500" />
                      Saved Properties
                    </CardTitle>
                    <CardDescription>Your favorite listings, all in one place.</CardDescription>
                  </div>
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search saved properties..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center items-center py-20">
                    <Loader2 className="h-12 w-12 animate-spin text-primary" />
                  </div>
                ) : filteredProperties.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredProperties.map((p, i) => (
                      <PropertyCard key={p.id} property={p} index={i} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20">
                    <Home className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No Saved Properties Yet</h3>
                    <p className="text-muted-foreground mb-6">
                      {searchTerm ? 'No saved properties match your search.' : 'Start browsing and click the heart icon to save listings.'}
                    </p>
                    <Button asChild><Link to="/properties">Browse Properties</Link></Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default SavedPropertiesPage;
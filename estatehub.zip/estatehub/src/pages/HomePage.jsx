
import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import Navbar from '@/components/Navbar';
import SupportChatbot from '@/components/SupportChatbot';
import HeroSection from '@/components/homepage/HeroSection';
import CategoriesSection from '@/components/homepage/CategoriesSection';
import LatestPropertiesSection from '@/components/homepage/LatestPropertiesSection';
import SafetySection from '@/components/homepage/SafetySection';
import TestimonialsSection from '@/components/homepage/TestimonialsSection';
import { useToast } from '@/components/ui/use-toast';

const HomePage = () => {
  const [latestProperties, setLatestProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const ogImageUrl = 'https://horizons-cdn.hostinger.com/3c6ab7a4-8e4f-40d5-aded-5cf29a2f6d8e/og_image_estatehub.png';

  const fetchLatestProperties = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.rpc('get_featured_listings', { p_limit: 6 });
    
    if (error) {
      console.error("Error fetching latest properties:", error);
      toast({
        title: "Error",
        description: "Could not fetch latest properties. Please try again later.",
        variant: "destructive",
      });
      setLatestProperties([]);
    } else {
      const listingsWithProfiles = await Promise.all(data.map(async l => {
          const { data: profileData } = await supabase.from('profiles').select('*').eq('id', l.agent_id).single();
          return { ...l, profiles: profileData };
      }));
      setLatestProperties(listingsWithProfiles);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchLatestProperties();

    const channel = supabase.channel('homepage-listings-changes')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'listings' }, (payload) => {
        fetchLatestProperties();
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'listings' }, (payload) => {
        fetchLatestProperties();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchLatestProperties]);

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "https://www.estatehub.com",
    "name": "EstateHub - Student Accommodation Made Easy",
    "description": "Find safe, affordable, and convenient off-campus housing, hostels, and apartments near your school in Nigeria. EstateHub is the trusted platform for student rentals.",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://www.estatehub.com/properties?search={search_term_string}",
      "query-input": "required name=search_term_string"
    },
    "publisher": {
      "@type": "Organization",
      "name": "EstateHub",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.estatehub.com/logo.png"
      }
    }
  };

  return (
    <>
      <Helmet>
        <title>EstateHub - Student Accommodation Made Easy in Nigeria</title>
        <meta name="description" content="Find safe, affordable, and convenient off-campus housing, hostels, and apartments near your school in Nigeria. EstateHub is the trusted platform for student rentals." />
        <meta property="og:title" content="EstateHub - Student Accommodation Made Easy" />
        <meta property="og:description" content="Find safe, affordable, and convenient off-campus housing, hostels, and apartments near your school in Nigeria." />
        <meta property="og:image" content={ogImageUrl} />
        <meta property="og:url" content="https://www.estatehub.com" />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="EstateHub - Student Accommodation Made Easy" />
        <meta name="twitter:description" content="Find safe, affordable, and convenient off-campus housing, hostels, and apartments near your school in Nigeria." />
        <meta name="twitter:image" content={ogImageUrl} />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>
      
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        
        <main>
          <HeroSection />
          <CategoriesSection />
          <LatestPropertiesSection properties={latestProperties} />
          <SafetySection />
          <TestimonialsSection />
        </main>
        <SupportChatbot />
      </div>
    </>
  );
};

export default HomePage;

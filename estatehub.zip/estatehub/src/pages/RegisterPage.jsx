import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Mail, Lock, Phone, Award, FileText, ArrowRight, Building, UserCheck, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import EHLogo from '@/components/EHLogo';

const RegisterPage = () => {
  const [step, setStep] = useState(1);
  const [userType, setUserType] = useState(null);
  const [formData, setFormData] = useState({
    fullName: '', email: '', password: '', phoneNumber: '', profilePicture: null, yearsOfExperience: '', licenseNumber: '', licenseProof: null
  });
  const [loading, setLoading] = useState(false);
  const { registerUser } = useAuth();
  const { toast } = useToast();

  const handleNext = (e) => {
    e.preventDefault();
    const form = e.target.closest('form');
    if(form.checkValidity()){
        setStep(step + 1);
    } else {
        form.reportValidity();
    }
  };

  const handleBack = () => setStep(step - 1);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (userType === 'agent') {
      if (!formData.profilePicture) {
        toast({ title: "Registration Error", description: "Profile picture is required for agents.", variant: "destructive" });
        return;
      }
      if (!formData.licenseProof) {
        toast({ title: "Registration Error", description: "Proof of license is required for agents.", variant: "destructive" });
        return;
      }
    }
    setLoading(true);
    try {
      await registerUser({ ...formData, role: userType });
    } catch (error) {
      toast({ title: "Registration Failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, [e.target.name]: file });
    }
  };
  
  const handleChange = (e) => {
      setFormData({...formData, [e.target.name]: e.target.value});
  }

  const renderStep = () => {
    const commonProps = { initial:{ opacity: 0, x: 50 }, animate:{ opacity: 1, x: 0 }, exit:{ opacity: 0, x: -50 }, transition:{ duration: 0.4 } };
    switch (step) {
      case 1:
        return (
          <motion.div key="step1" {...commonProps} exit={{ opacity: 0, x: 50 }}>
            <CardHeader className="text-center">
              <CardTitle>Join as a Client or Agent</CardTitle>
              <CardDescription>Select your role to get started.</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col sm:flex-row gap-4 p-6">
              <Button className="w-full h-28 text-lg flex flex-col gap-2" onClick={() => { setUserType('client'); setStep(2); }}>
                <UserCheck size={28} /> I'm a Student
              </Button>
              <Button className="w-full h-28 text-lg flex flex-col gap-2" variant="secondary" onClick={() => { setUserType('agent'); setStep(2); }}>
                <Building size={28} /> I'm an Agent
              </Button>
            </CardContent>
          </motion.div>
        );
      case 2:
        return (
          <motion.form key="step2" {...commonProps} onSubmit={userType === 'agent' ? handleNext : handleSubmit}>
            <CardHeader>
              <CardTitle>Your Information</CardTitle>
              <CardDescription>Let's get your basic details.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative"><User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input className="pl-10" placeholder="Full Name" name="fullName" value={formData.fullName} onChange={handleChange} required disabled={loading}/></div>
              <div className="relative"><Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input className="pl-10" placeholder="Email Address" name="email" type="email" value={formData.email} onChange={handleChange} required disabled={loading}/></div>
              <div className="relative"><Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input className="pl-10" placeholder="Password" name="password" type="password" value={formData.password} onChange={handleChange} required minLength="6" disabled={loading}/></div>
              <div className="relative"><Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input className="pl-10" placeholder="Phone Number" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} required disabled={loading}/></div>
              <div className="flex justify-between items-center pt-4">
                <Button variant="ghost" type="button" onClick={handleBack} disabled={loading}>Back</Button>
                <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {userType === 'agent' ? 'Next' : 'Create Account'}
                    {userType === 'agent' && <ArrowRight className="ml-2 h-4 w-4" />}
                </Button>
              </div>
            </CardContent>
          </motion.form>
        );
      case 3:
        return (
          <motion.form key="step3" {...commonProps} onSubmit={handleSubmit}>
            <CardHeader>
              <CardTitle>Agent Verification</CardTitle>
              <CardDescription>Please provide your professional details.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative"><Award className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input className="pl-10" placeholder="Years of Experience" name="yearsOfExperience" type="number" value={formData.yearsOfExperience} onChange={handleChange} required disabled={loading}/></div>
              <div className="relative"><FileText className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" /><Input className="pl-10" placeholder="License Number" name="licenseNumber" value={formData.licenseNumber} onChange={handleChange} required disabled={loading}/></div>
              <div>
                <Label htmlFor="profilePicture" className="text-muted-foreground">Profile Picture (Required)</Label>
                <Input id="profilePicture" type="file" name="profilePicture" accept="image/*" onChange={handleFileChange} required className="file:text-primary file:font-semibold" disabled={loading}/>
              </div>
              <div>
                <Label htmlFor="licenseProof" className="text-muted-foreground">Proof of License (Required)</Label>
                <Input id="licenseProof" type="file" name="licenseProof" accept="image/*,application/pdf" onChange={handleFileChange} required className="file:text-primary file:font-semibold" disabled={loading}/>
              </div>
              <div className="flex justify-between items-center pt-4">
                <Button variant="ghost" type="button" onClick={handleBack} disabled={loading}>Back</Button>
                <Button type="submit" disabled={loading}>
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {loading ? 'Submitting...' : 'Submit Application'}
                </Button>
              </div>
            </CardContent>
          </motion.form>
        );
      default: return null;
    }
  };

  return (
    <>
      <Helmet><title>Sign Up - EstateHub</title></Helmet>
      <div className="min-h-screen flex items-center justify-center p-4 bg-secondary/30 relative overflow-hidden">
        <motion.div initial={{ scale: 1.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1, ease: "circOut" }} className="absolute -top-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/10 rounded-full blur-3xl"></motion.div>
        <motion.div initial={{ scale: 1.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 1, ease: "circOut", delay: 0.2 }} className="absolute -bottom-1/4 -left-1/4 w-1/2 h-1/2 bg-primary/20 rounded-full blur-3xl"></motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="w-full max-w-lg z-10">
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center space-x-3 mb-6">
              <EHLogo className="h-10 w-10" />
              <span className="text-2xl font-bold">EstateHub</span>
            </Link>
          </div>

          <Card className="bg-card/80 backdrop-blur-lg border overflow-hidden">
            <AnimatePresence mode="wait">{renderStep()}</AnimatePresence>
          </Card>
          <div className="mt-6 text-center text-sm">
            <p className="text-muted-foreground">Already have an account? <Link to="/login" className="text-primary hover:underline font-medium">Sign in here</Link></p>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default RegisterPage;
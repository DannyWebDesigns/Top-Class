import React, { useState, useEffect } from 'react';
    import { useNavigate } from 'react-router-dom';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { Lock, Eye, EyeOff, Loader2 } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import EHLogo from '@/components/EHLogo';
    import { useAuth } from '@/contexts/SupabaseAuthContext';

    const UpdatePasswordPage = () => {
      const [password, setPassword] = useState('');
      const [confirmPassword, setConfirmPassword] = useState('');
      const [showPassword, setShowPassword] = useState(false);
      const [loading, setLoading] = useState(false);
      const { toast } = useToast();
      const navigate = useNavigate();
      const { session } = useAuth();
      
      useEffect(() => {
        // This page should only be accessible if there's a recovery session
        if (!session) {
          navigate('/login');
          toast({ title: 'Invalid Session', description: 'Please initiate password reset again.', variant: 'destructive'});
        }
      }, [session, navigate, toast]);


      const handleSubmit = async (e) => {
        e.preventDefault();
        if (password !== confirmPassword) {
          toast({ title: 'Passwords do not match', variant: 'destructive' });
          return;
        }
        if (password.length < 6) {
          toast({ title: 'Password too short', description: 'Password must be at least 6 characters.', variant: 'destructive' });
          return;
        }

        setLoading(true);
        try {
          const { error } = await supabase.auth.updateUser({ password });
          if (error) throw error;
          toast({ title: 'Password Updated', description: 'Your password has been changed successfully. Please log in.' });
          await supabase.auth.signOut();
          navigate('/login');
        } catch (error) {
          toast({ title: 'Error updating password', description: error.message, variant: 'destructive' });
        } finally {
          setLoading(false);
        }
      };

      return (
        <>
          <Helmet><title>Update Password - EstateHub</title></Helmet>
          <div className="min-h-screen flex items-center justify-center p-4 bg-secondary/30">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md z-10">
              <div className="text-center mb-8">
                  <EHLogo className="h-10 w-10 mx-auto" />
              </div>
              <Card>
                <CardHeader>
                  <CardTitle>Create New Password</CardTitle>
                  <CardDescription>Enter a new password for your account.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="relative">
                      <Label htmlFor="password">New Password</Label>
                      <Input
                        id="password"
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="mt-1"
                      />
                       <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 bottom-2.5 text-muted-foreground hover:text-foreground">
                        {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                     <div className="relative">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <Button type="submit" className="w-full h-12 text-base" disabled={loading}>
                      {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Update Password'}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </>
      );
    };

    export default UpdatePasswordPage;
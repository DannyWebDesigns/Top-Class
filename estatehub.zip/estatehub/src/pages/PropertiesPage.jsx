import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Home, DollarSign, BedDouble, Bath, ListFilter, X, Loader2, Grip, List, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import Navbar from '@/components/Navbar';
import PropertyCard from '@/components/PropertyCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { formatCurrency } from '@/lib/utils';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from '@/components/ui/use-toast';

const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
};

const PropertiesPage = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const searchParams = new URLSearchParams(location.search);
  
  const [filters, setFilters] = useState({
    searchTerm: searchParams.get('search') || '',
    priceRange: [parseInt(searchParams.get('minPrice') || 0), parseInt(searchParams.get('maxPrice') || 5000000)],
    bedrooms: parseInt(searchParams.get('beds') || 0),
    bathrooms: parseInt(searchParams.get('baths') || 0),
    types: searchParams.get('types')?.split(',') || ['house', 'apartment', 'condo', 'land'],
  });

  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState('grid');
  const [currentPage, setCurrentPage] = useState(parseInt(searchParams.get('page') || 1));
  const [totalCount, setTotalCount] = useState(0);
  
  const PROPERTIES_PER_PAGE = 12;

  const debouncedSearchTerm = useDebounce(filters.searchTerm, 300);

  const updateURL = useCallback((newFilters, newPage) => {
    const params = new URLSearchParams();
    if (newFilters.searchTerm) params.set('search', newFilters.searchTerm);
    if (newFilters.priceRange[0] > 0) params.set('minPrice', newFilters.priceRange[0]);
    if (newFilters.priceRange[1] < 5000000) params.set('maxPrice', newFilters.priceRange[1]);
    if (newFilters.bedrooms > 0) params.set('beds', newFilters.bedrooms);
    if (newFilters.bathrooms > 0) params.set('baths', newFilters.bathrooms);
    if (newFilters.types.length < 4) params.set('types', newFilters.types.join(','));
    if (newPage > 1) params.set('page', newPage);
    navigate(`${location.pathname}?${params.toString()}`, { replace: true });
  }, [navigate, location.pathname]);


  const fetchProperties = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    let query = supabase
      .from('listings')
      .select('*, profiles(full_name, avatar_url)', { count: 'exact' })
      .eq('status', 'active');

    if (debouncedSearchTerm) {
      query = query.textSearch('title', debouncedSearchTerm, { type: 'websearch' });
    }
    
    query = query.gte('price', filters.priceRange[0]);
    query = query.lte('price', filters.priceRange[1]);
    
    if (filters.bedrooms > 0) {
      query = query.gte('bedrooms', filters.bedrooms);
    }
    if (filters.bathrooms > 0) {
      query = query.gte('bathrooms', filters.bathrooms);
    }
    
    if (filters.types.length > 0 && filters.types.length < 4) {
      query = query.in('type', filters.types);
    }

    const from = (currentPage - 1) * PROPERTIES_PER_PAGE;
    const to = from + PROPERTIES_PER_PAGE - 1;

    query = query.range(from, to).order('created_at', { ascending: false });

    const { data, error, count } = await query;

    if (error) {
      console.error('Error fetching properties:', error);
      setError('Could not fetch properties. Please try again later.');
      toast({ title: 'Error', description: 'Failed to load properties.', variant: 'destructive' });
      setProperties([]);
    } else {
      setProperties(data);
      setTotalCount(count);
    }
    setLoading(false);
  }, [debouncedSearchTerm, filters, currentPage, toast]);

  useEffect(() => {
    fetchProperties();
    updateURL(filters, currentPage);
  }, [fetchProperties, filters, currentPage, updateURL]);

  useEffect(() => {
    const channel = supabase.channel('properties-page-listings-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'listings' }, (payload) => {
        console.log('Change received on properties page!', payload);
        fetchProperties();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchProperties]);

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
    setCurrentPage(1);
  };
  
  const resetFilters = () => {
    const defaultFilters = {
      searchTerm: '',
      priceRange: [0, 5000000],
      bedrooms: 0,
      bathrooms: 0,
      types: ['house', 'apartment', 'condo', 'land'],
    };
    setFilters(defaultFilters);
    setCurrentPage(1);
  };

  const totalPages = Math.ceil(totalCount / PROPERTIES_PER_PAGE);

  return (
    <>
      <Helmet>
        <title>All Properties - EstateHub</title>
        <meta name="description" content="Browse all available properties for sale or rent on EstateHub." />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
            <Card className="mb-8 p-4 md:p-6 bg-card/50 backdrop-blur-sm border shadow-xl">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="relative flex-grow w-full">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input 
                    placeholder="Search by location, landmark, or property name..." 
                    className="pl-12 h-12 text-base" 
                    value={filters.searchTerm}
                    onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
                  />
                </div>
                <Button size="lg" className="h-12 w-full md:w-auto" onClick={() => setShowFilters(!showFilters)}>
                  <ListFilter className="mr-2 h-5 w-5" />
                  Filters
                </Button>
              </div>
            </Card>

            <AnimatePresence>
              {showFilters && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <Card className="mb-8 p-6 shadow-lg">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-start">
                      <div>
                        <label className="text-sm font-medium text-muted-foreground flex items-center mb-2"><DollarSign className="w-4 h-4 mr-2"/> Price Range</label>
                        <Slider value={filters.priceRange} onValueChange={(value) => handleFilterChange('priceRange', value)} max={5000000} step={100000} />
                        <div className="flex justify-between text-xs mt-2">
                          <span>{formatCurrency(filters.priceRange[0])}</span>
                          <span>{formatCurrency(filters.priceRange[1])}{filters.priceRange[1] === 5000000 ? '+' : ''}</span>
                        </div>
                      </div>
                       <div>
                        <label className="text-sm font-medium text-muted-foreground flex items-center mb-2"><BedDouble className="w-4 h-4 mr-2"/> Min. Bedrooms</label>
                        <Slider value={[filters.bedrooms]} onValueChange={(val) => handleFilterChange('bedrooms', val[0])} max={5} step={1} />
                        <p className="text-center text-xs mt-2">{filters.bedrooms === 0 ? "Any" : `${filters.bedrooms}+ Beds`}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-muted-foreground flex items-center mb-2"><Bath className="w-4 h-4 mr-2"/> Min. Bathrooms</label>
                        <Slider value={[filters.bathrooms]} onValueChange={(val) => handleFilterChange('bathrooms', val[0])} max={5} step={1} />
                         <p className="text-center text-xs mt-2">{filters.bathrooms === 0 ? "Any" : `${filters.bathrooms}+ Baths`}</p>
                      </div>
                      <div className="flex flex-col justify-between gap-2">
                         <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="w-full">
                              <Home className="mr-2 h-4 w-4"/> Property Type
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            <DropdownMenuLabel>Select Types</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {['house', 'apartment', 'condo', 'land'].map(type => (
                              <DropdownMenuCheckboxItem key={type} checked={filters.types.includes(type)} onCheckedChange={() => {
                                const newTypes = filters.types.includes(type)
                                  ? filters.types.filter(t => t !== type)
                                  : [...filters.types, type];
                                handleFilterChange('types', newTypes);
                              }}>
                                {type.charAt(0).toUpperCase() + type.slice(1)}
                              </DropdownMenuCheckboxItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                         <Button variant="ghost" onClick={resetFilters} className="w-full">
                            <X className="mr-2 h-4 w-4"/> Reset Filters
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex justify-between items-center mb-6">
                <p className="text-sm text-muted-foreground">Showing <span className="font-bold text-foreground">{properties.length}</span> of <span className="font-bold text-foreground">{totalCount}</span> properties</p>
                <div className="flex items-center gap-2">
                    <Button variant={viewMode === 'grid' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('grid')}><Grip className="h-5 w-5" /></Button>
                    <Button variant={viewMode === 'list' ? 'secondary' : 'ghost'} size="icon" onClick={() => setViewMode('list')}><List className="h-5 w-5" /></Button>
                </div>
            </div>

            {loading ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
              </div>
            ) : error ? (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            ) : properties.length > 0 ? (
              <>
                <motion.div 
                  layout 
                  className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}
                >
                  <AnimatePresence>
                    {properties.map((p, i) => <PropertyCard key={p.id} property={p} index={i} />)}
                  </AnimatePresence>
                </motion.div>
                {totalPages > 1 && (
                  <div className="flex justify-center items-center mt-12 gap-4">
                    <Button variant="outline" onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1}><ChevronLeft className="h-4 w-4 mr-2"/> Previous</Button>
                    <span className="text-sm text-muted-foreground">Page {currentPage} of {totalPages}</span>
                    <Button variant="outline" onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages}>Next <ChevronRight className="h-4 w-4 ml-2"/></Button>
                  </div>
                )}
              </>
            ) : (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-20">
                <Home className="mx-auto h-16 w-16 text-muted-foreground" />
                <h3 className="mt-4 text-xl font-semibold">No Properties Found</h3>
                <p className="mt-2 text-muted-foreground">Try adjusting your filters or search terms.</p>
                <Button onClick={resetFilters} className="mt-6">Clear Filters</Button>
              </motion.div>
            )}
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default PropertiesPage;
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CheckCircle, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import EHLogo from '@/components/EHLogo';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const RegistrationSuccessPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { loginUser } = useAuth();
  const { toast } = useToast();

  const { role, email, password } = location.state || {};
  const [status, setStatus] = useState('Logging you in...');

  useEffect(() => {
    if (!email || !password) {
      setStatus('Invalid registration data. Please log in manually.');
      setTimeout(() => navigate('/login'), 3000);
      return;
    }

    const autoLogin = async () => {
      try {
        const profile = await loginUser(email, password);
        setStatus('Redirecting to your dashboard...');
        
        setTimeout(() => {
          if (profile.role === 'agent') {
            navigate('/agent-dashboard', { replace: true });
          } else {
            navigate('/client-dashboard', { replace: true });
          }
        }, 1500);

      } catch (error) {
        toast({
          title: "Auto-login Failed",
          description: "Please log in manually.",
          variant: "destructive",
        });
        setStatus('Auto-login failed. Redirecting to login page...');
        setTimeout(() => navigate('/login', { replace: true }), 3000);
      }
    };

    const timer = setTimeout(autoLogin, 2000);
    return () => clearTimeout(timer);
  }, [email, password, loginUser, navigate, toast]);

  return (
    <>
      <Helmet>
        <title>Registration Successful - EstateHub</title>
        <meta name="description" content="Your account has been successfully created." />
      </Helmet>
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-secondary/20 to-background p-4 relative overflow-hidden">
        <motion.div 
            initial={{ scale: 1.5, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            transition={{ duration: 1, ease: "circOut" }} 
            className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-primary/10 rounded-full blur-3xl"
        ></motion.div>
        <motion.div 
            initial={{ scale: 1.5, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            transition={{ duration: 1, ease: "circOut", delay: 0.2 }} 
            className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/20 rounded-full blur-3xl"
        ></motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="w-full max-w-md z-10"
        >
          <div className="text-center mb-6">
            <div className="inline-flex items-center space-x-3">
                <EHLogo className="h-10 w-10 text-primary" />
                <span className="text-2xl font-bold">EstateHub</span>
            </div>
          </div>
          <Card className="text-center shadow-2xl bg-card/80 backdrop-blur-lg border">
            <CardHeader>
              <motion.div 
                initial={{scale: 0}}
                animate={{scale: 1}}
                transition={{delay: 0.4, type: 'spring', stiffness: 260, damping: 20}}
                className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/50"
              >
                <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-400" />
              </motion.div>
              <CardTitle className="mt-4 text-3xl font-bold">
                Account Created!
              </CardTitle>
              <CardDescription>
                Your account has been successfully created.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                  <h3 className="font-semibold mb-2">What's next?</h3>
                  <p className="text-muted-foreground text-sm">
                      {role === 'agent' 
                        ? "Your agent account is approved and ready to go! We're logging you in now." 
                        : "You're all set to explore listings and connect with agents. Get ready!"}
                  </p>
              </div>
              <div className="flex items-center justify-center space-x-2 text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" />
                <span>{status}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default RegistrationSuccessPage;
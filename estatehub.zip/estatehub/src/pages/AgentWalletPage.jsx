import React, { useState, useEffect, useCallback, useMemo } from 'react';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { Wallet, Check, ChevronsUpDown, Coins as HandCoins, History, Loader2, ArrowRight, AlertTriangle, ShieldCheck, XCircle } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
    import { Badge } from '@/components/ui/badge';
    import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
    import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
    import { Alert, AlertDescription } from "@/components/ui/alert"
    import Navbar from '@/components/Navbar';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { formatCurrency, cn } from '@/lib/utils';
    import BanksData from '@/data/nigerian_banks.json';
    import { useDebounce } from '@/hooks/useDebounce';

    const itemVariants = {
      hidden: { opacity: 0, y: 20 },
      visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
    };

    const AgentWalletPage = () => {
        const { user } = useAuth();
        const { toast } = useToast();
        const [wallet, setWallet] = useState(null);
        const [requests, setRequests] = useState([]);
        const [loading, setLoading] = useState(true);
        const [showWithdrawDialog, setShowWithdrawDialog] = useState(false);
        const [withdrawAmount, setWithdrawAmount] = useState('');
        const [bankDetails, setBankDetails] = useState({ bankCode: '', accountNumber: '' });
        const [verifiedAccount, setVerifiedAccount] = useState(null);
        const [verificationError, setVerificationError] = useState(null);
        const [isVerifying, setIsVerifying] = useState(false);
        const [isSubmitting, setIsSubmitting] = useState(false);
        const [banks, setBanks] = useState([]);
        const [bankSearch, setBankSearch] = useState('');
        const [openBankPopover, setOpenBankPopover] = useState(false);

        const debouncedAccountNumber = useDebounce(bankDetails.accountNumber, 500);

        useEffect(() => {
            setBanks(BanksData);
        }, []);

        const loadWalletData = useCallback(async () => {
            if (!user) return;
            setLoading(true);
            try {
                const { data: walletData, error: walletError } = await supabase.from('agent_wallets').select('*').eq('agent_id', user.id).maybeSingle();
                if (walletError) throw walletError;

                const { data: requestsData, error: requestsError } = await supabase.from('withdrawal_requests').select('*').eq('agent_id', user.id).order('created_at', { ascending: false });
                if (requestsError) throw requestsError;
                
                setWallet(walletData || { balance: 0, pending_withdrawal: 0, lifetime_earnings: 0 });
                setRequests(requestsData);
            } catch (error) {
                toast({ title: 'Error loading wallet data', description: error.message, variant: 'destructive' });
            } finally {
                setLoading(false);
            }
        }, [user, toast]);

        useEffect(() => {
            loadWalletData();
        }, [loadWalletData]);

        useEffect(() => {
            if (!user) return;
            const channel = supabase.channel(`agent-wallet-page-channel-${user.id}`).on('postgres_changes', { event: '*', schema: 'public' }, (payload) => {
                if (['agent_wallets', 'withdrawal_requests'].includes(payload.table)) {
                    loadWalletData();
                }
            }).subscribe();
            return () => supabase.removeChannel(channel);
        }, [user, loadWalletData]);
        
        const verifyAccount = useCallback(async () => {
            if (debouncedAccountNumber.length !== 10 || !bankDetails.bankCode) {
                setVerifiedAccount(null);
                setVerificationError(null);
                return;
            }
            setIsVerifying(true);
            setVerifiedAccount(null);
            setVerificationError(null);
            try {
                const { data, error } = await supabase.functions.invoke('verify-bank-account', {
                    body: { account_number: debouncedAccountNumber, bank_code: bankDetails.bankCode }
                });

                if (error) throw new Error(error.message || 'Verification failed due to a network issue.');
                if (data.error) throw new Error(data.error);

                setVerifiedAccount({ name: data.account_name, ref: data.bank_id });
            } catch (error) {
                setVerificationError(error.message);
                setVerifiedAccount(null);
            } finally {
                setIsVerifying(false);
            }
        }, [debouncedAccountNumber, bankDetails.bankCode]);

        useEffect(() => {
            verifyAccount();
        }, [verifyAccount]);

        const handleWithdraw = async (e) => {
            e.preventDefault();
            const amount = parseFloat(withdrawAmount);

            if (!isFormValid) {
                toast({ title: 'Invalid Request', description: 'Please fix the errors before submitting.', variant: 'destructive' });
                return;
            }
            
            setIsSubmitting(true);
            try {
                const selectedBank = banks.find(b => b.code === bankDetails.bankCode);
                if (!selectedBank) throw new Error("Invalid bank selected.");

                const { error } = await supabase.rpc('request_withdrawal', {
                    p_amount: amount,
                    p_bank_name: selectedBank.name,
                    p_bank_code: bankDetails.bankCode,
                    p_account_number: bankDetails.accountNumber,
                    p_verified_account_name: verifiedAccount.name,
                    p_verification_ref: verifiedAccount.ref.toString()
                });

                if (error) throw error;
                
                toast({ title: "Withdrawal Requested", description: "Your request has been submitted for admin approval." });
                setShowWithdrawDialog(false);
                setWithdrawAmount('');
                setBankDetails({ bankCode: '', accountNumber: '' });
                setVerifiedAccount(null);
                setVerificationError(null);
                loadWalletData();
            } catch (error) {
                toast({ title: "Request Failed", description: error.message, variant: 'destructive' });
            } finally {
                setIsSubmitting(false);
            }
        };

        const getStatusBadge = (status) => {
            const styles = {
                requested: 'bg-yellow-100 text-yellow-800 border-yellow-300',
                paid: 'bg-green-100 text-green-800 border-green-300',
                rejected: 'bg-red-100 text-red-800 border-red-300',
            };
            return <Badge className={cn('capitalize', styles[status])}>{status}</Badge>;
        };

        const selectedBankName = useMemo(() => {
            return banks.find(b => b.code === bankDetails.bankCode)?.name || "Select bank...";
        }, [banks, bankDetails.bankCode]);

        const amountError = useMemo(() => {
            const amount = parseFloat(withdrawAmount);
            if (!withdrawAmount) return null;
            if (amount < 100) return `Minimum withdrawal is ${formatCurrency(100)}.`;
            if (wallet && amount > wallet.balance) return `Amount exceeds available balance of ${formatCurrency(wallet.balance)}.`;
            return null;
        }, [withdrawAmount, wallet]);

        const isFormValid = useMemo(() => {
            return !amountError && verifiedAccount && !isVerifying && !isSubmitting;
        }, [amountError, verifiedAccount, isVerifying, isSubmitting]);

        return (
            <>
                <Helmet><title>My Wallet - EstateHub</title></Helmet>
                <div className="min-h-screen bg-background">
                    <Navbar />
                    <div className="container mx-auto px-4 py-8">
                        <motion.div initial="hidden" animate="visible" variants={itemVariants}>
                          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">My Wallet</h1>
                          <p className="text-muted-foreground mb-8">Manage your earnings and request withdrawals.</p>

                          {loading ? (
                              <div className="flex justify-center items-center h-96"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                          ) : (
                            <>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                                  <Card><CardHeader><CardTitle className="flex items-center gap-2"><Wallet/>Available Balance</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{formatCurrency(wallet?.balance || 0)}</p></CardContent></Card>
                                  <Card><CardHeader><CardTitle className="flex items-center gap-2"><HandCoins/>Pending Payouts</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{formatCurrency(wallet?.pending_withdrawal || 0)}</p></CardContent></Card>
                                  <Card><CardHeader><CardTitle className="flex items-center gap-2"><History/>Lifetime Earnings</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{formatCurrency(wallet?.lifetime_earnings || 0)}</p></CardContent></Card>
                              </div>
                              
                              <Card>
                                  <CardHeader className="flex flex-row items-center justify-between">
                                      <div>
                                          <CardTitle>Withdrawal History</CardTitle>
                                          <CardDescription>Track your payout requests.</CardDescription>
                                      </div>
                                      <Button onClick={() => setShowWithdrawDialog(true)} disabled={!wallet || wallet.balance <= 100}>
                                          <ArrowRight className="mr-2 h-4 w-4"/> Request Withdrawal
                                      </Button>
                                  </CardHeader>
                                  <CardContent>
                                      {requests && requests.length > 0 ? requests.map(req => (
                                          <div key={req.id} className="p-4 border rounded-lg mb-4 flex items-center justify-between flex-wrap gap-2">
                                              <div>
                                                  <p className="font-semibold text-lg">{formatCurrency(req.amount)}</p>
                                                  <p className="text-sm text-muted-foreground">{req.bank_name} - ****{req.account_number.slice(-4)}</p>
                                                  <p className="text-xs text-muted-foreground">Requested: {new Date(req.created_at).toLocaleString()}</p>
                                                  {req.rejection_reason && <p className="text-xs text-red-500">Reason: {req.rejection_reason}</p>}
                                              </div>
                                              {getStatusBadge(req.status)}
                                          </div>
                                      )) : <p className="text-center py-8 text-muted-foreground">No withdrawal requests yet.</p>}
                                  </CardContent>
                              </Card>
                            </>
                          )}
                        </motion.div>
                    </div>
                </div>

                <Dialog open={showWithdrawDialog} onOpenChange={setShowWithdrawDialog}>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Request Withdrawal</DialogTitle>
                            <DialogDescription>Enter your bank details to withdraw funds. Payouts are processed within 2-3 business days.</DialogDescription>
                        </DialogHeader>
                        <form onSubmit={handleWithdraw} className="space-y-4 pt-4">
                            <div>
                                <Label htmlFor="amount">Amount (NGN)</Label>
                                <Input id="amount" type="number" value={withdrawAmount} onChange={e => setWithdrawAmount(e.target.value)} required />
                                {amountError ? (
                                    <p className="text-xs text-destructive mt-1">{amountError}</p>
                                ) : (
                                    <p className="text-xs text-muted-foreground mt-1">Available to withdraw: {formatCurrency(wallet?.balance || 0)}</p>
                                )}
                            </div>
                            
                            <div>
                                <Label>Bank</Label>
                                <Popover open={openBankPopover} onOpenChange={setOpenBankPopover}>
                                    <PopoverTrigger asChild>
                                        <Button variant="outline" role="combobox" aria-expanded={openBankPopover} className="w-full justify-between">
                                            {selectedBankName}
                                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-[300px] p-0">
                                        <Command>
                                            <CommandInput placeholder="Search bank..." onValueChange={setBankSearch}/>
                                            <CommandList>
                                                <CommandEmpty>No bank found.</CommandEmpty>
                                                <CommandGroup>
                                                    {banks.filter(b => b.name.toLowerCase().includes(bankSearch.toLowerCase())).map((bank) => (
                                                        <CommandItem key={bank.code} value={bank.code} onSelect={(currentValue) => {
                                                            setBankDetails({ ...bankDetails, bankCode: currentValue === bankDetails.bankCode ? "" : currentValue });
                                                            setOpenBankPopover(false);
                                                            setVerifiedAccount(null);
                                                            setVerificationError(null);
                                                        }}>
                                                            <Check className={cn("mr-2 h-4 w-4", bankDetails.bankCode === bank.code ? "opacity-100" : "opacity-0")}/>
                                                            {bank.name}
                                                        </CommandItem>
                                                    ))}
                                                </CommandGroup>
                                            </CommandList>
                                        </Command>
                                    </PopoverContent>
                                </Popover>
                            </div>
                            
                            <div>
                                <Label htmlFor="accountNumber">Account Number (10 digits)</Label>
                                <Input id="accountNumber" type="text" pattern="\d{10}" title="Enter a 10-digit account number" value={bankDetails.accountNumber} onChange={e => {
                                    setBankDetails({...bankDetails, accountNumber: e.target.value.replace(/\D/g, '').slice(0, 10)});
                                    setVerifiedAccount(null);
                                    setVerificationError(null);
                                }} required />
                            </div>

                            {isVerifying && <div className="flex items-center text-sm text-muted-foreground"><Loader2 className="mr-2 h-4 w-4 animate-spin"/> Verifying account...</div>}
                            
                            {verifiedAccount && (
                                <Alert variant="default" className="bg-green-50 text-green-800 border-green-200">
                                    <ShieldCheck className="h-4 w-4 !text-green-600" />
                                    <AlertDescription className="font-semibold">{verifiedAccount.name}</AlertDescription>
                                </Alert>
                            )}

                            {verificationError && (
                                <Alert variant="destructive">
                                    <XCircle className="h-4 w-4" />
                                    <AlertDescription>{verificationError}</AlertDescription>
                                </Alert>
                            )}

                            <div className="flex items-start p-3 rounded-md bg-amber-50 text-amber-700 border border-amber-200">
                               <AlertTriangle className="h-5 w-5 mr-3 mt-0.5 flex-shrink-0" />
                               <p className="text-xs">Ensure your bank details are correct. Incorrect information can delay or void your payout.</p>
                            </div>

                            <DialogFooter>
                                <DialogClose asChild><Button type="button" variant="secondary">Cancel</Button></DialogClose>
                                <Button type="submit" disabled={!isFormValid}>
                                    {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                    {isSubmitting ? "Submitting..." : "Submit Request"}
                                </Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>
            </>
        );
    };

    export default AgentWalletPage;
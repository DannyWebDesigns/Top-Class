
    import React, { useState, useEffect, useCallback } from 'react';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { Home, MessageCircle, TrendingUp, Info, LifeBuoy, Wallet } from 'lucide-react';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';
    import Navbar from '@/components/Navbar';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { useToast } from '@/components/ui/use-toast';
    import { formatCurrency } from '@/lib/utils';
    import { supabase } from '@/lib/customSupabaseClient';
    import AgentNotifications from '@/components/agent-dashboard/AgentNotifications';
    import AgentPropertiesTab from '@/components/agent-dashboard/AgentPropertiesTab';
    import AgentMessagesTab from '@/components/agent-dashboard/AgentMessagesTab';
    import AgentTransactionsTab from '@/components/agent-dashboard/AgentTransactionsTab';
    import SupportTicketDialog from '@/components/SupportTicketDialog.jsx';

    const AgentDashboard = () => {
      const { user, profile } = useAuth();
      const { toast } = useToast();
      const [stats, setStats] = useState({
        activeListings: 0,
        soldListings: 0,
        conversations: 0,
        totalEarnings: 0,
        availableBalance: 0,
      });
      const [notifications, setNotifications] = useState([]);
      const [conversations, setConversations] = useState([]);
      const [showGuideline, setShowGuideline] = useState(false);
      const [isSupportDialogOpen, setIsSupportDialogOpen] = useState(false);


      const loadDashboardData = useCallback(async () => {
        if (!user) return;

        const { data: propertiesData, error: propertiesError } = await supabase.from('listings').select('id, status').eq('agent_id', user.id);
        const { data: convosData, error: convosError } = await supabase.rpc('get_agent_conversations');
        const { data: walletData, error: walletError } = await supabase.from('agent_wallets').select('balance, lifetime_earnings').eq('agent_id', user.id).maybeSingle();
        const { data: notificationsData, error: notificationsError } = await supabase.from('notifications').select('*').eq('target_user_id', user.id).order('created_at', { ascending: false });

        if (propertiesError) toast({ title: "Error loading listings", variant: "destructive" });
        if (convosError) toast({ title: "Error loading messages", variant: "destructive" });
        if (walletError && walletError.code !== 'PGRST116') toast({ title: "Error loading earnings", variant: "destructive", description: walletError.message });
        if (notificationsError) toast({ title: "Error loading notifications", variant: "destructive" });

        if (propertiesData) {
          setStats(prev => ({
            ...prev,
            activeListings: propertiesData.filter(p => p.status === 'active').length,
            soldListings: propertiesData.filter(p => p.status === 'sale' || p.status === 'rented' || p.status === 'sold').length,
          }));
        }
        if (convosData) {
          setConversations(convosData);
          setStats(prev => ({ ...prev, conversations: convosData.length }));
        }
        if (walletData) {
            setStats(prev => ({
              ...prev, 
              totalEarnings: walletData.lifetime_earnings,
              availableBalance: walletData.balance,
            }));
        } else {
            setStats(prev => ({...prev, totalEarnings: 0, availableBalance: 0 }));
        }
        if (notificationsData) setNotifications(notificationsData);
      }, [user, toast]);

      useEffect(() => {
        loadDashboardData();
        const hasVisited = localStorage.getItem('hasVisitedAgentDashboard');
        if (!hasVisited) {
          setShowGuideline(true);
          localStorage.setItem('hasVisitedAgentDashboard', 'true');
        }
      }, [loadDashboardData]);

      useEffect(() => {
        if (!user) return;
        const channel = supabase.channel(`agent-dashboard-channel-${user.id}`)
          .on('postgres_changes', { event: '*', schema: 'public' }, (payload) => {
              loadDashboardData();
              if (payload.table === 'notifications' && payload.eventType === 'INSERT' && payload.new.target_user_id === user.id) {
                toast({ title: payload.new?.payload?.title || "New Notification", description: payload.new?.payload?.message });
              }
          })
          .subscribe();

        return () => { supabase.removeChannel(channel); };
      }, [user, toast, loadDashboardData]);

      const statCards = [
        { title: 'Available Balance', value: formatCurrency(stats.availableBalance), icon: Wallet, color: 'text-green-400' },
        { title: 'Active Listings', value: stats.activeListings, icon: Home, color: 'text-blue-400' },
        { title: 'Conversations', value: stats.conversations, icon: MessageCircle, color: 'text-purple-400' },
        { title: 'Total Payouts', value: formatCurrency(stats.totalEarnings), icon: TrendingUp, color: 'text-amber-400' }
      ];

      return (
        <>
          <Helmet><title>Agent Dashboard - EstateHub</title></Helmet>
          <div className="min-h-screen bg-background">
            <Navbar />
            <div className="container mx-auto px-4 py-8">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">Welcome back, {profile?.full_name?.split(' ')[0]}!</h1>
                    <p className="text-muted-foreground">Here’s your dashboard overview.</p>
                  </div>
                   <div className="flex items-center gap-2">
                      <Button asChild>
                          <Link to="/agent-wallet">
                            <Wallet className="mr-2 h-4 w-4"/>
                            My Wallet
                          </Link>
                      </Button>
                      <Button variant="outline" onClick={() => setIsSupportDialogOpen(true)}>
                          <LifeBuoy className="mr-2 h-4 w-4"/>
                          Support
                      </Button>
                      <AgentNotifications notifications={notifications} setNotifications={setNotifications} />
                   </div>
                </div>

                <Dialog open={showGuideline} onOpenChange={setShowGuideline}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2"><Info className="text-blue-500" /> How Transactions Work</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-3 text-sm text-muted-foreground">
                      <p>1. <span className="font-semibold text-foreground">Initiate a Transaction:</span> Select a client and the final agreed amount to start a deal.</p>
                      <p>2. <span className="font-semibold text-foreground">Client Pays:</span> The client pays into the platform. The funds are held securely.</p>
                      <p>3. <span className="font-semibold text-foreground">Admin Approves:</span> After admin approval, 90% of the funds are credited to your wallet.</p>
                      <p>4. <span className="font-semibold text-foreground">Request Payout:</span> Go to your Wallet to request a withdrawal to your bank account.</p>
                    </div>
                    <DialogFooter><Button onClick={() => setShowGuideline(false)}>Got It!</Button></DialogFooter>
                  </DialogContent>
                </Dialog>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  {statCards.map((stat, index) => (
                    <motion.div key={stat.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }}>
                      <Card><CardContent className="p-6 flex items-center justify-between"><div className="space-y-1"><p className="text-muted-foreground text-sm">{stat.title}</p><p className="text-2xl font-bold text-foreground">{stat.value}</p></div><div className={`p-3 rounded-full bg-secondary ${stat.color}`}><stat.icon className="h-6 w-6" /></div></CardContent></Card>
                    </motion.div>
                  ))}
                </div>

                <Tabs defaultValue="properties" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-input mb-6">
                    <TabsTrigger value="properties">My Listings</TabsTrigger>
                    <TabsTrigger value="messages">Messages</TabsTrigger>
                    <TabsTrigger value="transactions">Transactions</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="properties"><AgentPropertiesTab onDataChange={loadDashboardData} /></TabsContent>
                  <TabsContent value="messages"><AgentMessagesTab initialConversations={conversations} /></TabsContent>
                  <TabsContent value="transactions"><AgentTransactionsTab /></TabsContent>
                </Tabs>
              </motion.div>
            </div>
             <SupportTicketDialog open={isSupportDialogOpen} onOpenChange={setIsSupportDialogOpen} />
          </div>
        </>
      );
    };

    export default AgentDashboard;
  
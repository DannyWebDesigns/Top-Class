
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowLeft, Phone, Award, MessageCircle, Home, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import Navbar from '@/components/Navbar';
import PropertyCard from '@/components/PropertyCard';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';

const AgentProfilePage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [agent, setAgent] = useState(null);
  const [agentProperties, setAgentProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadAgentData = useCallback(async () => {
    setLoading(true);
    const { data: agentData, error: agentError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', id)
      .eq('role', 'agent')
      .single();

    if (agentError || !agentData) {
      console.error("Error fetching agent:", agentError);
      setAgent(null);
    } else {
      setAgent(agentData);
    }

    const { data: propertiesData, error: propertiesError } = await supabase
      .from('listings')
      .select('*, profiles:agent_id(*)')
      .eq('agent_id', id);

    if (propertiesError) {
      console.error("Error fetching agent properties:", propertiesError);
      setAgentProperties([]);
    } else {
      setAgentProperties(propertiesData);
    }
    setLoading(false);
  }, [id]);

  useEffect(() => {
    loadAgentData();

    const channel = supabase.channel(`agent-profile-listings-changes-${id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'listings', filter: `agent_id=eq.${id}` }, (payload) => {
        loadAgentData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, loadAgentData]);

  const getBadgeColor = (badge) => {
    switch (badge) {
      case 'gold': return 'bg-amber-400 text-amber-900 border-amber-500';
      case 'premium': return 'bg-purple-500 text-white border-purple-600';
      default: return 'hidden';
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-primary"></div></div>;
  }

  if (!agent) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <Award className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-foreground mb-2">Agent not found</h2>
            <p className="text-muted-foreground mb-6">The agent you're looking for doesn't exist or is not approved.</p>
            <Button asChild>
              <Link to="/agents">Browse Agents</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{agent.full_name} - Real Estate Agent - EstateHub</title>
        <meta name="description" content={`Connect with ${agent.full_name}, a licensed real estate agent with ${agent.years_of_experience} years of experience.`} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <div className="container mx-auto px-4 py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Button asChild variant="ghost" className="mb-6 text-muted-foreground hover:text-foreground">
              <Link to="/agents">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Agents
              </Link>
            </Button>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <Card className="bg-card border-border mb-6">
                  <CardContent className="p-6 text-center">
                    <div className="relative inline-block">
                      <Avatar className="h-32 w-32 mx-auto mb-6">
                        <AvatarImage src={agent.avatar_url} />
                        <AvatarFallback className="bg-primary text-primary-foreground text-4xl">
                          {agent.full_name?.charAt(0).toUpperCase() || 'A'}
                        </AvatarFallback>
                      </Avatar>
                      {agent.badge !== 'none' && (
                        <Badge className={cn("absolute top-0 right-0 capitalize", getBadgeColor(agent.badge))}>
                          <Star className="h-3 w-3 mr-1" />
                          {agent.badge}
                        </Badge>
                      )}
                    </div>

                    <h1 className="text-2xl font-bold text-foreground mb-2">{agent.full_name}</h1>
                    <p className="text-muted-foreground mb-4">Licensed Real Estate Agent</p>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center justify-center text-muted-foreground">
                        <Phone className="h-4 w-4 mr-2" />
                        <span>{agent.phone_number}</span>
                      </div>
                      <div className="flex items-center justify-center text-muted-foreground">
                        <Award className="h-4 w-4 mr-2" />
                        <span>{agent.years_of_experience} years experience</span>
                      </div>
                      <div className="flex items-center justify-center text-muted-foreground">
                        <span className="text-sm">License: {agent.license_number}</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Button onClick={() => navigate(`/messages/${agent.id}`)} className="w-full">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Send Message
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="text-foreground">Agent Statistics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between"><span className="text-muted-foreground">Active Listings</span><span className="text-foreground font-semibold">{agentProperties.filter(p => p.status === 'active').length}</span></div>
                      <div className="flex items-center justify-between"><span className="text-muted-foreground">Properties Sold</span><span className="text-foreground font-semibold">{agentProperties.filter(p => p.status === 'sold').length}</span></div>
                      <div className="flex items-center justify-between"><span className="text-muted-foreground">Years Experience</span><span className="text-foreground font-semibold">{agent.years_of_experience}</span></div>
                      <div className="flex items-center justify-between"><span className="text-muted-foreground">Client Rating</span><div className="flex items-center"><Star className="h-4 w-4 text-yellow-400 fill-current" /><span className="text-foreground font-semibold ml-1">4.8</span></div></div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-2">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="text-foreground">Properties by {agent.full_name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {agentProperties.length === 0 ? (
                      <div className="text-center py-8">
                        <Home className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-foreground mb-2">No properties listed</h3>
                        <p className="text-muted-foreground">This agent hasn't listed any properties yet.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {agentProperties.map((property, index) => (
                          <PropertyCard key={property.id} property={property} index={index} />
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default AgentProfilePage;

import React, { useState } from 'react';
import { Plus, X as XIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const AddPropertyDialog = ({ open, onOpenChange, onSuccess }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [newProperty, setNewProperty] = useState({
    title: '', description: '', price: '', location: '', type: 'sale',
    bedrooms: '', bathrooms: '', area: '', images: [], status: 'active', currency: 'NGN'
  });
  const [imageFiles, setImageFiles] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const resetForm = () => {
    setNewProperty({
      title: '', description: '', price: '', location: '', type: 'sale',
      bedrooms: '', bathrooms: '', area: '', images: [], status: 'active', currency: 'NGN'
    });
    setImageFiles([]);
    setImagePreviews([]);
  };

  const handleAddProperty = async (e) => {
    e.preventDefault();
    if (imageFiles.length === 0) {
      toast({ title: "Image Required", description: "Please upload at least one image.", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);

    const imageUrls = [];
    for (const file of imageFiles) {
      const { data, error } = await supabase.storage
        .from('properties')
        .upload(`${user.id}/${Date.now()}-${file.name}`, file);
      if (error) {
        toast({ title: "Image upload failed", description: error.message, variant: "destructive" });
        setIsSubmitting(false);
        return;
      }
      const { data: publicUrlData } = supabase.storage.from('properties').getPublicUrl(data.path);
      imageUrls.push(publicUrlData.publicUrl);
    }

    const { error } = await supabase.from('listings').insert([{
      ...newProperty,
      agent_id: user.id,
      images: imageUrls,
      price: parseFloat(newProperty.price),
      bedrooms: parseInt(newProperty.bedrooms),
      bathrooms: parseInt(newProperty.bathrooms),
      area: parseInt(newProperty.area),
    }]);

    setIsSubmitting(false);
    if (error) {
      toast({ title: "Failed to add property", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Property Added!", description: "Your new listing is live. 🏠" });
      resetForm();
      onOpenChange(false);
      onSuccess();
    }
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    const currentImageCount = imagePreviews.length;
    const filesToProcess = files.slice(0, 10 - currentImageCount);

    setImageFiles(prev => [...prev, ...filesToProcess]);

    const newPreviews = [];
    filesToProcess.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        newPreviews.push(reader.result);
        if (newPreviews.length === filesToProcess.length) {
          setImagePreviews(prev => [...prev, ...newPreviews]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index) => {
    const newImageFiles = [...imageFiles];
    const newPreviews_ = [...imagePreviews];
    newImageFiles.splice(index, 1);
    newPreviews_.splice(index, 1);
    setImageFiles(newImageFiles);
    setImagePreviews(newPreviews_);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button><Plus className="h-4 w-4 mr-2" />Add Property</Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto custom-scrollbar">
        <DialogHeader><DialogTitle>Add New Property</DialogTitle></DialogHeader>
        <form onSubmit={handleAddProperty} className="space-y-6 pt-4">
          <div className="space-y-2"><Label htmlFor="title">Property Title</Label><Input id="title" name="title" value={newProperty.title} onChange={e => setNewProperty({ ...newProperty, title: e.target.value })} required /></div>
          <div className="space-y-2"><Label htmlFor="description">Description</Label><Textarea id="description" name="description" value={newProperty.description} onChange={e => setNewProperty({ ...newProperty, description: e.target.value })} required /></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2"><Label htmlFor="price">Price (₦)</Label><Input id="price" name="price" type="number" value={newProperty.price} onChange={e => setNewProperty({ ...newProperty, price: e.target.value })} required /></div>
            <div className="space-y-2"><Label htmlFor="location">Location</Label><Input id="location" name="location" value={newProperty.location} onChange={e => setNewProperty({ ...newProperty, location: e.target.value })} required /></div>
            <div className="space-y-2"><Label htmlFor="type">Type</Label><select id="type" name="type" value={newProperty.type} onChange={e => setNewProperty({ ...newProperty, type: e.target.value })} className="w-full h-10 px-3 rounded-md bg-input border"><option value="sale">For Sale</option><option value="rent">For Rent</option></select></div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2"><Label htmlFor="bedrooms">Bedrooms</Label><Input id="bedrooms" name="bedrooms" type="number" value={newProperty.bedrooms} onChange={e => setNewProperty({ ...newProperty, bedrooms: e.target.value })} required /></div>
            <div className="space-y-2"><Label htmlFor="bathrooms">Bathrooms</Label><Input id="bathrooms" name="bathrooms" type="number" value={newProperty.bathrooms} onChange={e => setNewProperty({ ...newProperty, bathrooms: e.target.value })} required /></div>
            <div className="space-y-2"><Label htmlFor="area">Area (sqft)</Label><Input id="area" name="area" type="number" value={newProperty.area} onChange={e => setNewProperty({ ...newProperty, area: e.target.value })} required /></div>
          </div>
          <div className="space-y-2">
            <Label>Property Images (up to 10)</Label>
            <Input id="images" type="file" multiple accept="image/*" onChange={handleImageUpload} className="file:text-primary file:font-semibold" disabled={imagePreviews.length >= 10} />
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 mt-2">
              {imagePreviews.map((img, index) => (
                <div key={index} className="relative group">
                  <img src={img} alt={`Preview ${index}`} className="w-full h-24 object-cover rounded-md" />
                  <Button type="button" size="icon" variant="destructive" className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => removeImage(index)}><XIcon className="h-3 w-3" /></Button>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button type="button" variant="secondary">Cancel</Button></DialogClose>
            <Button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Submitting...' : 'Add Property'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddPropertyDialog;
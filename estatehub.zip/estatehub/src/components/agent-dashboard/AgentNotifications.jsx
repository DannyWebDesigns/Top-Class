import React from 'react';
import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/customSupabaseClient';

const AgentNotifications = ({ notifications, setNotifications }) => {
  const unreadNotifications = notifications.filter(n => !n.is_read).length;

  const handleMarkAsRead = async (notificationId) => {
    const { error } = await supabase.from('notifications').update({ is_read: true }).eq('id', notificationId);
    if (!error) {
      setNotifications(current => current.map(n => n.id === notificationId ? { ...n, is_read: true } : n));
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-6 w-6" />
          {unreadNotifications > 0 && <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500" />}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="p-4">
          <h4 className="font-medium text-sm mb-2">Notifications</h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {notifications.length > 0 ? notifications.map(n => (
              <div key={n.id} className="text-sm p-2 rounded-lg hover:bg-secondary">
                <p className={cn("font-semibold", !n.is_read && "text-foreground")}>{n.payload?.title || n.kind}</p>
                <p className={cn("text-xs", n.is_read ? "text-muted-foreground" : "text-foreground/80")}>{n.payload?.message}</p>
                {!n.is_read && <Button variant="link" size="sm" className="h-auto p-0 mt-1 text-xs" onClick={() => handleMarkAsRead(n.id)}>Mark as read</Button>}
              </div>
            )) : <p className="text-sm text-muted-foreground text-center py-4">No notifications yet.</p>}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default AgentNotifications;
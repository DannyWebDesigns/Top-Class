import React, { useState, useEffect, useCallback } from 'react';
import { Plus, Home, Archive, Edit, Trash2, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { formatCurrency } from '@/lib/utils';
import AddPropertyDialog from './AddPropertyDialog';
import PropertyCard from '@/components/PropertyCard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const AgentPropertiesTab = ({ onDataChange }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [properties, setProperties] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [showAddProperty, setShowAddProperty] = useState(false);
  const [showInitiateTransaction, setShowInitiateTransaction] = useState(false);
  const [propertyToProcess, setPropertyToProcess] = useState(null);
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState('');
  const [leasePeriod, setLeasePeriod] = useState('');

  const loadData = useCallback(async () => {
    if (!user) return;
    const { data: propertiesData, error: propertiesError } = await supabase
      .from('listings')
      .select('*')
      .eq('agent_id', user.id);
    if (propertiesError) {
      toast({ title: "Error fetching properties", description: propertiesError.message, variant: "destructive" });
    } else {
      setProperties(propertiesData);
    }
    
    const { data: transactionsData, error: transactionsError } = await supabase
      .from('transactions')
      .select('listing_id, status')
      .eq('agent_id', user.id);
    if (transactionsError) {
      toast({ title: "Error fetching transactions", description: transactionsError.message, variant: "destructive" });
    } else {
      setTransactions(transactionsData);
    }
  }, [user, toast]);

  const loadClients = useCallback(async () => {
    const { data, error } = await supabase.from('profiles').select('id, full_name').eq('role', 'client');
    if (error) {
      toast({ title: "Error fetching clients", description: error.message, variant: "destructive" });
    } else {
      setClients(data);
    }
  }, [toast]);

  useEffect(() => {
    loadData();
    loadClients();
  }, [loadData, loadClients]);

  const handleDeleteProperty = async (propertyId) => {
    const { error } = await supabase.from('listings').delete().eq('id', propertyId);
    if (error) {
      toast({ title: "Failed to delete", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Property Deleted", description: "The listing has been removed." });
      loadData();
      onDataChange();
    }
  };

  const handleInitiateTransaction = async (e) => {
    e.preventDefault();
    if (!propertyToProcess || !selectedClient) {
        toast({ title: "Missing Information", description: "Please select a client.", variant: "destructive" });
        return;
    }

    try {
        const { error } = await supabase.functions.invoke('create-transaction', {
            body: {
                listing_id: propertyToProcess.id,
                client_id: selectedClient,
                type: propertyToProcess.type,
                lease_period_months: propertyToProcess.type === 'rent' ? parseInt(leasePeriod) : null
            }
        });
        if (error) throw error;
        toast({ title: "Transaction Initiated!", description: "The client has been notified to confirm the transaction." });
        setShowInitiateTransaction(false);
        setPropertyToProcess(null);
        setSelectedClient('');
        setLeasePeriod('');
        loadData();
        onDataChange();
    } catch (error) {
        toast({ title: "Failed to initiate transaction", description: error.message.includes('duplicate key value violates') ? "This property already has an active transaction." : error.message, variant: "destructive" });
    }
  };

  const activeProperties = properties.filter(p => p.status === 'active');
  const soldProperties = properties.filter(p => p.status === 'sold' || p.status === 'rented');
  const propertiesWithActiveTransaction = transactions.filter(t => ['pending', 'client_confirmed'].includes(t.status)).map(t => t.listing_id);

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Your Properties</CardTitle>
            <CardDescription>Manage your active and sold property listings.</CardDescription>
          </div>
          <AddPropertyDialog
            open={showAddProperty}
            onOpenChange={setShowAddProperty}
            onSuccess={() => {
              loadData();
              onDataChange();
            }}
          />
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="active" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="active">Active ({activeProperties.length})</TabsTrigger>
              <TabsTrigger value="sold">Sold/Rented ({soldProperties.length})</TabsTrigger>
            </TabsList>
            <TabsContent value="active">
              {activeProperties.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {activeProperties.map((p) => {
                    const hasActiveTransaction = propertiesWithActiveTransaction.includes(p.id);
                    return (
                    <Card key={p.id} className="overflow-hidden">
                      <img src={p.images[0]} alt={p.title} className="w-full h-40 object-cover" />
                      <CardContent className="p-4">
                        <h3 className="font-semibold truncate">{p.title}</h3>
                        <p className="text-sm text-muted-foreground">{formatCurrency(p.price)}</p>
                        <div className="flex gap-2 mt-4">
                          <Tooltip><TooltipTrigger asChild>
                            <Button size="icon" variant="outline" className="h-8 w-8" onClick={() => { setPropertyToProcess(p); setShowInitiateTransaction(true); }} disabled={hasActiveTransaction}>
                              <DollarSign className="h-4 w-4"/>
                            </Button>
                          </TooltipTrigger><TooltipContent><p>{hasActiveTransaction ? 'Transaction in Progress' : 'Initiate Transaction'}</p></TooltipContent></Tooltip>
                          <Tooltip><TooltipTrigger asChild><Button size="icon" variant="outline" className="h-8 w-8"><Edit className="h-4 w-4"/></Button></TooltipTrigger><TooltipContent><p>Edit</p></TooltipContent></Tooltip>
                          <Dialog>
                            <Tooltip>
                              <TooltipTrigger asChild><DialogTrigger asChild><Button size="icon" variant="destructive" className="h-8 w-8"><Trash2 className="h-4 w-4"/></Button></DialogTrigger></TooltipTrigger>
                              <TooltipContent><p>Delete</p></TooltipContent>
                            </Tooltip>
                            <DialogContent>
                              <DialogHeader><DialogTitle>Are you sure?</DialogTitle><DialogDescription>This will permanently delete the property. This action cannot be undone.</DialogDescription></DialogHeader>
                              <DialogFooter><DialogClose asChild><Button variant="secondary">Cancel</Button></DialogClose><DialogClose asChild><Button variant="destructive" onClick={() => handleDeleteProperty(p.id)}>Delete</Button></DialogClose></DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </CardContent>
                    </Card>
                    );
                  })}
                </div>
              ) : <div className="text-center py-12"><Home className="mx-auto h-12 w-12 text-muted-foreground" /><h3 className="mt-2 text-sm font-semibold text-foreground">No active properties</h3><p className="mt-1 text-sm text-muted-foreground">Add a new property to get started.</p></div>}
            </TabsContent>
            <TabsContent value="sold">
              {soldProperties.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {soldProperties.map((p) => <PropertyCard key={p.id} property={p} />)}
                </div>
              ) : <div className="text-center py-12"><Archive className="mx-auto h-12 w-12 text-muted-foreground" /><h3 className="mt-2 text-sm font-semibold text-foreground">No sold properties</h3><p className="mt-1 text-sm text-muted-foreground">Your sold listings will appear here.</p></div>}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      <Dialog open={showInitiateTransaction} onOpenChange={setShowInitiateTransaction}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Initiate Transaction</DialogTitle>
            <DialogDescription>
              Start the transaction for "{propertyToProcess?.title}" at the fixed price of {formatCurrency(propertyToProcess?.price || 0)}. The client will need to confirm.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleInitiateTransaction} className="space-y-4 pt-4">
            <div>
              <Label htmlFor="client">Select Client</Label>
              <select id="client" value={selectedClient} onChange={(e) => setSelectedClient(e.target.value)} required className="w-full h-10 px-3 rounded-md bg-input border">
                <option value="" disabled>-- Select a client --</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.full_name}</option>)}
              </select>
            </div>
            {propertyToProcess?.type === 'rent' && (
              <div>
                <Label htmlFor="leasePeriod">Lease Period (Months)</Label>
                <Input id="leasePeriod" type="number" value={leasePeriod} onChange={(e) => setLeasePeriod(e.target.value)} required />
              </div>
            )}
            <DialogFooter>
              <DialogClose asChild><Button type="button" variant="secondary">Cancel</Button></DialogClose>
              <Button type="submit">Initiate Transaction</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AgentPropertiesTab;
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { MessageCircle, Send, Paperclip, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { cn } from '@/lib/utils';

const AgentMessagesTab = ({ initialConversations }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [conversations, setConversations] = useState(initialConversations || []);
  const [activeConversation, setActiveConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [isSending, setIsSending] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    setConversations(initialConversations);
    if (initialConversations.length > 0 && !activeConversation) {
      setActiveConversation(initialConversations[0]);
    }
  }, [initialConversations, activeConversation]);

  const fetchMessages = useCallback(async () => {
    if (!activeConversation) return;
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .or(`and(sender_id.eq.${user.id},receiver_id.eq.${activeConversation.client_id}),and(sender_id.eq.${activeConversation.client_id},receiver_id.eq.${user.id})`)
      .order('created_at', { ascending: true });

    if (error) {
      toast({ title: "Error fetching messages", description: error.message, variant: "destructive" });
    } else {
      setMessages(data);
    }
  }, [activeConversation, user, toast]);

  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  useEffect(() => {
    if (!activeConversation || !user) return;
    const channel = supabase.channel(`chat-${activeConversation.client_id}-${user.id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages',
        filter: `receiver_id=eq.${user.id}`
      }, (payload) => {
        setMessages(current => [...current, payload.new]);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    }
  }, [activeConversation, user.id]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if ((!newMessage.trim() && !attachment) || !activeConversation) return;

    setIsSending(true);

    let mediaUrl = null;
    let mediaType = null;

    if (attachment) {
      const fileExt = attachment.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('chat-attachments')
        .upload(filePath, attachment);

      if (uploadError) {
        toast({ title: "Upload Failed", description: uploadError.message, variant: "destructive" });
        setIsSending(false);
        return;
      }
      
      const { data: urlData } = supabase.storage.from('chat-attachments').getPublicUrl(filePath);
      mediaUrl = urlData.publicUrl;
      mediaType = attachment.type.startsWith('image/') ? 'image' : 'file';
    }

    const { error } = await supabase.from('chat_messages').insert({
      sender_id: user.id,
      receiver_id: activeConversation.client_id,
      message: newMessage,
      media_url: mediaUrl,
      media_type: mediaType,
    });

    if (error) {
      toast({ title: "Failed to send message", description: error.message, variant: "destructive" });
    } else {
      setNewMessage('');
      setAttachment(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
    setIsSending(false);
  };

  return (
    <Card className="h-[600px] flex">
      <div className="w-1/3 border-r flex flex-col">
        <div className="p-4 border-b"><Input placeholder="Search messages..." /></div>
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {conversations.map(c => (
            <div key={c.client_id} onClick={() => setActiveConversation(c)} className={cn("p-4 flex items-center gap-3 cursor-pointer hover:bg-secondary", activeConversation?.client_id === c.client_id && "bg-secondary")}>
              <Avatar><AvatarImage src={c.avatar_url} /><AvatarFallback>{c.full_name.charAt(0)}</AvatarFallback></Avatar>
              <div className="flex-1 overflow-hidden">
                <p className="font-semibold truncate text-sm">{c.full_name}</p>
                <p className="text-xs text-muted-foreground truncate">{c.last_message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="w-2/3 flex flex-col">
        {activeConversation ? (
          <>
            <div className="p-4 border-b flex items-center gap-3">
              <Avatar><AvatarImage src={activeConversation.avatar_url} /><AvatarFallback>{activeConversation.full_name.charAt(0)}</AvatarFallback></Avatar>
              <div><p className="font-semibold">{activeConversation.full_name}</p></div>
            </div>
            <div className="flex-1 p-4 overflow-y-auto custom-scrollbar space-y-4">
              {messages.map((m) => (
                <div key={m.id} className={cn("flex", m.sender_id === user.id ? 'justify-end' : 'justify-start')}>
                  <div className={cn("max-w-md p-3 rounded-lg", m.sender_id === user.id ? 'bg-primary text-primary-foreground' : 'bg-secondary')}>
                    {m.message}
                    {m.media_url && m.media_type === 'image' && <img src={m.media_url} alt="attachment" className="mt-2 rounded-lg max-w-full h-auto" />}
                    {m.media_url && m.media_type === 'file' && <a href={m.media_url} target="_blank" rel="noopener noreferrer" className="text-blue-300 hover:underline">View Attachment</a>}
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t">
              <form onSubmit={handleSendMessage} className="flex gap-2">
                 <Button type="button" variant="ghost" size="icon" onClick={() => fileInputRef.current.click()}>
                    <Paperclip className="h-4 w-4" />
                </Button>
                <Input ref={fileInputRef} type="file" className="hidden" onChange={(e) => setAttachment(e.target.files[0])}/>
                <Input value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Type a message..." disabled={isSending} />
                <Button type="submit" disabled={isSending || (!newMessage.trim() && !attachment)}>
                    {isSending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </form>
               {attachment && (
                  <div className="mt-2 flex items-center justify-between text-sm p-2 bg-secondary rounded-md">
                    <div className="flex items-center gap-2">
                        <ImageIcon className="h-4 w-4" />
                        <span className="truncate max-w-[200px]">{attachment.name}</span>
                    </div>
                    <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => { setAttachment(null); if(fileInputRef.current) fileInputRef.current.value = ''; }}>
                        <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-center">
            <div className="text-muted-foreground">
              <MessageCircle className="h-16 w-16 mx-auto mb-4" />
              <h3 className="text-xl font-semibold">No Conversation Selected</h3>
              <p>Select a conversation to start chatting.</p>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};

export default AgentMessagesTab;
import React, { useState, useEffect, useCallback } from 'react';
import { CreditCard } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { formatCurrency } from '@/lib/utils';

const AgentTransactionsTab = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [transactions, setTransactions] = useState([]);

  const loadTransactions = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('transactions')
      .select('*, client:client_id(full_name), property:listing_id(title)')
      .eq('agent_id', user.id)
      .order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching transactions", description: error.message, variant: "destructive" });
    } else {
      setTransactions(data);
    }
  }, [user, toast]);

  useEffect(() => {
    loadTransactions();
  }, [loadTransactions]);

  useEffect(() => {
    if (!user) return;
    const channel = supabase.channel(`agent-transactions-channel-${user.id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'transactions', filter: `agent_id=eq.${user.id}` }, loadTransactions)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'transactions', filter: `agent_id=eq.${user.id}` }, loadTransactions)
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    }
  }, [user, loadTransactions]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Transactions</CardTitle>
        <CardDescription>A log of all your sales and rentals.</CardDescription>
      </CardHeader>
      <CardContent>
        {transactions.map(t => (
          <div key={t.id} className="flex items-center justify-between p-4 border rounded-lg mb-4">
            <div className="flex items-center gap-4">
              <CreditCard className="h-8 w-8 text-muted-foreground" />
              <div>
                <p className="font-semibold">{formatCurrency(t.amount)} for <span className="text-primary">{t.property?.title || 'A property'}</span></p>
                <p className="text-sm text-muted-foreground">Client: {t.client?.full_name}</p>
                <p className="text-xs text-muted-foreground">Ref: {t.id} on {new Date(t.created_at).toLocaleDateString()}</p>
              </div>
            </div>
            <Badge variant={t.status === 'admin_confirmed' ? 'success' : t.status === 'pending' || t.status === 'client_confirmed' ? 'secondary' : 'destructive'}>{t.status}</Badge>
          </div>
        ))}
        {transactions.length === 0 && <p className="text-center text-muted-foreground py-8">No transactions yet.</p>}
      </CardContent>
    </Card>
  );
};

export default AgentTransactionsTab;
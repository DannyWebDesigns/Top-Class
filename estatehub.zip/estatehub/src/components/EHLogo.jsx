import React from 'react';
import { motion } from 'framer-motion';

const EHLogo = ({ className = "h-8 w-8", ...props }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.1 } },
  };

  const pathVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: {
      pathLength: 1,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeInOut" },
    },
  };

  const fillVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.4, delay: 0.7 } },
  };

  return (
    <motion.svg
      className={className}
      viewBox="0 0 100 100"
      xmlns="http://www.w3.org/2000/svg"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      {...props}
    >
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: 'hsl(var(--primary))', stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: 'hsl(var(--secondary))', stopOpacity: 1 }} />
        </linearGradient>
      </defs>

      {/* Main house structure */}
      <motion.path
        d="M 15 90 V 45 L 50 10 L 85 45 V 90"
        stroke="hsl(var(--foreground))"
        strokeWidth="6"
        strokeLinejoin="round"
        fill="transparent"
        variants={pathVariants}
      />
      
      {/* Roof detail */}
      <motion.path
        d="M 10 48 L 50 5 L 90 48"
        stroke="url(#logoGradient)"
        strokeWidth="7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="transparent"
        variants={{...pathVariants, visible: {...pathVariants.visible, transition: {...pathVariants.visible.transition, delay: 0.2}}}}
      />

      {/* Door */}
      <motion.rect
        x="42"
        y="65"
        width="16"
        height="25"
        rx="2"
        fill="hsl(var(--primary))"
        variants={fillVariants}
      />
      
      {/* Skyline in the background */}
      <motion.path
        d="M 25 90 V 70 L 35 70 V 90"
        stroke="hsl(var(--muted-foreground))"
        strokeWidth="4"
        fill="transparent"
        variants={{...pathVariants, visible: {...pathVariants.visible, transition: {...pathVariants.visible.transition, delay: 0.4}}}}
      />
       <motion.path
        d="M 65 90 V 60 L 75 60 V 90"
        stroke="hsl(var(--muted-foreground))"
        strokeWidth="4"
        fill="transparent"
        variants={{...pathVariants, visible: {...pathVariants.visible, transition: {...pathVariants.visible.transition, delay: 0.5}}}}
      />
    </motion.svg>
  );
};

export default EHLogo;

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Award, Phone, MessageCircle, Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const AgentCard = ({ agent, index }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleChatClick = (e) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Please log in",
        description: "You need to be logged in to chat with agents.",
        variant: "destructive",
        action: <Button onClick={() => navigate('/login')}>Login</Button>
      });
    } else {
      navigate(`/messages/${agent.id}`);
    }
  };

  const getBadgeColor = (badge) => {
    switch (badge) {
      case 'gold': return 'bg-amber-400 text-amber-900 border-amber-500';
      case 'premium': return 'bg-purple-500 text-white border-purple-600';
      default: return 'hidden';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card className="property-card text-center h-full flex flex-col">
        <CardContent className="p-6 flex-grow flex flex-col">
          <div className="relative">
            <Avatar className="h-24 w-24 mx-auto mb-4 border-2 border-primary">
              <AvatarImage src={agent.avatar_url} alt={agent.full_name} />
              <AvatarFallback className="bg-secondary text-secondary-foreground text-2xl">
                {agent.full_name?.charAt(0).toUpperCase() || 'A'}
              </AvatarFallback>
            </Avatar>
            {agent.badge !== 'none' && (
              <Badge className={cn("absolute top-0 right-1/2 translate-x-[80%] capitalize", getBadgeColor(agent.badge))}>
                <Star className="h-3 w-3 mr-1" />
                {agent.badge}
              </Badge>
            )}
          </div>

          <h3 className="text-xl font-bold text-foreground mb-1">{agent.full_name}</h3>
          
          <div className="flex items-center justify-center text-sm text-muted-foreground mb-4">
            <Award className="h-4 w-4 text-amber-400 mr-1.5" />
            <span>{agent.years_of_experience || 0} years experience</span>
          </div>

          <div className="flex items-center justify-center text-sm text-muted-foreground mb-2">
            <Phone className="h-4 w-4 mr-2" />
            <span>{agent.phone_number}</span>
          </div>

          <p className="text-xs text-muted-foreground mb-6">License: {agent.license_number}</p>

          <div className="flex flex-col sm:flex-row gap-2 mt-auto">
            <Button asChild size="sm" variant="outline" className="flex-1">
              <Link to={`/agent/${agent.id}`}>View Profile</Link>
            </Button>
            <Button asChild size="sm" className="flex-1" onClick={handleChatClick}>
              <Link to={`/messages/${agent.id}`}>
                <MessageCircle className="h-4 w-4 mr-2" />
                Chat
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default AgentCard;

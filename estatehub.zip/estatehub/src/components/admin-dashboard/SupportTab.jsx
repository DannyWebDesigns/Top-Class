import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Mail, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const SupportTab = ({ messages, activeMessage, setActiveMessage, replyText, setReplyText, handleReplySubmit, isReplying }) => (
    <motion.div variants={itemVariants}>
        <Card className="h-[600px] flex"><div className="w-1/3 border-r flex flex-col"><div className="p-4 border-b"><Input placeholder="Search tickets..." /></div><div className="flex-1 overflow-y-auto custom-scrollbar">
            {messages.map(msg => (<div key={msg.id} onClick={() => setActiveMessage(msg)} className={cn("p-4 border-b cursor-pointer hover:bg-secondary", activeMessage?.id === msg.id && 'bg-secondary')}><div className="flex justify-between items-start"><p className="font-semibold text-sm truncate">{msg.sender?.full_name}</p><Badge variant={msg.replied ? 'default' : 'secondary'}>{msg.replied ? 'Replied' : 'New'}</Badge></div><p className="text-xs text-muted-foreground truncate pr-4">{msg.message}</p><p className="text-xs text-muted-foreground mt-1">{new Date(msg.created_at).toLocaleString()}</p></div>))}</div></div>
            <div className="w-2/3 flex flex-col">{activeMessage ? (<> <div className="p-4 border-b"><div className="flex items-center gap-3"><Avatar><AvatarImage src={activeMessage.sender?.avatar_url} /><AvatarFallback>{activeMessage.sender?.full_name?.charAt(0) || 'U'}</AvatarFallback></Avatar><div><p className="font-semibold">{activeMessage.sender?.full_name}</p><p className="text-xs text-muted-foreground">{activeMessage.sender?.email}</p></div></div><p className="mt-2 p-4 bg-secondary rounded-md">{activeMessage.message}</p>{activeMessage.attachment_url && <a href={activeMessage.attachment_url} target="_blank" rel="noopener noreferrer" className="text-primary text-sm mt-2 hover:underline">View Attachment</a>}</div><div className="flex-1 p-4"><form onSubmit={handleReplySubmit}><Textarea placeholder={`Reply to ${activeMessage.sender?.full_name}...`} className="mb-4 min-h-[200px]" value={replyText} onChange={(e) => setReplyText(e.target.value)} disabled={activeMessage.replied || isReplying} />{activeMessage.replied && <p className="text-sm text-green-600 mb-2">You have already replied to this message: <span className="italic">{activeMessage.reply_text}</span></p>}<Button type="submit" disabled={activeMessage.replied || isReplying}>{isReplying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Send Reply</Button></form></div> </>) : (<div className="flex-1 flex items-center justify-center text-muted-foreground text-center"><Mail className="h-16 w-16 mx-auto mb-4" /><h3 className="text-xl font-semibold">No Message Selected</h3></div>)}</div>
        </Card>
    </motion.div>
);

export default SupportTab;
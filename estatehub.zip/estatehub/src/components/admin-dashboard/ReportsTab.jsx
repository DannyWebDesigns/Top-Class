import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Flag } from 'lucide-react';

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const ReportsTab = ({ reports, onUpdateStatus }) => (
    <motion.div variants={itemVariants}>
        <Card><CardHeader><CardTitle>Listing Reports</CardTitle><CardDescription>Review and resolve user-submitted reports.</CardDescription></CardHeader>
            <CardContent>
                {reports.map(report => (
                    <div key={report.id} className="p-4 border rounded-lg mb-4 hover:bg-secondary/50 transition-colors">
                        <div className="flex items-center justify-between"><div className="flex items-center gap-4"><Flag className="h-6 w-6 text-red-500" /><div><p className="font-semibold">Report for: <span className="text-primary">{report.listing?.title || 'Deleted Listing'}</span></p><p className="text-sm text-muted-foreground">Reason: {report.reason}</p><p className="text-xs text-muted-foreground">By: {report.reporter?.full_name || 'Anonymous'} on {new Date(report.created_at).toLocaleDateString()}</p></div></div><Badge variant={report.status === 'pending' ? 'destructive' : 'secondary'}>{report.status}</Badge></div>
                        {report.details && <p className="mt-2 p-3 bg-secondary rounded-md text-sm">{report.details}</p>}
                        <div className="flex gap-2 mt-3">{report.status === 'pending' && <Button size="sm" onClick={() => onUpdateStatus(report.id, 'reviewed')}>Mark as Reviewed</Button>}{report.status === 'reviewed' && <Button size="sm" variant="success" onClick={() => onUpdateStatus(report.id, 'resolved')}>Mark as Resolved</Button>}</div>
                    </div>
                ))}
                {reports.length === 0 && <p className="text-center text-muted-foreground py-8">No reports submitted yet.</p>}
            </CardContent>
        </Card>
    </motion.div>
);

export default ReportsTab;

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatCurrency, cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Check, X, Loader2 } from 'lucide-react';

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const WithdrawalsTab = ({ requests, onProcess, isProcessing }) => {
    const [requestToProcess, setRequestToProcess] = useState(null);
    const [action, setAction] = useState(null);
    const [reason, setReason] = useState('');

    const handleActionClick = (req, act) => {
        setRequestToProcess(req);
        setAction(act);
    };

    const handleConfirm = () => {
        onProcess(requestToProcess.id, action, reason);
        setRequestToProcess(null);
        setAction(null);
        setReason('');
    };

    const getStatusBadge = (status) => {
        const styles = {
            requested: 'bg-yellow-100 text-yellow-800 border-yellow-300',
            paid: 'bg-green-100 text-green-800 border-green-300',
            rejected: 'bg-red-100 text-red-800 border-red-300',
        };
        return <Badge className={cn('capitalize', styles[status])}>{status}</Badge>;
    };

    return (
        <>
            <motion.div variants={itemVariants}>
                <Card>
                    <CardHeader>
                        <CardTitle>Withdrawal Requests</CardTitle>
                        <CardDescription>Manage and process agent withdrawal requests.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {requests.map(req => (
                            <div key={req.id} className="p-4 border rounded-lg mb-4 hover:bg-secondary/50 transition-colors flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <Avatar>
                                        <AvatarImage src={req.agent?.avatar_url} />
                                        <AvatarFallback>{req.agent?.full_name?.charAt(0) || 'A'}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <p className="font-semibold">{req.agent?.full_name}</p>
                                        <p className="text-lg font-bold text-primary">{formatCurrency(req.amount)}</p>
                                        <p className="text-xs text-muted-foreground">{req.bank_name} - {req.account_number}</p>
                                        <p className="text-xs text-muted-foreground">Requested on {new Date(req.created_at).toLocaleDateString()}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    {getStatusBadge(req.status)}
                                    {req.status === 'requested' && (
                                        <>
                                            <Button size="icon" variant="outline" className="text-green-500" onClick={() => handleActionClick(req, 'paid')} disabled={isProcessing}>
                                                {isProcessing === req.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                                            </Button>
                                            <Button size="icon" variant="destructive-outline" onClick={() => handleActionClick(req, 'rejected')} disabled={isProcessing}>
                                                {isProcessing === req.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-4 w-4" />}
                                            </Button>
                                        </>
                                    )}
                                </div>
                            </div>
                        ))}
                        {requests.length === 0 && (
                            <p className="text-center text-muted-foreground py-8">No withdrawal requests at this time.</p>
                        )}
                    </CardContent>
                </Card>
            </motion.div>

            <Dialog open={!!requestToProcess} onOpenChange={() => setRequestToProcess(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Confirm Withdrawal Action</DialogTitle>
                        <DialogDescription>
                            You are about to {action} the withdrawal request of {formatCurrency(requestToProcess?.amount)} for {requestToProcess?.agent.full_name}.
                        </DialogDescription>
                    </DialogHeader>
                    {action === 'rejected' && (
                        <div className="py-4">
                            <Label htmlFor="reason">Reason for Rejection (required)</Label>
                            <Input id="reason" value={reason} onChange={e => setReason(e.target.value)} placeholder="e.g., Bank details incorrect" />
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="secondary" onClick={() => setRequestToProcess(null)}>Cancel</Button>
                        <Button variant={action === 'paid' ? 'default' : 'destructive'} onClick={handleConfirm} disabled={action === 'rejected' && !reason}>
                            Confirm {action === 'paid' ? 'Payment' : 'Rejection'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default WithdrawalsTab;

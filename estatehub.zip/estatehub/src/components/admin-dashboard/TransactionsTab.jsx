
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Check, X, Download, Loader2 } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const TransactionsTab = ({ transactions, onApprove, onReject, isProcessing }) => {
    const { toast } = useToast();

    const handleDownloadReceipt = async (transactionId) => {
        toast({ title: 'Generating Receipt...', description: 'Your download will begin shortly.' });
        try {
            const response = await fetch('/api/generate-receipt-pdf-download', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ transaction_id: transactionId }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to generate PDF');
            }
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `EstateHub-Receipt-${transactionId.substring(0, 8)}.pdf`;
            document.body.appendChild(a);
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);

        } catch (error) {
            toast({ title: 'Download Failed', description: error.message, variant: 'destructive' });
        }
    };
    
    return (
    <motion.div variants={itemVariants}>
        <Card><CardHeader><CardTitle>Transaction Log</CardTitle><CardDescription>Monitor all payments and transaction statuses on the platform.</CardDescription></CardHeader>
            <CardContent>
                {transactions.map(t => (
                    <div key={t.id} className="flex items-center justify-between p-4 border rounded-lg mb-4 hover:bg-secondary/50 transition-colors">
                        <div className="flex items-center gap-4"><CreditCard className="h-8 w-8 text-muted-foreground" /><div><p className="font-semibold">{formatCurrency(t.amount)} for <span className="text-primary">{t.property?.title}</span></p><p className="text-sm text-muted-foreground">From: {t.client?.full_name} To: {t.agent?.full_name}</p><p className="text-xs text-muted-foreground">Ref: {t.id} on {new Date(t.created_at).toLocaleDateString()}</p></div></div>
                        <div className="flex items-center gap-2">
                            <Badge variant={t.status === 'admin_confirmed' ? 'success' : t.status === 'pending' || t.status === 'client_confirmed' ? 'secondary' : 'destructive'}>{t.status}</Badge>
                            {t.status === 'client_confirmed' && (<> <Button size="sm" variant="outline" className="text-green-500 border-green-500" onClick={() => onApprove(t.id)} disabled={isProcessing === t.id}> {isProcessing === t.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />} Approve & Payout</Button><Button size="sm" variant="destructive" onClick={() => onReject(t.id)} disabled={isProcessing === t.id}><X className="mr-2 h-4 w-4" />Reject</Button> </>)}
                            {t.status === 'admin_confirmed' && (
                                <Button size="sm" variant="outline" onClick={() => handleDownloadReceipt(t.id)}><Download className="mr-2 h-4 w-4" />Receipt</Button>
                            )}
                        </div>
                    </div>
                ))}
                {transactions.length === 0 && <p className="text-center text-muted-foreground py-8">No transactions yet.</p>}
            </CardContent>
        </Card>
    </motion.div>
)};

export default TransactionsTab;

import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trash2 } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const ListingsTab = ({ listings, onDeleteAction }) => (
    <motion.div variants={itemVariants}>
        <Card><CardHeader><CardTitle>All Listings</CardTitle><CardDescription>Manage all properties on the platform.</CardDescription></CardHeader>
            <CardContent>
                {listings.map(l => (
                    <div key={l.id} className="flex items-center justify-between p-4 border rounded-lg mb-4 hover:bg-secondary/50 transition-colors">
                        <div className="flex items-center gap-4"><img src={l.images?.[0]} className="w-16 h-16 rounded-md object-cover" alt={l.title} /><div><p className="font-semibold">{l.title}</p><p className="text-sm text-muted-foreground">{formatCurrency(l.price)} - {l.location}</p><p className="text-xs text-muted-foreground">Agent: {l.profiles?.full_name || 'N/A'}</p></div></div>
                        <div className="flex items-center gap-4"><Badge variant={l.status === 'active' ? 'default' : 'destructive'}>{l.status}</Badge><Button size="icon" variant="destructive" onClick={() => onDeleteAction(l)}><Trash2 className="h-4 w-4" /></Button></div>
                    </div>
                ))}
            </CardContent>
        </Card>
    </motion.div>
);

export default ListingsTab;

import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { BarChart2, Users, Home, CreditCard, Flag, LifeBuoy, LogOut, Shield, X, User, UserCheck, Coins as HandCoins } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const Sidebar = ({ activeTab, setActiveTab, onLogout, isOpen, setIsOpen, pendingApprovalsCount }) => {
    const navItems = [
        { id: 'analytics', label: 'Analytics', icon: BarChart2, color: 'text-purple-500' },
        { id: 'users', label: 'Users', icon: Users, color: 'text-blue-500' },
        { id: 'agents', label: 'Agents', icon: UserCheck, color: 'text-green-500' },
        { id: 'clients', label: 'Clients', icon: User, color: 'text-yellow-500' },
        { id: 'listings', label: 'Listings', icon: Home, color: 'text-red-500' },
        { id: 'transactions', label: 'Payments', icon: CreditCard, color: 'text-indigo-500', count: pendingApprovalsCount > 0 ? pendingApprovalsCount : null },
        { id: 'withdrawals', label: 'Withdrawals', icon: HandCoins, color: 'text-teal-500' },
        { id: 'reports', label: 'Reports', icon: Flag, color: 'text-orange-500' },
        { id: 'support', label: 'Support', icon: LifeBuoy, color: 'text-pink-500' },
    ];

    const handleNavClick = (tabId) => {
        setActiveTab(tabId);
        if (isOpen) setIsOpen(false);
    };

    const sidebarContent = (
        <>
            <div className="flex items-center justify-between mb-10 px-2">
                <div className="flex items-center gap-2">
                    <Shield className="h-8 w-8 text-primary" />
                    <h2 className="text-xl font-bold">Admin Panel</h2>
                </div>
                {isOpen && (
                    <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsOpen(false)}>
                        <X className="h-6 w-6" />
                    </Button>
                )}
            </div>
            <nav className="flex-1 space-y-2">
                {navItems.map(item => (
                    <Button
                        key={item.id}
                        variant={activeTab === item.id ? 'secondary' : 'ghost'}
                        className="w-full justify-start text-base py-6 relative"
                        onClick={() => handleNavClick(item.id)}
                    >
                        <item.icon className={cn("mr-3 h-5 w-5", item.color)} />
                        <span>{item.label}</span>
                        {item.count && (
                            <Badge className="absolute right-4 bg-primary text-primary-foreground">{item.count}</Badge>
                        )}
                    </Button>
                ))}
            </nav>
            <div className="mt-auto">
                <Button variant="ghost" className="w-full justify-start text-base py-6" onClick={onLogout}>
                    <LogOut className="mr-3 h-5 w-5" />
                    Logout
                </Button>
            </div>
        </>
    );

    return (
        <>
            <aside className="w-64 bg-background border-r flex-col p-4 hidden md:flex">
                {sidebarContent}
            </aside>
            
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: isOpen ? 1 : 0 }}
                transition={{ duration: 0.3 }}
                className={cn(
                    "fixed inset-0 bg-black/50 z-40 md:hidden",
                    isOpen ? 'pointer-events-auto' : 'pointer-events-none'
                )}
                onClick={() => setIsOpen(false)}
            />
            <motion.aside
                initial={{ x: '-100%' }}
                animate={{ x: isOpen ? 0 : '-100%' }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                className="fixed top-0 left-0 h-full w-64 bg-background border-r flex flex-col p-4 z-50 md:hidden"
            >
                {sidebarContent}
            </motion.aside>
        </>
    );
};

export default Sidebar;

import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Eye, Trash2, Send } from 'lucide-react';

const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const UserManagementTab = ({ agents, clients, onUserAction, onSendMessage }) => (
    <motion.div variants={itemVariants}>
        <Card>
            <CardHeader><CardTitle>User Management</CardTitle><CardDescription>Review and manage all user accounts.</CardDescription></CardHeader>
            <CardContent>
                <h3 className="text-lg font-semibold mb-4">Agents ({agents.length})</h3>
                <div className="space-y-4 mb-8">
                    {agents.map(user => <UserRow key={user.id} user={user} onUserAction={onUserAction} onSendMessage={onSendMessage} />)}
                </div>
                <h3 className="text-lg font-semibold mb-4">Clients ({clients.length})</h3>
                <div className="space-y-4">
                    {clients.map(user => <UserRow key={user.id} user={user} onUserAction={onUserAction} onSendMessage={onSendMessage} />)}
                </div>
            </CardContent>
        </Card>
    </motion.div>
);

const UserRow = ({ user, onUserAction, onSendMessage }) => (
    <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-secondary/50 transition-colors">
        <div className="flex items-center gap-4"><Avatar><AvatarImage src={user.avatar_url} /><AvatarFallback>{user.full_name?.charAt(0) || 'U'}</AvatarFallback></Avatar><div><p className="font-semibold text-foreground">{user.full_name}</p><p className="text-sm text-muted-foreground">{user.email}</p></div></div>
        <div className="flex items-center gap-2">
            {user.role === 'agent' && (
                <Dialog><DialogTrigger asChild><Button variant="ghost" size="icon"><Eye className="h-4 w-4" /></Button></DialogTrigger>
                    <DialogContent><DialogHeader><DialogTitle>{user.full_name}'s Agent Profile</DialogTitle></DialogHeader><div className="py-4 space-y-4"><div><strong>Profile Picture:</strong><img src={user.avatar_url} alt="Profile" className="rounded-md max-h-40 w-auto mt-2" /></div><p><strong>License Number:</strong> {user.license_number}</p><p><strong>Years Experience:</strong> {user.years_of_experience}</p><div><strong>Proof of License:</strong><a href={user.license_proof_url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">View License Document</a></div></div></DialogContent>
                </Dialog>
            )}
            <Button size="icon" variant="ghost" className="text-blue-500" onClick={() => onSendMessage(user)}><Send className="h-4 w-4" /></Button>
            <Button size="icon" variant="destructive" onClick={() => onUserAction(user)}><Trash2 className="h-4 w-4" /></Button>
        </div>
    </div>
);

export default UserManagementTab;
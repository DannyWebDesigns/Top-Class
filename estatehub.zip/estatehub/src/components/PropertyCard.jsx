import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Bed, Bath, Triangle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { formatCurrency } from '@/lib/utils';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

const PropertyCard = ({ property, index }) => {
  const isSold = property.status === 'sale' || property.status === 'rent';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      layout
    >
      <Card className={cn("property-card overflow-hidden h-full flex flex-col", isSold && "opacity-60")}>
        <div className="relative">
          <img
            src={property.images?.[0] || 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?q=80&w=2070&auto=format&fit=crop'}
            alt={property.title}
            className="w-full h-52 object-cover"
            loading="lazy"
          />
          {isSold && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="text-white text-2xl font-bold border-2 border-white px-4 py-2 rounded-md uppercase">{property.status === 'sale' ? 'Sold' : 'Rented'}</span>
            </div>
          )}
          <div className="absolute top-3 left-3">
            <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider">
              {property.type}
            </span>
          </div>
          <div className="absolute top-3 right-3">
            <Tooltip>
              <TooltipTrigger asChild>
                <Link to={`/agent/${property.agent_id}`}>
                  <Avatar className="w-10 h-10 border-2 border-background">
                    <AvatarImage src={property.profiles?.avatar_url} alt={property.profiles?.full_name} />
                    <AvatarFallback>{property.profiles?.full_name?.charAt(0) || 'A'}</AvatarFallback>
                  </Avatar>
                </Link>
              </TooltipTrigger>
              <TooltipContent>
                <p>{property.profiles?.full_name}</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>
        
        <CardContent className="p-4 md:p-6 flex flex-col flex-grow">
          <div className="flex items-center text-muted-foreground mb-2">
            <MapPin className="h-4 w-4 mr-1.5 flex-shrink-0" />
            <span className="text-sm truncate">{property.location}</span>
          </div>
          <h3 className="text-lg md:text-xl font-bold text-foreground mb-3 truncate">{property.title}</h3>
          
          <div className="flex items-center justify-between text-muted-foreground mb-4">
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center gap-1.5">
                <Bed className="h-4 w-4 text-primary" />
                <span>{property.bedrooms}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Bath className="h-4 w-4 text-primary" />
                <span>{property.bathrooms}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Triangle className="h-4 w-4 text-primary" />
                <span>{property.area} sqft</span>
              </div>
            </div>
          </div>

          <p className="text-primary font-bold text-2xl mb-4 mt-auto">{formatCurrency(property.price)}</p>
          
          <Button asChild size="sm" className="w-full mt-2" disabled={isSold}>
            <Link to={`/property/${property.id}`}>View Details</Link>
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PropertyCard;
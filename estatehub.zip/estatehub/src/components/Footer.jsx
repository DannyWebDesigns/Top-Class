import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Linkedin, Twitter, Send } from 'lucide-react';
import EHLogo from '@/components/EHLogo';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const Footer = () => {
  return (
    <footer className="bg-secondary text-foreground border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Company Info */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <EHLogo className="h-8 w-8" />
              <span className="text-xl font-bold">EstateHub</span>
            </Link>
            <p className="text-sm text-muted-foreground">Your gateway to exceptional properties. We connect you with the best agents and homes.</p>
            <p className="text-sm text-muted-foreground">123 Real Estate Ave, Property City, 12345</p>
            <a href="mailto:support@estatehub.com" className="text-sm text-muted-foreground hover:text-primary transition-colors">support@estatehub.com</a>
          </div>

          {/* Quick Links */}
          <div>
            <p className="font-semibold mb-4">Quick Links</p>
            <ul className="space-y-2">
              <li><Link to="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">Home</Link></li>
              <li><Link to="/properties" className="text-sm text-muted-foreground hover:text-primary transition-colors">Properties</Link></li>
              <li><Link to="/agents" className="text-sm text-muted-foreground hover:text-primary transition-colors">Agents</Link></li>
              <li><Link to="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">FAQs</Link></li>
              <li><Link to="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Support</Link></li>
            </ul>
          </div>

          {/* Legal & Social */}
          <div>
            <p className="font-semibold mb-4">Legal</p>
            <ul className="space-y-2">
              <li><Link to="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms of Use</Link></li>
              <li><Link to="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link to="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">Anti-Scam Warning</Link></li>
            </ul>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Instagram size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Facebook size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Linkedin size={20} /></a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Twitter size={20} /></a>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <p className="font-semibold mb-4">Join Our Newsletter</p>
            <p className="text-sm text-muted-foreground mb-4">Get the latest property news and market updates delivered to your inbox.</p>
            <form className="flex space-x-2">
              <Input type="email" placeholder="Enter your email" className="bg-background" />
              <Button type="submit" size="icon"><Send size={16} /></Button>
            </form>
          </div>
        </div>

        <div className="border-t mt-12 pt-8 text-center text-sm text-muted-foreground">
          &copy; {new Date().getFullYear()} EstateHub. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, ShieldCheck, DollarSign, Users } from 'lucide-react';

const SafetySection = () => {
    const features = [
        { title: "Verified Listings", description: "Every property is checked to protect you from fraud.", icon: ShieldCheck },
        { title: "Trusted Agents", description: "Connect with reliable agents dedicated to helping students.", icon: Users },
        { title: "Fair Prices", description: "Find housing options that won't break your budget.", icon: DollarSign },
    ];
    
    return (
        <section className="py-24 px-4 bg-secondary/30">
            <div className="container mx-auto grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.5 }}
                variants={{ hidden: { opacity: 0, x: -50 }, visible: { opacity: 1, x: 0, transition: { duration: 0.7 } } }}
              >
                <h2 className="text-4xl font-bold mb-6">Your Safety, Our Priority</h2>
                <p className="text-muted-foreground text-lg mb-8">
                  We're committed to making your housing search secure. Say goodbye to rental scams and hello to verified listings and professional agents.
                </p>
                <div className="space-y-4">
                  {features.map(feature => (
                      <div key={feature.title} className="flex items-start gap-4">
                          <div className="mt-1 flex-shrink-0 h-6 w-6 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                              <feature.icon className="h-4 w-4" />
                          </div>
                          <div>
                              <h3 className="font-semibold text-lg">{feature.title}</h3>
                              <p className="text-muted-foreground">{feature.description}</p>
                          </div>
                      </div>
                  ))}
                </div>
                 <Button asChild size="lg" className="mt-10">
                  <Link to="/properties">
                    Start Exploring <ArrowRight className="h-5 w-5 ml-2" />
                  </Link>
                </Button>
              </motion.div>
               <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.5 }}
                variants={{ hidden: { opacity: 0, scale: 0.8 }, visible: { opacity: 1, scale: 1, transition: { duration: 0.7 } } }}
                className="h-[500px] relative"
              >
                <img  class="w-full h-full object-cover rounded-xl shadow-2xl" alt="A smiling student looking at her phone while sitting in a modern, well-lit apartment with a friend" src="https://images.unsplash.com/photo-1700190615918-b4aadb0e68cc" />
              </motion.div>
            </div>
        </section>
    );
}

export default SafetySection;
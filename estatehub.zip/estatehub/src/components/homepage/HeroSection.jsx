import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.3 },
    },
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } },
};

const HeroSection = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const navigate = useNavigate();
    const { toast } = useToast();

    const handleSearch = (e) => {
        e.preventDefault();
        if (!searchTerm.trim()) {
          toast({
            title: "Search is empty",
            description: "Please enter a campus, area, or keyword to search.",
            variant: "destructive",
          });
          return;
        }
        navigate(`/properties?search=${encodeURIComponent(searchTerm)}`);
    };

    return (
        <section className="relative pt-20 pb-28 px-4 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-t from-secondary/30 via-background to-background z-0"></div>
            <motion.div
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 0.1, scale: 1 }}
              transition={{ duration: 1.5 }}
              className="absolute inset-0 z-0"
            >
              <img  class="w-full h-full object-cover" alt="Bright and modern student apartment living room in Lagos" src="https://images.unsplash.com/photo-1546900886-c26cf30b36f3" />
            </motion.div>
            
            <motion.div 
              className="container mx-auto text-center relative z-10"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-extrabold mb-5 leading-tight">
                Your Next Home, Steps from Campus
              </motion.h1>
              <motion.p variants={itemVariants} className="text-lg text-muted-foreground mb-10 max-w-3xl mx-auto">
                Find safe, affordable, and convenient off-campus housing. We connect students with trusted landlords and apartments near your school in Nigeria.
              </motion.p>
              
              <motion.form
                onSubmit={handleSearch}
                variants={itemVariants}
                className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto bg-card/80 backdrop-blur-sm p-2 rounded-xl shadow-lg border"
              >
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search near your university, e.g., 'UNILAG', 'Yaba'"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-12 h-12 text-base bg-transparent border-none focus:ring-0"
                  />
                </div>
                <Button type="submit" size="lg" className="h-12 px-8 text-base">
                  Find My Place
                </Button>
              </motion.form>
            </motion.div>
        </section>
    );
}

export default HeroSection;

import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowRight } from 'lucide-react';
import { supabase } from '@/lib/customSupabaseClient';
import PropertyCard from '@/components/PropertyCard';

const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.2, delayChildren: 0.3 } },
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } },
};

const categoryData = {
    'shared-apartments': {
      title: "Shared Apartments",
      image: "https://images.unsplash.com/photo-1576941089067-2de3c901e126?q=80&w=2100&auto=format&fit=crop",
      alt: "Modern exterior of a shared apartment building in Lagos",
      description: "Live with friends in spacious, modern apartments. Ideal for groups seeking comfort and community.",
    },
    'hostel-rooms': {
      title: "Hostel Rooms",
      image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop",
      alt: "Bright, airy interior of a student hostel room in Nigeria",
      description: "Affordable, vibrant rooms perfect for campus life and making new connections.",
    },
    'full-houses': {
      title: "Full Houses",
      image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?q=80&w=2071&auto=format&fit=crop",
      alt: "Luxurious full house with a swimming pool in Lekki, Lagos",
      description: "Enjoy ultimate privacy and space. Perfect for those who desire independent living.",
    },
};

const CategoriesSection = () => {
    const [activeTab, setActiveTab] = useState('shared-apartments');
    const [listings, setListings] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const navigate = useNavigate();

    const fetchListings = useCallback(async (type) => {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('listings')
        .select('*, profiles:agent_id(*)')
        .eq('status', 'active')
        .eq('type', type)
        .order('created_at', { ascending: false })
        .limit(3);

      if (error) {
        console.error("Error fetching category listings:", error);
        setListings([]);
      } else {
        setListings(data);
      }
      setIsLoading(false);
    }, []);
    
    useEffect(() => {
        fetchListings(activeTab);
    }, [activeTab, fetchListings]);

    return (
        <section className="py-24 px-4 bg-gradient-to-b from-background to-secondary/20">
            <div className="container mx-auto">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.3 }}
                variants={containerVariants}
                className="text-center mb-12"
              >
                <motion.h2 variants={itemVariants} className="text-4xl font-bold mb-4">
                  Find Your Kind of Place
                </motion.h2>
                <motion.p variants={itemVariants} className="text-lg text-muted-foreground max-w-3xl mx-auto">
                    Explore curated listings for every student lifestyle. From social hostel rooms to private houses, your perfect home awaits.
                </motion.p>
              </motion.div>
              
              <div className="flex justify-center mb-12">
                  <div className="bg-muted p-1 rounded-lg flex items-center gap-1">
                      {Object.keys(categoryData).map(key => (
                          <Button key={key} variant={activeTab === key ? 'default' : 'ghost'} onClick={() => setActiveTab(key)} className="capitalize px-4 sm:px-6">
                              {categoryData[key].title}
                          </Button>
                      ))}
                  </div>
              </div>
              
                <motion.div
                    key={activeTab}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <Card className="overflow-hidden shadow-lg">
                        <div className="grid grid-cols-1 md:grid-cols-5">
                            <div className="md:col-span-2 relative">
                                <img src={categoryData[activeTab].image} alt={categoryData[activeTab].alt} className="w-full h-64 md:h-full object-cover"/>
                                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent md:bg-gradient-to-r"></div>
                                <div className="absolute bottom-0 left-0 p-8 text-white">
                                    <h3 className="text-3xl font-bold mb-2">{categoryData[activeTab].title}</h3>
                                    <p className="text-lg max-w-sm">{categoryData[activeTab].description}</p>
                                </div>
                            </div>
                            <div className="md:col-span-3 p-8">
                                <div className="flex justify-between items-center mb-6">
                                    <h4 className="text-2xl font-semibold">Featured Listings</h4>
                                    <Button asChild variant="outline" size="sm" onClick={() => navigate(`/properties?types=${activeTab}`)}>
                                        <Link to={`/properties?types=${activeTab}`}>View All <ArrowRight className="h-4 w-4 ml-2"/></Link>
                                    </Button>
                                </div>
                                {isLoading ? (
                                    <div className="flex justify-center items-center h-full min-h-[200px]">
                                        <Loader2 className="h-8 w-8 animate-spin text-primary"/>
                                    </div>
                                ) : listings.length > 0 ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                        {listings.map((listing, index) => (
                                            <PropertyCard key={listing.id} property={listing} index={index}/>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="text-center py-10">
                                        <p className="text-muted-foreground">No featured listings for this category right now.
                                            <Button variant="link" asChild><Link to="/properties">Explore all listings</Link></Button>
                                        </p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </Card>
                </motion.div>
            </div>
        </section>
    );
}

export default CategoriesSection;

import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Aisha Bello',
    role: 'Student, UNILAG',
    avatar: 'https://images.unsplash.com/photo-1521119989659-a83eee488004?q=80&w=1887&auto=format&fit=crop',
    rating: 5,
    comment: "Found a great and safe apartment just a 10-minute walk from my faculty. EstateHub made my house hunting so much easier!"
  },
  {
    name: 'Samuel Adekunle',
    role: 'Student, UI',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=1887&auto=format&fit=crop',
    rating: 5,
    comment: "The agents are verified and professional. I didn't have to worry about scams, which was my biggest fear. Found a cool spot in Agbowo."
  },
  {
    name: 'Grace Nwosu',
    role: 'Postgraduate, OAU',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1887&auto=format&fit=crop',
    rating: 4,
    comment: "Decent options and the prices are student-friendly. The platform is super easy to navigate. Recommended it to all my course mates."
  }
];

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.3 },
    },
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } },
};

const TestimonialsSection = () => {
    return (
        <section className="py-24 px-4">
            <div className="container mx-auto">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.3 }}
                variants={containerVariants}
                className="text-center mb-16"
              >
                <motion.h2 variants={itemVariants} className="text-4xl font-bold mb-4">
                  Hear from Fellow Students
                </motion.h2>
                <motion.p variants={itemVariants} className="text-lg text-muted-foreground max-w-3xl mx-auto">
                  See what other students are saying about finding their perfect place with EstateHub.
                </motion.p>
              </motion.div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.map((testimonial, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.5, delay: index * 0.15 }}
                  >
                    <Card className="h-full flex flex-col">
                      <CardContent className="p-6 flex-grow">
                        <div className="flex items-center mb-4">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`h-5 w-5 ${i < testimonial.rating ? 'text-amber-400 fill-amber-400' : 'text-muted-foreground/30'}`} />
                          ))}
                        </div>
                        <p className="text-muted-foreground italic">"{testimonial.comment}"</p>
                      </CardContent>
                      <div className="bg-secondary/50 p-4 flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                          <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-semibold">{testimonial.name}</p>
                          <Badge variant="outline" className="mt-1">
                            {testimonial.role}
                          </Badge>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
        </section>
    );
}

export default TestimonialsSection;
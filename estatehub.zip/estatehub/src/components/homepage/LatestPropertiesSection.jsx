
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Home } from 'lucide-react';
import PropertyCard from '@/components/PropertyCard';

const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.2, delayChildren: 0.3 },
    },
};

const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } },
};

const LatestPropertiesSection = ({ properties }) => {
    return (
        <section className="py-24 px-4">
            <div className="container mx-auto">
              <motion.div
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, amount: 0.3 }}
                variants={containerVariants}
                className="mb-16"
              >
                <motion.div variants={itemVariants} className="flex items-center justify-between">
                    <div>
                        <h2 className="text-4xl font-bold mb-4 text-left">
                        Latest Student Accommodations
                        </h2>
                        <p className="text-lg text-muted-foreground max-w-3xl text-left">
                        Fresh listings perfect for students, available right now.
                        </p>
                    </div>
                    <Button asChild variant="outline">
                        <Link to="/properties">View All Listings <ArrowRight className="h-4 w-4 ml-2"/></Link>
                    </Button>
                </motion.div>
              </motion.div>
              {properties.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {properties.map((property, index) => (
                    <PropertyCard key={property.id} property={property} index={index} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 bg-secondary/50 rounded-lg">
                    <Home className="mx-auto h-16 w-16 text-muted-foreground" />
                    <h3 className="mt-4 text-xl font-semibold">No Properties Available</h3>
                    <p className="mt-2 text-muted-foreground">Please check back soon for new listings.</p>
                </div>
              )}
            </div>
        </section>
    );
}

export default LatestPropertiesSection;

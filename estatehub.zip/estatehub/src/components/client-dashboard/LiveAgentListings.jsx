import React from 'react';
import { useNavigate } from 'react-router-dom';
import { UserCheck, Loader2, Users, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import AgentCard from '@/components/AgentCard';

const LiveAgentListings = ({ agents, isLoading }) => {
  const navigate = useNavigate();
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
            <CardTitle className="flex items-center gap-2"><UserCheck /> Find an Agent</CardTitle>
            <CardDescription>Connect with our verified and top-rated agents.</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={() => navigate('/agents')}>
            View All <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : agents.length === 0 ? (
           <div className="text-center py-10 bg-secondary/50 rounded-lg">
            <Users className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-2 text-lg font-semibold">No Agents Available</h3>
            <p className="mt-1 text-sm text-muted-foreground">Please check back later.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {agents.map((agent, index) => (
              <AgentCard key={agent.id} agent={agent} index={index} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default LiveAgentListings;
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2 } from 'lucide-react';

const ReportAgentDialog = ({ agent, open, onOpenChange }) => {
    const { toast } = useToast();
    const [reason, setReason] = useState('');
    const [details, setDetails] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!reason) {
            toast({ title: 'Reason required', description: 'Please provide a reason for the report.', variant: 'destructive' });
            return;
        }
        setIsSubmitting(true);

        try {
            const { error } = await supabase.rpc('create_agent_report', {
                p_reported_agent_id: agent.id,
                p_reason: reason,
                p_details: details,
            });

            if (error) throw error;
            
            toast({
                title: 'Report Submitted',
                description: `Your report against ${agent.full_name} has been submitted for review.`,
            });
            onOpenChange(false);
            setReason('');
            setDetails('');

        } catch (error) {
            toast({
                title: 'Submission Failed',
                description: error.message,
                variant: 'destructive',
            });
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Report Agent: {agent.full_name}</DialogTitle>
                    <DialogDescription>
                        Please provide details about why you are reporting this agent. All reports are reviewed by our team.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 pt-4">
                    <div>
                        <Label htmlFor="reason">Reason for Report</Label>
                        <Input
                            id="reason"
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="e.g., Unprofessional conduct, false information"
                            required
                        />
                    </div>
                    <div>
                        <Label htmlFor="details">Details</Label>
                        <Textarea
                            id="details"
                            value={details}
                            onChange={(e) => setDetails(e.target.value)}
                            placeholder="Please provide a detailed description of the incident."
                            required
                            rows={5}
                        />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="secondary" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
                            Cancel
                        </Button>
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Submit Report
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default ReportAgentDialog;
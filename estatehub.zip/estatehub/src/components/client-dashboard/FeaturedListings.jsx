
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, Loader2, FileText, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import PropertyCard from '@/components/PropertyCard';

const FeaturedListings = ({ listings, isLoading, error }) => {
  const navigate = useNavigate();
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><TrendingUp /> Featured Listings</CardTitle>
        <CardDescription>Check out these trending properties available now.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : listings.length === 0 ? (
           <div className="text-center py-10 bg-secondary/50 rounded-lg">
            <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-2 text-lg font-semibold">No Featured Properties</h3>
            <p className="mt-1 text-sm text-muted-foreground">Check back soon for new listings.</p>
            <Button size="sm" className="mt-4" onClick={() => navigate('/properties')}>Explore Listings</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {listings.map((listing, index) => (
              <PropertyCard key={listing.id} property={listing} index={index} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FeaturedListings;

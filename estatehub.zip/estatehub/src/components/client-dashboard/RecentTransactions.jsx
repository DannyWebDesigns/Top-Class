
import React from 'react';
import { CreditCard, Loader2, AlertTriangle, CheckCircle, XCircle, Download, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const RecentTransactions = ({ transactions, onPay, onReject, isProcessing }) => {
  const { toast } = useToast();

  const handleDownloadReceipt = async (transactionId) => {
    toast({ title: 'Generating Receipt...', description: 'Your download will begin shortly.' });
    try {
      const response = await fetch('/api/generate-receipt-pdf-download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transaction_id: transactionId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate PDF');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `EstateHub-Receipt-${transactionId.substring(0, 8)}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);

    } catch (error) {
      toast({ title: 'Download Failed', description: error.message, variant: 'destructive' });
    }
  };

  const getStatusInfo = (tx) => {
    const isPaid = tx.payment && (Array.isArray(tx.payment) ? tx.payment.some(p => p.status === 'success') : tx.payment.status === 'success');
    
    if (tx.status === 'admin_confirmed') {
      return { badge: <Badge variant="outline" className="text-green-600 border-green-400 bg-green-50"><CheckCircle className="mr-1 h-3 w-3" />Completed</Badge> };
    }
    if (tx.status === 'rejected') {
      return { badge: <Badge variant="destructive"><XCircle className="mr-1 h-3 w-3" />Rejected</Badge> };
    }
    if (isPaid || tx.status === 'client_confirmed') {
      return { badge: <Badge variant="outline" className="text-blue-600 border-blue-400 bg-blue-50"><Loader2 className="mr-1 h-3 w-3 animate-spin" />Awaiting Approval</Badge> };
    }
    if (tx.status === 'pending') {
      return { badge: <Badge variant="outline" className="text-amber-600 border-amber-400 bg-amber-50"><AlertTriangle className="mr-1 h-3 w-3" />Action Required</Badge> };
    }
    return { badge: <Badge variant="secondary">{tx.status}</Badge> };
  };

  const isPaymentSuccessful = (tx) => tx.payment && (Array.isArray(tx.payment) ? tx.payment.some(p => p.status === 'success') : tx.payment.status === 'success');

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><CreditCard /> Recent Transactions</CardTitle>
        <CardDescription>An overview of your recent transaction history.</CardDescription>
      </CardHeader>
      <CardContent>
        {transactions.length === 0 ? (
          <div className="text-center py-10 bg-secondary/50 rounded-lg">
            <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
            <h3 className="mt-2 text-lg font-semibold">No Transactions Found</h3>
            <p className="mt-1 text-sm text-muted-foreground">Your transaction history is empty.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.map(tx => (
              <div key={tx.id} className="p-4 border rounded-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex-grow">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-lg">{tx.listing?.title || 'Property'}</p>
                    {getStatusInfo(tx).badge}
                  </div>
                  <div className="text-sm text-muted-foreground flex items-center gap-4 mt-1">
                    <span>{formatCurrency(tx.amount)}</span>
                    <span>{new Date(tx.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {tx.status === 'pending' && (
                    <>
                      <Button size="sm" onClick={() => onPay(tx)} disabled={isProcessing === tx.id}>
                        {isProcessing === tx.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CreditCard className="mr-2 h-4 w-4" />}
                        Confirm & Pay
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => onReject(tx)} disabled={isProcessing === tx.id}>
                        <XCircle className="mr-2 h-4 w-4" />
                        Reject
                      </Button>
                    </>
                  )}
                  {isPaymentSuccessful(tx) && tx.status === 'admin_confirmed' && (
                    <Button size="sm" variant="outline" onClick={() => handleDownloadReceipt(tx.id)}>
                      <Download className="mr-2 h-4 w-4" />
                      Receipt
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentTransactions;

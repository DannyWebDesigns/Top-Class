import React, { useState } from 'react';
import { User, Settings, Loader2, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const ProfileCard = ({ profile, loading }) => {
  const [isConfirming, setIsConfirming] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();
  const { user, signOut } = useAuth();

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const { error } = await supabase.functions.invoke('delete-user', { body: { user_id: user.id } });
      if (error) throw error;
      
      toast({
        title: "Account Disabled",
        description: "Your account has been successfully disabled and you have been logged out.",
      });
      signOut();
    } catch(error) {
       toast({
        title: "Error Disabling Account",
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setIsDeleting(false);
      setIsConfirming(false);
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><User /> Profile</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center text-center">
          {loading ? <Loader2 className="h-16 w-16 animate-spin text-primary" /> : (
            <>
              <Avatar className="h-24 w-24 mb-4 border-4 border-primary/20">
                <AvatarImage src={profile?.avatar_url} alt={profile?.full_name} />
                <AvatarFallback className="bg-secondary text-secondary-foreground text-3xl">
                  {profile?.full_name?.charAt(0).toUpperCase() || 'C'}
                </AvatarFallback>
              </Avatar>
              <p className="text-xl font-bold">{profile?.full_name}</p>
              <p className="text-sm text-muted-foreground">{profile?.email}</p>
              <div className="flex gap-2 mt-4">
                 <Button variant="outline" size="sm">
                  <Settings className="mr-2 h-4 w-4" />
                  Edit Profile
                </Button>
                <Button variant="destructive" size="sm" onClick={() => setIsConfirming(true)}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Disable Account
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
      <Dialog open={isConfirming} onOpenChange={setIsConfirming}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you absolutely sure?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently disable your account and anonymize your data. You will be logged out immediately.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setIsConfirming(false)} disabled={isDeleting}>Cancel</Button>
            <Button variant="destructive" onClick={handleDeleteAccount} disabled={isDeleting}>
              {isDeleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Yes, Disable My Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProfileCard;
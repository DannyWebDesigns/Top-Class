import React from 'react';
import { LifeBuoy, Phone, Mail } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const SupportCard = ({ onContactAgent, onGetSupport }) => (
  <Card>
    <CardHeader>
      <CardTitle className="flex items-center gap-2"><LifeBuoy /> Need Help?</CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      <p className="text-muted-foreground text-sm">Have a question about a property or transaction? Contact an agent directly.</p>
      <Button className="w-full" variant="secondary" onClick={onContactAgent}><Phone className="mr-2 h-4 w-4" /> Contact Agent</Button>
      <p className="text-muted-foreground text-sm">For technical issues or account problems, open a support ticket.</p>
      <Button className="w-full" onClick={onGetSupport}><Mail className="mr-2 h-4 w-4" /> Get Support</Button>
    </CardContent>
  </Card>
);

export default SupportCard;
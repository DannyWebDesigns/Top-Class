import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, Loader2, FileText, MessageSquare, Flag } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import ReportAgentDialog from '@/components/client-dashboard/ReportAgentDialog';

const MyProperties = ({ properties, isLoading }) => {
  const navigate = useNavigate();
  const [reportAgent, setReportAgent] = useState(null);

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Home /> My Properties</CardTitle>
          <CardDescription>All properties you have successfully purchased or rented.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-40"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
          ) : properties.length === 0 ? (
            <div className="text-center py-10 bg-secondary/50 rounded-lg">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-lg font-semibold">No Properties Yet</h3>
              <p className="mt-1 text-sm text-muted-foreground">Properties you acquire will appear here.</p>
              <Button size="sm" className="mt-4" onClick={() => navigate('/properties')}>Explore Listings</Button>
            </div>
          ) : (
            <div className="space-y-4">
              {properties.map(({ id, listing }) => (
                <div key={id} className="grid grid-cols-[auto,1fr,auto] items-center gap-4 p-3 border rounded-lg hover:bg-secondary/50 transition-colors">
                  <img src={listing.images?.[0] || 'https://placehold.co/100x100'} alt={listing.title} className="w-16 h-16 rounded-md object-cover" />
                  <div className="flex-grow">
                    <p className="font-semibold">{listing.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Tooltip>
                        <TooltipTrigger>
                          <Avatar className="h-6 w-6">
                             <AvatarImage src={listing.agent?.avatar_url} alt={listing.agent?.full_name} />
                             <AvatarFallback>{listing.agent?.full_name?.charAt(0) || 'A'}</AvatarFallback>
                          </Avatar>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Agent: {listing.agent?.full_name}</p>
                        </TooltipContent>
                      </Tooltip>
                      <p className="text-sm text-muted-foreground">{listing.agent?.full_name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={listing.status === 'sold' ? 'default' : 'secondary'} className="capitalize">{listing.status}</Badge>
                    <Button size="icon" variant="outline" className="h-8 w-8" onClick={() => navigate(`/messages/${listing.agent_id}`)}>
                      <MessageSquare className="h-4 w-4"/>
                    </Button>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button size="icon" variant="destructive-outline" className="h-8 w-8" onClick={() => setReportAgent(listing.agent)}>
                                <Flag className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                            <p>Report Agent</p>
                        </TooltipContent>
                    </Tooltip>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      {reportAgent && (
        <ReportAgentDialog
            agent={reportAgent}
            open={!!reportAgent}
            onOpenChange={(isOpen) => !isOpen && setReportAgent(null)}
        />
      )}
    </>
  );
};

export default MyProperties;
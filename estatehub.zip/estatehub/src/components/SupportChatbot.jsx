import React from 'react';
import { Button } from '@/components/ui/button';
import { FaWhatsapp } from 'react-icons/fa';

const SupportChatbot = () => {
  const handleSupportClick = () => {
    window.open('https://wa.me/2347067818376', '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed bottom-5 right-5 z-50">
      <Button
        size="icon"
        className="rounded-full h-16 w-16 shadow-lg flex items-center justify-center group bg-[#25D366] hover:bg-[#128C7E]"
        onClick={handleSupportClick}
      >
        <FaWhatsapp className="h-8 w-8 text-white transition-transform duration-300 group-hover:scale-110" />
        <span className="sr-only">Customer Support</span>
      </Button>
    </div>
  );
};

export default SupportChatbot;
import React from 'react';

const ProductsList = () => {
  return (
    <div>
      <p>Online Store has been disconnected. This component is no longer in use.</p>
    </div>
  );
};

export default ProductsList;
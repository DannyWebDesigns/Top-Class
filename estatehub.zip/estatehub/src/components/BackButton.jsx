import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

const BackButton = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const handleBack = () => {
    if (window.history.length > 2) {
      navigate(-1);
    } else {
      navigate('/');
    }
  };

  const showBackButton = ['/login', '/register'].includes(location.pathname);

  if (!showBackButton) {
    return null;
  }

  return (
    <Button
      onClick={handleBack}
      variant="ghost"
      className="absolute top-5 left-5 z-50 text-muted-foreground hover:text-foreground hidden md:inline-flex"
    >
      <ArrowLeft className="h-4 w-4 mr-2" />
      Back
    </Button>
  );
};

export default BackButton;
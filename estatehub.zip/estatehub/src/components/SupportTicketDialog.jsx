import React, { useState, useRef } from 'react';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { useToast } from '@/components/ui/use-toast';
    import { supabase } from '@/lib/customSupabaseClient';
    import { Loader2, Paperclip, X } from 'lucide-react';

    const SupportTicketDialog = ({ open, onOpenChange }) => {
      const { toast } = useToast();
      const [subject, setSubject] = useState('');
      const [message, setMessage] = useState('');
      const [attachment, setAttachment] = useState(null);
      const [isSubmitting, setIsSubmitting] = useState(false);
      const fileInputRef = useRef(null);

      const resetForm = () => {
        setSubject('');
        setMessage('');
        setAttachment(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        const formData = new FormData();
        formData.append('subject', subject);
        formData.append('message', message);
        if (attachment) {
          formData.append('attachment', attachment);
        }

        try {
          const { error } = await supabase.functions.invoke('create-support-ticket', {
            body: formData,
          });

          if (error) throw new Error(error.message);

          toast({
            title: 'Ticket Submitted',
            description: 'Our support team will get back to you shortly.',
          });
          resetForm();
          onOpenChange(false);
        } catch (error) {
          toast({
            title: 'Submission Failed',
            description: error.message,
            variant: 'destructive',
          });
        } finally {
          setIsSubmitting(false);
        }
      };

      return (
        <Dialog open={open} onOpenChange={onOpenChange}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Contact Support</DialogTitle>
              <DialogDescription>
                Have an issue or a question? Fill out the form below to create a support ticket.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-4">
              <div>
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Issue with a transaction"
                  required
                />
              </div>
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please describe your issue in detail..."
                  required
                  rows={5}
                />
              </div>
              <div>
                <Label htmlFor="attachment">Attachment (Optional)</Label>
                <Input
                  id="attachment"
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => setAttachment(e.target.files[0])}
                  className="file:text-primary file:font-semibold"
                />
                {attachment && (
                  <div className="mt-2 flex items-center justify-between text-sm p-2 bg-secondary rounded-md">
                    <div className="flex items-center gap-2">
                        <Paperclip className="h-4 w-4" />
                        <span className="truncate max-w-[200px]">{attachment.name}</span>
                    </div>
                    <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => { setAttachment(null); if(fileInputRef.current) fileInputRef.current.value = ''; }}>
                        <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Submit Ticket
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      );
    };

    export default SupportTicketDialog;
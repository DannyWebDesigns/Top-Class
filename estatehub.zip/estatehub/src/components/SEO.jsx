import React from 'react';
import { Helmet } from 'react-helmet';
import { useLocation } from 'react-router-dom';

const SEO = ({ title, description, ogImage, structuredData }) => {
  const location = useLocation();

  const defaultTitle = 'EstateHub - Student Accommodation Made Easy';
  const defaultDescription = 'Find safe, affordable, and convenient off-campus housing, hostels, and apartments near your school in Nigeria. EstateHub is the trusted platform for student rentals.';
  const defaultOgImage = 'https://horizons-cdn.hostinger.com/3c6ab7a4-8e4f-40d5-aded-5cf29a2f6d8e/og_image_estatehub.png';
  const siteUrl = 'https://www.estatehub.com';

  const seo = {
    title: title || defaultTitle,
    description: description || defaultDescription,
    image: `${ogImage || defaultOgImage}`,
    url: `${siteUrl}${location.pathname}`,
  };

  return (
    <Helmet>
      <title>{seo.title}</title>
      <meta name="description" content={seo.description} />
      {seo.image && <meta name="image" content={seo.image} />}
      
      {seo.url && <meta property="og:url" content={seo.url} />}
      <meta property="og:type" content="website" />
      {seo.title && <meta property="og:title" content={seo.title} />}
      {seo.description && <meta property="og:description" content={seo.description} />}
      {seo.image && <meta property="og:image" content={seo.image} />}
      
      <meta name="twitter:card" content="summary_large_image" />
      {seo.title && <meta name="twitter:title" content={seo.title} />}
      {seo.description && <meta name="twitter:description" content={seo.description} />}
      {seo.image && <meta name="twitter:image" content={seo.image} />}
      
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
};

export default SEO;
import React from 'react';

const ShoppingCart = () => {
  return null;
};

export default ShoppingCart;

import React from 'react';
    import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
    import { Toaster } from '@/components/ui/toaster';
    import { TooltipProvider } from '@/components/ui/tooltip';
    import { AuthProvider } from '@/contexts/SupabaseAuthContext';
    import { ThemeProvider } from '@/contexts/ThemeContext';
    import HomePage from '@/pages/HomePage';
    import LoginPage from '@/pages/LoginPage';
    import RegisterPage from '@/pages/RegisterPage';
    import RegistrationSuccessPage from '@/pages/RegistrationSuccessPage';
    import ResetPasswordPage from '@/pages/ResetPasswordPage';
    import UpdatePasswordPage from '@/pages/UpdatePasswordPage';
    import AgentDashboard from '@/pages/AgentDashboard';
    import ClientDashboard from '@/pages/ClientDashboard';
    import AdminDashboard from '@/pages/AdminDashboard';
    import AllListingsPage from '@/pages/AllListingsPage';
    import AgentsPage from '@/pages/AgentsPage';
    import PropertyDetailsPage from '@/pages/PropertyDetailsPage';
    import AgentProfilePage from '@/pages/AgentProfilePage';
    import SavedPropertiesPage from '@/pages/SavedPropertiesPage';
    import ClientMessagesPage from '@/pages/ClientMessagesPage';
    import ReceiptPage from '@/pages/ReceiptPage';
    import AgentWalletPage from '@/pages/AgentWalletPage';
    import BackButton from '@/components/BackButton';
    import Footer from '@/components/Footer';
    import SEO from '@/components/SEO.jsx';

    const AppContent = () => {
      const location = useLocation();
      const showFooter = location.pathname === '/';

      return (
        <div className="min-h-screen bg-background font-sans flex flex-col">
          <BackButton />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/registration-success" element={<RegistrationSuccessPage />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />
              <Route path="/update-password" element={<UpdatePasswordPage />} />
              <Route path="/agent-dashboard" element={<AgentDashboard />} />
              <Route path="/agent-wallet" element={<AgentWalletPage />} />
              <Route path="/client-dashboard" element={<ClientDashboard />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/:tab" element={<AdminDashboard />} />
              <Route path="/properties" element={<AllListingsPage />} />
              <Route path="/agents" element={<AgentsPage />} />
              <Route path="/property/:id" element={<PropertyDetailsPage />} />
              <Route path="/agent/:id" element={<AgentProfilePage />} />
              <Route path="/saved-properties" element={<SavedPropertiesPage />} />
              <Route path="/messages" element={<ClientMessagesPage />} />
              <Route path="/messages/:agentId" element={<ClientMessagesPage />} />
              <Route path="/receipt/:transactionId" element={<ReceiptPage />} />
            </Routes>
          </main>
          {showFooter && <Footer />}
          <Toaster />
        </div>
      );
    };

    function App() {
      return (
        <ThemeProvider>
          <Router>
            <AuthProvider>
              <TooltipProvider>
                <SEO />
                <AppContent />
              </TooltipProvider>
            </AuthProvider>
          </Router>
        </ThemeProvider>
      );
    }

    export default App;

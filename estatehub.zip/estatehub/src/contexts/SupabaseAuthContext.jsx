import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate, useLocation } from 'react-router-dom';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const signOutAndRedirect = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setUser(null);
    setSession(null);
    navigate('/login');
  }, [navigate]);

  const fetchProfile = useCallback(async (userToFetch) => {
    if (!userToFetch) {
      setProfile(null);
      return null;
    }
    
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userToFetch.id)
        .single();
      
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error.message);
        toast({ title: "Could not load profile", description: error.message, variant: "destructive" });
        return null;
      }
      
      setProfile(data);
      return data;

    } catch (e) {
      console.error('An unexpected error occurred in fetchProfile:', e);
      setProfile(null);
      return null;
    }
  }, [toast]);

  useEffect(() => {
    const getSessionAndProfile = async () => {
      setLoading(true);
      const { data: { session: currentSession }, error: sessionError } = await supabase.auth.getSession();
      
      if(sessionError) {
        console.error("Error getting session:", sessionError.message);
        if (sessionError.message.includes('Invalid Refresh Token')) {
          await signOutAndRedirect();
        }
        setLoading(false);
        return;
      }

      setSession(currentSession);
      const currentUser = currentSession?.user ?? null;
      setUser(currentUser);

      if (currentUser) {
        await fetchProfile(currentUser);
      } else {
         const protectedRoutes = ['/agent-dashboard', '/client-dashboard', '/admin', '/saved-properties', '/messages', '/update-password'];
         if (protectedRoutes.some(path => location.pathname.startsWith(path)) && location.pathname !== '/update-password') {
             navigate(`/login?next=${location.pathname}`);
         }
      }
      setLoading(false);
    };

    getSessionAndProfile();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, newSession) => {
        setSession(newSession);
        const authUser = newSession?.user ?? null;
        setUser(authUser);
        if (authUser) {
          await fetchProfile(authUser);
           if (_event === 'PASSWORD_RECOVERY') {
            navigate('/update-password');
          }
        } else {
          setProfile(null);
          setUser(null);
        }
      }
    );

    return () => subscription?.unsubscribe();
  }, [fetchProfile, navigate, location.pathname, signOutAndRedirect]);

  const loginUser = useCallback(async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      if (error.message.includes('Invalid login credentials')) {
        throw new Error('Invalid email or password. Please try again.');
      }
      throw error;
    }

    const userProfile = await fetchProfile(data.user);
    if (!userProfile) {
      await supabase.auth.signOut();
      throw new Error("Could not retrieve user profile after login. Please try again.");
    }

    return userProfile;
  }, [fetchProfile]);

  const registerUser = useCallback(async (userData) => {
    const { email, password, fullName, role, phoneNumber, profilePicture, licenseNumber, licenseProof, yearsOfExperience } = userData;

    const { data: authData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName,
          role: role,
          phone_number: phoneNumber,
        }
      }
    });

    if (signUpError) {
      if (signUpError.message.includes('User already registered')) {
        throw new Error('This email is already registered. Please try logging in.');
      }
      throw signUpError;
    }
    const { user } = authData;
    if (!user) throw new Error("Registration failed, user not created.");
    
    if (role === 'agent') {
        let avatarUrl = null;
        let licenseUrl = null;

        if (profilePicture) {
            const { data: avatarData, error: avatarError } = await supabase.storage.from('avatars').upload(`public/${user.id}-profile.png`, profilePicture, { upsert: true });
            if (avatarError) throw new Error(`Avatar upload failed: ${avatarError.message}`);
            avatarUrl = supabase.storage.from('avatars').getPublicUrl(avatarData.path).data.publicUrl;
        }

        if (licenseProof) {
            const { data: licenseData, error: licenseError } = await supabase.storage.from('licenses').upload(`public/${user.id}-license.png`, licenseProof, { upsert: true });
            if (licenseError) throw new Error(`License upload failed: ${licenseError.message}`);
            licenseUrl = supabase.storage.from('licenses').getPublicUrl(licenseData.path).data.publicUrl;
        }
    
        const agentProfileData = {
          avatar_url: avatarUrl,
          license_number: licenseNumber,
          years_of_experience: yearsOfExperience,
          license_proof_url: licenseUrl,
          status: 'approved',
        };
    
        const { error: profileError } = await supabase.from('profiles').update(agentProfileData).eq('id', user.id);
    
        if (profileError) {
          const { error: deleteError } = await supabase.functions.invoke('delete-user', {
            body: { user_id: user.id }
          });
          if (deleteError) {
              console.error("CRITICAL: Failed to clean up user after profile update failed.", deleteError);
          }
          throw new Error(`Failed to update agent profile: ${profileError.message}`);
        }
    }

    navigate('/registration-success', { state: { role, email, password } });
    
  }, [navigate, toast]);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut({ scope: 'global' });
    if (error && error.message !== 'Session from session_id claim in JWT does not exist') {
      toast({ variant: "destructive", title: "Sign out Failed", description: error.message });
    } else {
      setProfile(null);
      setUser(null);
      setSession(null);
      navigate('/');
    }
  }, [toast, navigate]);

  const value = useMemo(() => ({
    user,
    session,
    profile,
    loading,
    loginUser,
    registerUser,
    signOut,
    fetchProfile,
  }), [user, session, profile, loading, loginUser, registerUser, signOut, fetchProfile]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
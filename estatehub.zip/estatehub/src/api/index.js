
import { supabase } from '@/lib/customSupabaseClient';

export const fetchAdminDashboardAnalytics = async () => {
    return await supabase.rpc('get_admin_dashboard_analytics');
};

export const fetchAllProfiles = async () => {
    return await supabase.from('profiles').select('*').order('updated_at', { ascending: false });
};

export const fetchAllListingsWithProfiles = async () => {
    return await supabase.from('listings').select('*, profiles(full_name)');
};

export const fetchAllSupportMessages = async () => {
    return await supabase.from('support_messages').select('*, sender:sender_id(full_name, email, avatar_url)').order('created_at', { ascending: false });
};

export const fetchAllReports = async () => {
    return await supabase.from('reports').select('*, listing:listing_id(title), reporter:reporter_id(full_name)').order('created_at', { ascending: false });
};

export const fetchAllTransactions = async () => {
    return await supabase.from('transactions').select('*, client:client_id(full_name), agent:agent_id(full_name), property:listing_id(title)').order('created_at', { ascending: false });
};

export const fetchAllWithdrawalRequests = async () => {
    return await supabase.from('withdrawal_requests').select('*, agent:agent_id(full_name, avatar_url, email)').order('created_at', { ascending: false });
};

export const fetchFilteredListings = async ({
  searchTerm,
  priceRange,
  bedrooms,
  bathrooms,
  types,
  sortBy,
  page,
  perPage,
}) => {
  return await supabase.rpc('get_filtered_listings', {
    p_search_term: searchTerm,
    p_min_price: priceRange[0],
    p_max_price: priceRange[1],
    p_min_bedrooms: bedrooms,
    p_min_bathrooms: bathrooms,
    p_types: types.length === 0 ? null : types,
    p_sort_by: sortBy.column,
    p_sort_order: sortBy.order,
    p_page: page,
    p_limit: perPage,
  });
};
